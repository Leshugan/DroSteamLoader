package leshugan.DSL;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(SteamPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
