package `in`.dragonbra.javasteam.depotdownloader

import `in`.dragonbra.javasteam.depotdownloader.data.AppItem
import `in`.dragonbra.javasteam.depotdownloader.data.ChunkMatch
import `in`.dragonbra.javasteam.depotdownloader.data.DepotDownloadCounter
import `in`.dragonbra.javasteam.depotdownloader.data.DepotDownloadInfo
import `in`.dragonbra.javasteam.depotdownloader.data.DepotFilesData
import `in`.dragonbra.javasteam.depotdownloader.data.DownloadItem
import `in`.dragonbra.javasteam.depotdownloader.data.FileStreamData
import `in`.dragonbra.javasteam.depotdownloader.data.GlobalDownloadCounter
import `in`.dragonbra.javasteam.depotdownloader.data.PubFileItem
import `in`.dragonbra.javasteam.depotdownloader.data.UgcItem
import `in`.dragonbra.javasteam.enums.EAccountType
import `in`.dragonbra.javasteam.enums.EAppInfoSection
import `in`.dragonbra.javasteam.enums.EDepotFileFlag
import `in`.dragonbra.javasteam.enums.EWorkshopFileType
import `in`.dragonbra.javasteam.steam.cdn.ClientLancache
import `in`.dragonbra.javasteam.steam.cdn.DepotChunk
import `in`.dragonbra.javasteam.steam.cdn.Server
import `in`.dragonbra.javasteam.steam.handlers.steamapps.License
import `in`.dragonbra.javasteam.steam.handlers.steamapps.callback.LicenseListCallback
import `in`.dragonbra.javasteam.steam.handlers.steamcloud.callback.UGCDetailsCallback
import `in`.dragonbra.javasteam.steam.steamclient.SteamClient
import `in`.dragonbra.javasteam.types.ChunkData
import `in`.dragonbra.javasteam.types.DepotManifest
import `in`.dragonbra.javasteam.types.FileData
import `in`.dragonbra.javasteam.types.KeyValue
import `in`.dragonbra.javasteam.types.PublishedFileID
import `in`.dragonbra.javasteam.types.UGCHandle
import `in`.dragonbra.javasteam.util.Adler32
import `in`.dragonbra.javasteam.util.SteamKitWebRequestException
import `in`.dragonbra.javasteam.util.Strings
import `in`.dragonbra.javasteam.util.log.LogManager
import `in`.dragonbra.javasteam.util.log.Logger
import io.ktor.client.request.get
import io.ktor.client.statement.bodyAsChannel
import io.ktor.http.HttpHeaders
import io.ktor.utils.io.core.readAvailable
import io.ktor.utils.io.readRemaining
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.DelicateCoroutinesApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.cancel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.flatMapMerge
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.yield
import okio.Buffer
import okio.FileSystem
import okio.Path
import okio.Path.Companion.toPath
import okio.buffer
import org.apache.commons.lang3.SystemUtils
import java.io.Closeable
import java.io.IOException
import java.io.RandomAccessFile
import java.lang.IllegalStateException
import java.time.Instant
import java.time.temporal.ChronoUnit
import java.util.concurrent.*
import java.util.concurrent.atomic.AtomicInteger
import kotlin.collections.mutableListOf
import kotlin.collections.set
import kotlin.text.toLongOrNull

/**
 * Downloads games, workshop items, and other Steam content via depot manifests.
 *
 * This class provides a queue-based FIFO download system that processes items sequentially.
 * Items are added via [add] or [addAll] and processed automatically in order. The processing
 * loop starts immediately upon construction and waits for items to be queued.
 *
 * ## Download Process
 * 1. Validates account access and obtains depot keys
 * 2. Downloads and caches depot manifests
 * 3. Allocates disk space for files
 * 4. Downloads chunks concurrently (configured by [maxDownloads])
 * 5. Verifies checksums and moves files to final location
 *
 * ## Thread Safety
 * Methods [add], [addAll], [addListener], and [removeListener] are thread-safe.
 * Multiple concurrent calls are supported.
 *
 * @param steamClient Connected Steam client instance with valid login session
 * @param licenses User's license list from [LicenseListCallback]. Required to determine which depots the account has access to.
 * @param debug Enables detailed logging of all operations via [LogManager]
 * @param useLanCache Attempts to detect and use local Steam cache servers (e.g., LANCache) for faster downloads on local networks
 * @param maxDownloads Number of concurrent chunk downloads. Automatically increased to 25 when a LAN cache is detected. Default: 8
 * @param maxDecompress Number of concurrent chunk decompress. Default: 8
 * @param maxFileWrites Number of concurrent files being written. Default: 1
 * @param androidEmulation Forces "Windows" as the default OS filter. Used when running Android games in PC emulators that expect Windows builds.
 * @param parentJob Parent job for the downloader. If provided, the downloader will be cancelled when the parent job is cancelled.
 *
 * @author Oxters
 * @author Lossy
 * @since Oct 29, 2024
 */
@OptIn(ExperimentalCoroutinesApi::class)
@Suppress("unused")
class DepotDownloader @JvmOverloads constructor(
    private val steamClient: SteamClient,
    private val licenses: List<License>,
    private val debug: Boolean = false,
    private val useLanCache: Boolean = false,
    private var maxDownloads: Int = 8,
    private var maxDecompress: Int = 8,
    private var maxFileWrites: Int = 1,
    private val androidEmulation: Boolean = false,
    private val parentJob: Job? = null,
) : Closeable {

    companion object {
        const val INVALID_APP_ID: Int = Int.MAX_VALUE
        const val INVALID_DEPOT_ID: Int = Int.MAX_VALUE
        const val INVALID_MANIFEST_ID: Long = Long.MAX_VALUE

        const val CONFIG_DIR: String = ".DepotDownloader"
        const val DEFAULT_BRANCH: String = "public"
        const val DEFAULT_DOWNLOAD_DIR: String = "depots"

        val STAGING_DIR: Path = CONFIG_DIR.toPath() / "staging"

        private val SupportedWorkshopFileTypes: Set<EWorkshopFileType> = setOf(
            EWorkshopFileType.Community,
            EWorkshopFileType.Art,
            EWorkshopFileType.Screenshot,
            EWorkshopFileType.Merch,
            EWorkshopFileType.IntegratedGuide,
            EWorkshopFileType.ControllerBinding,
        )
    }

    private val completionFuture = CompletableFuture<Void>()

    private val filesystem: FileSystem by lazy { FileSystem.SYSTEM }

    private val httpClient: HttpClient by lazy { HttpClient(maxConnections = maxDownloads) }

    private val listeners = CopyOnWriteArrayList<IDownloadListener>()

    private val progressUpdateInterval = 500L // ms

    /**
     * Куски, которые в этой игре встречаются больше одного раза (Steam хранит одинаковые
     * блоки один раз, но в манифесте они перечислены у каждого файла). Только такие
     * куски имеет смысл держать в памяти — остальные скачиваются ровно один раз.
     * Храним не текстовый номер, а число: на больших играх кусков сотни тысяч.
     */
    private val repeatedChunkIds = ConcurrentHashMap.newKeySet<Long>()

    /** Короткий числовой ключ куска — первые 8 байт его номера. */
    private fun chunkKey(id: ByteArray?): Long {
        if (id == null || id.size < 8) return 0L
        var v = 0L
        for (i in 0 until 8) {
            v = (v shl 8) or (id[i].toLong() and 0xFF)
        }
        return v
    }

    /** Ограниченный по объёму склад уже скачанных повторяющихся кусков (сжатые байты). */
    private val chunkCacheMaxBytes =
        minOf(16L * 1024 * 1024, Runtime.getRuntime().maxMemory() / 32)

    private var chunkCacheBytes = 0L

    private val chunkCache = object : LinkedHashMap<String, ByteArray>(64, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, ByteArray>): Boolean {
            if (chunkCacheBytes > chunkCacheMaxBytes) {
                chunkCacheBytes -= eldest.value.size.toLong()
                return true
            }
            return false
        }
    }

    private fun cachedChunk(chunkId: String): ByteArray? = synchronized(chunkCache) {
        chunkCache[chunkId]
    }

    private fun cacheChunk(chunkId: String, data: ByteArray) {
        if (data.size > chunkCacheMaxBytes) return
        synchronized(chunkCache) {
            if (chunkCache.put(chunkId, data) == null) {
                chunkCacheBytes += data.size.toLong()
            }
            // подрезаем склад, если он перерос лимит
            val it = chunkCache.entries.iterator()
            while (chunkCacheBytes > chunkCacheMaxBytes && it.hasNext()) {
                val e = it.next()
                chunkCacheBytes -= e.value.size.toLong()
                it.remove()
            }
        }
    }

    private val scope: CoroutineScope = CoroutineScope(Dispatchers.IO + SupervisorJob(parentJob))

    private var cdnClientPool: CDNClientPool? = null

    private var config: Config = Config(androidEmulation = androidEmulation)

    private var logger: Logger? = null

    private var processingChannel = Channel<DownloadItem>(Channel.UNLIMITED)

    // Очередь кусков ограничена: раньше в неё разом складывались все куски игры,
    // теперь в памяти держится только небольшой запас впереди качающихся.
    private val networkChunkFlow = MutableSharedFlow<NetworkChunkItem>(
        extraBufferCapacity = (maxDownloads * 8).coerceAtLeast(64)
    )

    private val pendingChunks = AtomicInteger(0)

    /** Сигнал «последний кусок дописан» — чтобы не опрашивать счётчик в цикле. */
    private val chunksDrained = Channel<Unit>(Channel.CONFLATED)

    /** Сколько кусков сейчас скачано, но ещё не распаковано и не записано. */
    fun pendingChunkCount(): Int = pendingChunks.get()

    /** Время на кусок по каждому серверу: [сколько кусков, суммарно мс, суммарно байт]. */
    private val serverStats = ConcurrentHashMap<String, LongArray>()

    private val statChunkCounter = AtomicInteger(0)

    private fun noteServerTiming(host: String, ms: Long, bytes: Int) {
        cdnClientPool?.noteTiming(host, ms, bytes)

        val a = serverStats.getOrPut(host) { LongArray(3) }
        synchronized(a) {
            a[0]++
            a[1] += ms
            a[2] += bytes.toLong()
        }

        // Раз в 200 кусков показываем, кто из серверов тянет, а кто тормозит
        if (statChunkCounter.incrementAndGet() % 200 != 0) return

        val rows = serverStats.entries
            .filter { it.value[0] > 0 }
            .map { e ->
                val c = e.value[0]
                val avgMs = e.value[1] / c
                val kbs = if (e.value[1] > 0) e.value[2] * 1000L / e.value[1] / 1024L else 0L
                Triple(e.key, avgMs, kbs) to c
            }
            .sortedBy { it.first.second }

        val best = rows.take(4).joinToString(", ") { "${it.first.first} ${it.first.second}мс ${it.first.third}КБ/с" }
        val worst = rows.takeLast(4).joinToString(", ") { "${it.first.first} ${it.first.second}мс ${it.first.third}КБ/с" }
        logger?.debug("Серверы — быстрые: $best")
        logger?.debug("Серверы — медленные: $worst")
    }

    private fun chunkFinished() {
        if (pendingChunks.decrementAndGet() <= 0) {
            chunksDrained.trySend(Unit)
        }
    }

    private var chunkProcessingJob: Job? = null

    private var steam3: Steam3Session? = null

    private var processingItemsMap = mutableMapOf<Int, DownloadItem>()

    // region [REGION] Private data classes.

    private data class NetworkChunkItem(
        val downloadCounter: GlobalDownloadCounter,
        val depotFilesData: DepotFilesData,
        val fileStreamData: FileStreamData,
        val fileData: FileData,
        val chunk: ChunkData,
        val totalChunksForFile: Int,
    )

    @Suppress("ArrayInDataClass")
    private data class DecompressItem(
        val depot: DepotDownloadInfo,
        val depotDownloadCounter: DepotDownloadCounter,
        val downloadCounter: GlobalDownloadCounter,
        val downloaded: Int,
        val file: FileData,
        val fileStreamData: FileStreamData,
        val chunk: ChunkData,
        val chunkBuffer: ByteArray,
    )

    @Suppress("ArrayInDataClass")
    private data class FileWriteItem(
        val depot: DepotDownloadInfo,
        val depotDownloadCounter: DepotDownloadCounter,
        val downloadCounter: GlobalDownloadCounter,
        val file: FileData,
        val fileStreamData: FileStreamData,
        val chunk: ChunkData,
        val decompressed: Int,
        val decompressedBuffer: ByteArray,
    )

    private data class DirectoryResult(val success: Boolean, val installDir: Path?)

    private data class Config(
        val installPath: Path? = null,
        val betaPassword: String? = null,
        val downloadAllPlatforms: Boolean = false,
        val downloadAllArchs: Boolean = false,
        val downloadAllLanguages: Boolean = false,
        val androidEmulation: Boolean = false,
        val downloadManifestOnly: Boolean = false,
        val installToGameNameDirectory: Boolean = false,

        // Not used yet in code
        val usingFileList: Boolean = false,
        var filesToDownloadRegex: List<Regex> = emptyList(),
        var filesToDownload: HashSet<String> = hashSetOf(),
        /** Что НЕ качать: например озвучки чужих языков внутри общей части игры. */
        var filesToSkipRegex: List<Regex> = emptyList(),
        var verifyAll: Boolean = false,
    )

    // endregion

    init {
        if (debug) {
            logger = LogManager.getLogger(DepotDownloader::class.java)
        }

        steam3 = Steam3Session(steamClient, debug)

        logger?.debug("DepotDownloader launched with ${licenses.size} for account")
        licenses.forEach { license ->
            if (license.accessToken.toULong() > 0UL) {
                steam3!!.packageTokens[license.packageID] = license.accessToken
            }
        }

        // Launch the processing loop
        scope.launch {
            processItems()
        }
    }

    private fun createChunkProcessingFlow(): kotlinx.coroutines.flow.Flow<Unit> = networkChunkFlow
        .flatMapMerge(concurrency = maxDownloads) { item ->
            flow {
                try {
                    val result = downloadSteam3DepotFileChunk(
                        downloadCounter = item.downloadCounter,
                        depotFilesData = item.depotFilesData,
                        file = item.fileData,
                        fileStreamData = item.fileStreamData,
                        chunk = item.chunk
                    )
                    if (result != null) {
                        emit(result)
                    }
                } catch (e: Exception) {
                    logger?.error("Error downloading chunk: ${e.message}", e)
                }
            }.flowOn(Dispatchers.IO)
        }
        // Между этапами по умолчанию копилось до 64 готовых кусков, а каждый кусок —
        // это около мегабайта в памяти. Держим очередь короткой, но не в обрез,
        // иначе качающие потоки встают каждый раз, когда распаковка чуть отстала.
        .buffer(stageBuffer)
        .flatMapMerge(concurrency = minOf(maxDecompress, decompressThreads)) { item ->
            flow {
                try {
                    val result = processFileDecompress(item)
                    if (result != null) {
                        emit(result)
                    }
                } catch (e: Exception) {
                    logger?.error("Error decompressing chunk: ${e.message}", e)
                }
            }.flowOn(decompressDispatcher)
        }
        .buffer(stageBuffer)
        .flatMapMerge(concurrency = maxFileWrites) { item ->
            flow {
                try {
                    processFileWrites(item)
                    chunkFinished()
                    emit(Unit)
                } catch (e: Exception) {
                    logger?.error("Error writing file: ${e.message}", e)
                    chunkFinished()
                }
            }.flowOn(Dispatchers.IO)
        }

    // region [REGION] Downloading Operations

    private suspend fun processPublishedFile(
        appId: Int,
        publishedFileId: Long,
        fileUrls: MutableList<Pair<String, String>>,
        contentFileIds: MutableList<Long>,
    ) {
        val details = steam3!!.getPublishedFileDetails(appId, PublishedFileID(publishedFileId))
        val fileType = EWorkshopFileType.from(details!!.fileType)

        if (fileType == EWorkshopFileType.Collection) {
            details.childrenList.forEach { child ->
                processPublishedFile(appId, child.publishedfileid, fileUrls, contentFileIds)
            }
        } else if (SupportedWorkshopFileTypes.contains(fileType)) {
            if (details.fileUrl.isNotEmpty()) {
                fileUrls.add(Pair(details.filename, details.fileUrl))
            } else if (details.hcontentFile > 0) {
                contentFileIds.add(details.hcontentFile)
            } else {
                logger?.error("Unable to locate manifest ID for published file $publishedFileId")
            }
        } else {
            logger?.error("Published file $publishedFileId has unsupported file type $fileType. Skipping file")
        }
    }

    @Throws(IllegalStateException::class)
    private suspend fun downloadPubFile(appId: Int, publishedFileId: Long) {
        val fileUrls = mutableListOf<Pair<String, String>>()
        val contentFileIds = mutableListOf<Long>()

        processPublishedFile(appId, publishedFileId, fileUrls, contentFileIds)

        fileUrls.forEach { item ->
            downloadWebFile(appId, item.first, item.second)
        }

        if (contentFileIds.isNotEmpty()) {
            val depotManifestIds = contentFileIds.map { id -> appId to id }
            downloadApp(
                appId = appId,
                depotManifestIds = depotManifestIds,
                branch = DEFAULT_BRANCH,
                os = null,
                arch = null,
                language = null,
                lv = false,
                isUgc = true
            )
        }
    }

    private suspend fun downloadUGC(
        appId: Int,
        ugcId: Long,
    ) {
        var details: UGCDetailsCallback? = null

        val steamUser = requireNotNull(steam3!!.steamUser)
        val steamId = requireNotNull(steamUser.steamID)

        if (steamId.accountType != EAccountType.AnonUser) {
            val ugcHandle = UGCHandle(ugcId)
            details = steam3!!.getUGCDetails(ugcHandle)
        } else {
            logger?.error("Unable to query UGC details for $ugcId from an anonymous account")
        }

        if (!details?.url.isNullOrBlank()) {
            downloadWebFile(appId = appId, fileName = details.fileName, url = details.url)
        } else {
            downloadApp(
                appId = appId,
                depotManifestIds = listOf(appId to ugcId),
                branch = DEFAULT_BRANCH,
                os = null,
                arch = null,
                language = null,
                lv = false,
                isUgc = true,
            )
        }
    }

    @Throws(IllegalStateException::class, IOException::class)
    private suspend fun downloadWebFile(appId: Int, fileName: String, url: String) {
        val (success, installDir) = createDirectories(appId, 0, appId)

        if (!success) {
            logger?.error("Error: Unable to create install directories!")
            return
        }

        val stagingDir = installDir!! / "staging"
        val fileStagingPath = stagingDir / fileName
        val fileFinalPath = installDir / fileName

        filesystem.createDirectories(fileFinalPath.parent!!)
        filesystem.createDirectories(fileStagingPath.parent!!)

        httpClient.getClient().use { client ->
            logger?.debug("Starting download of $fileName...")

            val response = client.get(url)
            val channel = response.bodyAsChannel()

            val totalBytes = response.headers[HttpHeaders.ContentLength]?.toLongOrNull()

            logger?.debug("File size: ${totalBytes?.let { Util.formatBytes(it) } ?: "Unknown"}")

            filesystem.sink(fileStagingPath).buffer().use { sink ->
                val buffer = Buffer()
                val tempArray = ByteArray(DEFAULT_BUFFER_SIZE)

                while (!channel.isClosedForRead) {
                    val packet = channel.readRemaining(DEFAULT_BUFFER_SIZE.toLong())
                    if (!packet.exhausted()) {
                        val bytesRead = packet.readAvailable(tempArray, 0, tempArray.size)
                        if (bytesRead > 0) {
                            buffer.write(tempArray, 0, bytesRead)
                            sink.writeAll(buffer)
                        }
                    }
                }
            }

            logger?.debug("Download completed.")
        }

        if (filesystem.exists(fileFinalPath)) {
            logger?.debug("Deleting $fileFinalPath")
            filesystem.delete(fileFinalPath)
        }

        try {
            filesystem.atomicMove(fileStagingPath, fileFinalPath)
            logger?.debug("File '$fileStagingPath' moved to final location: $fileFinalPath")
        } catch (e: IOException) {
            logger?.error("Failed to move files", e)
            throw e
        }
    }

    // L4D2 (app) supports LV
    @Throws(IllegalStateException::class, DepotDownloaderException::class)
    private suspend fun downloadApp(
        appId: Int,
        depotManifestIds: List<Pair<Int, Long>>,
        branch: String,
        os: String?,
        arch: String?,
        language: String?,
        lv: Boolean,
        isUgc: Boolean,
    ) {
        var depotManifestIds = depotManifestIds.toMutableList()

        val steamUser = requireNotNull(steam3!!.steamUser)
        cdnClientPool = CDNClientPool(steam3!!, appId, scope, debug)

        // Load our configuration data containing the depots currently installed
        var configPath = config.installPath
        if (configPath == null) {
            configPath = DEFAULT_DOWNLOAD_DIR.toPath()
        }

        filesystem.createDirectories(configPath)
        DepotConfigStore.loadFromFile(configPath / CONFIG_DIR / "depot.config")
        DepotProgressStore.loadFromFile(configPath / CONFIG_DIR / "dsl_progress.json")

        if (config.verifyAll) {
            // Полная проверка: забываем список «уже готово», иначе проверять будет нечего
            DepotProgressStore.forgetAll()
            notifyListeners {
                it.onStatusUpdate("Проверяю все файлы игры: беру свежую опись у Steam и сверяю каждый файл")
            }
        } else if (DepotProgressStore.lastRunWasDirty) {
            notifyListeners {
                it.onStatusUpdate("Прошлый раз загрузка оборвалась — сверяю файлы на диске заново")
            }
        }

        steam3!!.requestAppInfo(appId)

        if (!accountHasAccess(appId, appId)) {
            if (steamUser.steamID!!.accountType != EAccountType.AnonUser && steam3!!.requestFreeAppLicense(appId)) {
                logger?.debug("Obtained FreeOnDemand license for app $appId")

                // Fetch app info again in case we didn't get it fully without a license.
                steam3!!.requestAppInfo(appId, true)
            } else {
                val contentName = getAppName(appId)
                throw DepotDownloaderException("App $appId ($contentName) is not available from this account.")
            }
        }

        val hasSpecificDepots = depotManifestIds.isNotEmpty()
        val depotIdsFound = mutableListOf<Int>()
        val depotIdsExpected = depotManifestIds.map { x -> x.first }.toMutableList()
        val depots = getSteam3AppSection(appId, EAppInfoSection.Depots)

        if (isUgc) {
            val workshopDepot = depots!!["workshopdepot"].asInteger()
            if (workshopDepot != 0 && !depotIdsExpected.contains(workshopDepot)) {
                depotIdsExpected.add(workshopDepot)
                depotManifestIds = depotManifestIds.map { pair -> workshopDepot to pair.second }.toMutableList()
            }

            depotIdsFound.addAll(depotIdsExpected)
        } else {
            logger?.debug("Using app branch: $branch")

            depots?.children?.forEach { depotSection ->
                if (depotSection.children.isEmpty()) {
                    return@forEach
                }

                val id: Int = depotSection.name?.toIntOrNull() ?: return@forEach

                if (hasSpecificDepots && !depotIdsExpected.contains(id)) {
                    return@forEach
                }

                if (!hasSpecificDepots) {
                    val depotConfig = depotSection["config"]
                    if (depotConfig != KeyValue.INVALID) {
                        if (!config.downloadAllPlatforms &&
                            depotConfig["oslist"] != KeyValue.INVALID &&
                            !depotConfig["oslist"].value.isNullOrBlank()
                        ) {
                            val osList = depotConfig["oslist"].value!!.split(",")
                            if (osList.indexOf(os ?: Util.getSteamOS(config.androidEmulation)) == -1) {
                                return@forEach
                            }
                        }

                        if (!config.downloadAllArchs &&
                            depotConfig["osarch"] != KeyValue.INVALID &&
                            !depotConfig["osarch"].value.isNullOrBlank()
                        ) {
                            val depotArch = depotConfig["osarch"].value
                            if (depotArch != (arch ?: Util.getSteamArch())) {
                                return@forEach
                            }
                        }

                        if (!config.downloadAllLanguages &&
                            depotConfig["language"] != KeyValue.INVALID &&
                            !depotConfig["language"].value.isNullOrBlank()
                        ) {
                            val depotLang = depotConfig["language"].value
                            if (depotLang != (language ?: "english")) {
                                return@forEach
                            }
                        }

                        if (!lv &&
                            depotConfig["lowviolence"] != KeyValue.INVALID &&
                            depotConfig["lowviolence"].asBoolean()
                        ) {
                            return@forEach
                        }
                    }
                }

                depotIdsFound.add(id)

                if (!hasSpecificDepots) {
                    depotManifestIds.add(id to INVALID_MANIFEST_ID)
                }
            }

            if (depotManifestIds.isEmpty() && !hasSpecificDepots) {
                throw DepotDownloaderException("Couldn't find any depots to download for app $appId")
            }

            if (depotIdsFound.size < depotIdsExpected.size) {
                val remainingDepotIds = depotIdsExpected.subtract(depotIdsFound.toSet())
                throw DepotDownloaderException("Depot ${remainingDepotIds.joinToString(", ")} not listed for app $appId")
            }
        }

        val infos = mutableListOf<DepotDownloadInfo>()

        depotManifestIds.forEach { (depotId, manifestId) ->
            val info = getDepotInfo(depotId, appId, manifestId, branch)
            if (info != null) {
                infos.add(info)
            }
        }

        downloadSteam3(appId, infos)
    }

    @Throws(IllegalStateException::class)
    private suspend fun getDepotInfo(
        depotId: Int,
        appId: Int,
        manifestId: Long,
        branch: String,
    ): DepotDownloadInfo? {
        var manifestId = manifestId
        var branch = branch

        if (appId != INVALID_APP_ID) {
            steam3!!.requestAppInfo(appId)
        }

        if (!accountHasAccess(appId, depotId)) {
            logger?.error("Depot $depotId is not available from this account.")
            return null
        }

        if (manifestId == INVALID_MANIFEST_ID) {
            manifestId = getSteam3DepotManifest(depotId, appId, branch)

            if (manifestId == INVALID_MANIFEST_ID && !branch.equals(DEFAULT_BRANCH, true)) {
                logger?.error("Warning: Depot $depotId does not have branch named \"$branch\". Trying $DEFAULT_BRANCH branch.")
                branch = DEFAULT_BRANCH
                manifestId = getSteam3DepotManifest(depotId, appId, branch)
            }

            if (manifestId == INVALID_MANIFEST_ID) {
                logger?.error("Depot $depotId missing public subsection or manifest section.")
                return null
            }
        }

        steam3!!.requestDepotKey(depotId, appId)

        val depotKey = steam3!!.depotKeys[depotId]
        if (depotKey == null) {
            logger?.error("No valid depot key for $depotId, unable to download.")
            return null
        }

        val uVersion = getSteam3AppBuildNumber(appId, branch)

        val (success, installDir) = createDirectories(depotId, uVersion, appId)
        if (!success) {
            logger?.error("Error: Unable to create install directories!")
            return null
        }

        // For depots that are proxied through depotfromapp, we still need to resolve the proxy app id, unless the app is freetodownload
        var containingAppId = appId
        val proxyAppId = getSteam3DepotProxyAppId(depotId, appId)
        if (proxyAppId != INVALID_APP_ID) {
            val common = getSteam3AppSection(appId, EAppInfoSection.Common)
            if (common == null || !common["FreeToDownload"].asBoolean()) {
                containingAppId = proxyAppId
            }
        }

        return DepotDownloadInfo(
            depotId = depotId,
            appId = containingAppId,
            manifestId = manifestId,
            branch = branch,
            installDir = installDir!!,
            depotKey = depotKey
        )
    }

    private suspend fun getSteam3DepotManifest(
        depotId: Int,
        appId: Int,
        branch: String,
    ): Long {
        val depots = getSteam3AppSection(appId, EAppInfoSection.Depots)
        var depotChild = depots?.get(depotId.toString()) ?: KeyValue.INVALID

        if (depotChild == KeyValue.INVALID) {
            return INVALID_MANIFEST_ID
        }

        // Shared depots can either provide manifests, or leave you relying on their parent app.
        // It seems that with the latter, "sharedinstall" will exist (and equals 2 in the one existance I know of).
        // Rather than relay on the unknown sharedinstall key, just look for manifests. Test cases: 111710, 346680.
        if (depotChild["manifests"] == KeyValue.INVALID && depotChild["depotfromapp"] != KeyValue.INVALID) {
            val otherAppId = depotChild["depotfromapp"].asInteger()
            if (otherAppId == appId) {
                // This shouldn't ever happen, but ya never know with Valve. Don't infinite loop.
                logger?.error("App $appId, Depot $depotId has depotfromapp of $otherAppId!")
                return INVALID_MANIFEST_ID
            }

            steam3!!.requestAppInfo(otherAppId)

            return getSteam3DepotManifest(depotId, otherAppId, branch)
        }

        var manifests = depotChild["manifests"]

        if (manifests.children.isEmpty()) {
            return INVALID_MANIFEST_ID
        }

        var node = manifests[branch]["gid"]

        // Non passworded branch, found the manifest
        if (node.value != null) {
            return node.value!!.toLong()
        }

        // If we requested public branch, and it had no manifest, nothing to do
        if (branch.equals(DEFAULT_BRANCH, true)) {
            return INVALID_MANIFEST_ID
        }

        // Either the branch just doesn't exist, or it has a password
        if (config.betaPassword.isNullOrBlank()) {
            logger?.error("Branch $branch for depot $depotId was not found, either it does not exist or it has a password.")
            return INVALID_MANIFEST_ID
        }

        if (!steam3!!.appBetaPasswords.containsKey(branch)) {
            // Submit the password to Steam now to get encryption keys
            steam3!!.checkAppBetaPassword(appId, config.betaPassword!!)

            if (!steam3!!.appBetaPasswords.containsKey(branch)) {
                logger?.error("Error: Password was invalid for branch $branch (or the branch does not exist)")
                return INVALID_MANIFEST_ID
            }
        }

        // Got the password, request private depot section
        // TODO: (SK) We're probably repeating this request for every depot?
        val privateDepotSection = steam3!!.getPrivateBetaDepotSection(appId, branch)

        // Now repeat the same code to get the manifest gid from depot section
        depotChild = privateDepotSection[depotId.toString()]

        if (depotChild == KeyValue.INVALID) {
            return INVALID_MANIFEST_ID
        }

        manifests = depotChild["manifests"]

        if (manifests.children.isEmpty()) {
            return INVALID_MANIFEST_ID
        }

        node = manifests[branch]["gid"]

        if (node.value == null) {
            return INVALID_MANIFEST_ID
        }

        return node.value!!.toLong()
    }

    private fun getSteam3AppBuildNumber(appId: Int, branch: String): Int {
        if (appId == INVALID_APP_ID) {
            return 0
        }

        val depots = getSteam3AppSection(appId, EAppInfoSection.Depots) ?: KeyValue.INVALID
        val branches = depots["branches"]
        val node = branches[branch]

        if (node == KeyValue.INVALID) {
            return 0
        }

        val buildId = node["buildid"]

        if (buildId == KeyValue.INVALID) {
            return 0
        }

        return buildId.value!!.toInt()
    }

    private fun getSteam3DepotProxyAppId(depotId: Int, appId: Int): Int {
        val depots = getSteam3AppSection(appId, EAppInfoSection.Depots) ?: KeyValue.INVALID
        val depotChild = depots[depotId.toString()]

        if (depotChild == KeyValue.INVALID) {
            return INVALID_APP_ID
        }

        if (depotChild["depotfromapp"] == KeyValue.INVALID) {
            return INVALID_APP_ID
        }

        return depotChild["depotfromapp"].asInteger()
    }

    @Throws(IllegalStateException::class, IOException::class)
    private fun createDirectories(depotId: Int, depotVersion: Int, appId: Int = 0): DirectoryResult {
        var installDir: Path?
        try {
            if (config.installPath?.toString().isNullOrBlank()) {
                // Android Check
                if (SystemUtils.IS_OS_ANDROID) {
                    // This should propagate up to the caller.
                    throw IllegalStateException("Android must have an installation directory set.")
                }

                filesystem.createDirectories(DEFAULT_DOWNLOAD_DIR.toPath())

                if (config.installToGameNameDirectory) {
                    val info = getSteam3AppSection(appId, EAppInfoSection.Config) ?: KeyValue.INVALID
                    val appInstallDir = info["installdir"].asString()

                    if (appInstallDir.isNullOrBlank()) {
                        throw IOException("Config install directory is blank, cannot create directory")
                    }

                    installDir = DEFAULT_DOWNLOAD_DIR.toPath() / appInstallDir

                    filesystem.createDirectories(installDir)
                } else {
                    val depotPath = DEFAULT_DOWNLOAD_DIR.toPath() / depotId.toString()
                    filesystem.createDirectories(depotPath)

                    installDir = depotPath / depotVersion.toString()
                    filesystem.createDirectories(installDir)
                }

                filesystem.createDirectories(installDir / CONFIG_DIR)
                filesystem.createDirectories(installDir / STAGING_DIR)
            } else {
                filesystem.createDirectories(config.installPath!!)

                if (config.installToGameNameDirectory) {
                    val info = getSteam3AppSection(appId, EAppInfoSection.Config) ?: KeyValue.INVALID
                    val appInstallDir = info["installdir"].asString()

                    if (appInstallDir.isNullOrBlank()) {
                        throw IOException("Config install directory is blank, cannot create directory")
                    }

                    installDir = config.installPath!! / appInstallDir

                    filesystem.createDirectories(installDir)
                } else {
                    installDir = config.installPath!!
                }

                filesystem.createDirectories(installDir / CONFIG_DIR)
                filesystem.createDirectories(installDir / STAGING_DIR)
            }
        } catch (e: IOException) {
            logger?.error("Failed to create directory for depot $depotId, app $appId", e)
            return DirectoryResult(false, null)
        }

        return DirectoryResult(true, installDir)
    }

    private fun getAppName(appId: Int): String {
        val info = getSteam3AppSection(appId, EAppInfoSection.Common) ?: KeyValue.INVALID
        return info["name"].asString() ?: ""
    }

    private fun getSteam3AppSection(appId: Int, section: EAppInfoSection): KeyValue? {
        if (steam3 == null) {
            return null
        }

        if (steam3!!.appInfo.isEmpty()) {
            return null
        }

        val app = steam3!!.appInfo[appId]?.value ?: return null

        val appInfo = app.keyValues
        val sectionKey = when (section) {
            EAppInfoSection.Common -> "common"
            EAppInfoSection.Extended -> "extended"
            EAppInfoSection.Config -> "config"
            EAppInfoSection.Depots -> "depots"
            else -> throw DepotDownloaderException("${section.name} not implemented")
        }

        val sectionKV = appInfo.children.firstOrNull { c -> c.name == sectionKey }
        return sectionKV
    }

    /**
     * Что доступно аккаунту: собираем один раз и дальше только смотрим в готовые списки.
     * Раньше на каждую часть игры заново разбирались все лицензии — на большой библиотеке
     * это заметно тормозило старт.
     */
    private val ownedIdsMutex = Mutex()

    private var ownedIdsLoaded = false

    private val ownedIds = HashSet<Int>()

    private suspend fun ensureOwnedIds() {
        if (ownedIdsLoaded) return

        ownedIdsMutex.withLock {
            if (ownedIdsLoaded) return

            val steamUser = requireNotNull(steam3!!.steamUser)
            val steamID = requireNotNull(steamUser.steamID)

            val licenseQuery = arrayListOf<Int>()
            if (steamID.accountType == EAccountType.AnonUser) {
                licenseQuery.add(17906)
            } else {
                licenseQuery.addAll(licenses.map { it.packageID }.distinct())
            }

            steam3!!.requestPackageInfo(licenseQuery)

            licenseQuery.forEach { license ->
                steam3!!.packageInfo[license]?.value?.let { pkg ->
                    pkg.keyValues["appids"].children.forEach { ownedIds.add(it.asInteger()) }
                    pkg.keyValues["depotids"].children.forEach { ownedIds.add(it.asInteger()) }
                }
            }

            ownedIdsLoaded = true
            logger?.debug("Account owns ${ownedIds.size} app/depot ids")
        }
    }

    private suspend fun accountHasAccess(appId: Int, depotId: Int): Boolean {
        val steamUser = requireNotNull(steam3!!.steamUser)
        val steamID = requireNotNull(steamUser.steamID)

        if (licenses.isEmpty() && steamID.accountType != EAccountType.AnonUser) {
            return false
        }

        ensureOwnedIds()

        if (depotId in ownedIds) {
            return true
        }

        // Check if this app is free to download without a license
        val info = getSteam3AppSection(appId, EAppInfoSection.Common)

        return info != null && info["FreeToDownload"].asBoolean()
    }

    /**
     * Перед массовой качкой проверяем по одному куску на каждую часть игры: не все серверы
     * раздают все части. Отказавшие сразу попадают в чёрный список, поэтому в начале загрузки
     * не будет вала неудачных запросов. Скачанный при проверке кусок не выбрасывается —
     * он кладётся в память и потом берётся оттуда.
     */
    private suspend fun probeDepotServers(depotsToDownload: List<DepotFilesData>): Unit = coroutineScope {
        val pool = cdnClientPool ?: return@coroutineScope

        depotsToDownload.map { data ->
            async {
                val depot = data.depotDownloadInfo
                val chunk = data.filteredFiles
                    .firstOrNull { !it.flags.contains(EDepotFileFlag.Directory) && it.chunks.isNotEmpty() }
                    ?.chunks?.firstOrNull() ?: return@async

                val chunkIdBytes = chunk.chunkID ?: return@async
                val chunkId = Strings.toHex(chunkIdBytes)

                var tries = 0
                while (tries < 5) {
                    tries++
                    ensureActive()

                    val server = try {
                        pool.getConnection(depot.depotId)
                    } catch (e: Exception) {
                        return@async
                    }

                    try {
                        var cdnToken: String? = null
                        steam3!!.cdnAuthTokens[depot.depotId to server.host]?.let { promise ->
                            try {
                                cdnToken = promise.await().token
                            } catch (e: Exception) {
                                // без токена тоже пробуем
                            }
                        }

                        val buffer = ByteArray(chunk.compressedLength)
                        pool.cdnClient!!.downloadDepotChunk(
                            depotId = depot.depotId,
                            chunk = chunk,
                            server = server,
                            destination = buffer,
                            depotKey = depot.depotKey,
                            proxyServer = pool.proxyServer,
                            cdnAuthToken = cdnToken,
                        )

                        // сервер годится; кусок пригодится дальше — не качаем его второй раз
                        repeatedChunkIds.add(chunkKey(chunkIdBytes))
                        cacheChunk(chunkId, buffer)

                        logger?.debug("Depot ${depot.depotId} will download from ${server.host}")
                        return@async
                    } catch (e: SteamKitWebRequestException) {
                        if (e.statusCode == 403) {
                            val hadToken = steam3!!.cdnAuthTokens.containsKey(depot.depotId to server.host)
                            if (hadToken) {
                                // пропуск был, а сервер всё равно отказал — он не раздаёт эту часть
                                pool.blacklistForDepot(depot.depotId, server)
                            } else {
                                // возможно, просто не было пропуска — запрашиваем и пробуем дальше
                                steam3!!.requestCDNAuthToken(depot.appId, depot.depotId, server)
                            }
                            continue
                        }
                        return@async
                    } catch (e: CancellationException) {
                        return@async
                    } catch (e: Exception) {
                        return@async
                    }
                }
            }
        }.awaitAll()
    }

    /**
     * Распаковка держит на КАЖДОМ потоке, который её выполнял, буфер окна в 8 МБ
     * и больше его не отдаёт. Потоки у загрузки и распаковки общие, их бывает
     * несколько десятков — так и набиралась вся память телефона.
     * Поэтому распаковываем только на двух своих потоках: два буфера вместо тридцати.
     */
    /** Не качать файлы, подходящие под этот образец (например чужие озвучки). */
    fun setSkipPattern(pattern: String?) {
        config = if (pattern.isNullOrEmpty()) {
            config.copy(filesToSkipRegex = emptyList())
        } else {
            config.copy(filesToSkipRegex = listOf(Regex(pattern)))
        }
    }

    private var blazing = false

    /** Предельный режим: больше потоков распаковки и длиннее очереди, ценой памяти и процессора. */
    fun setSpeedMode(mode: String?) {
        blazing = mode == "blazing"
    }

    /** Новое задание поверх уже лежащих файлов — сверить их перед скачиванием. */
    private var checkExisting = false

    fun setCheckExisting(value: Boolean) {
        checkExisting = value
    }

    /**
     * Распаковка держит на каждом своём потоке буфер окна в 8 МБ, поэтому потоков должно быть
     * немного — но и двух мало: тридцать качающих потоков упираются в них и загрузка дёргается.
     * Считаем лениво, уже зная выбранный режим.
     */
    private val decompressThreads: Int by lazy {
        val cores = Runtime.getRuntime().availableProcessors()
        val heapMb = Runtime.getRuntime().maxMemory() / (1024 * 1024)
        val byHeap = ((heapMb - 160) / 16).toInt()
        val want = if (blazing) cores else maxOf(2, cores / 2)
        val n = minOf(if (blazing) 10 else 6, maxOf(2, minOf(want, byHeap)))
        logger?.debug("Потоков распаковки: $n (ядер $cores, память $heapMb МБ, предельный режим $blazing)")
        n
    }

    /** Сколько готовых кусков разрешаем копить между этапами. */
    private val stageBuffer: Int
        get() = if (blazing) 8 else 4

    private val decompressExecutor: java.util.concurrent.ExecutorService by lazy {
        java.util.concurrent.Executors.newFixedThreadPool(decompressThreads) { r ->
            Thread(r, "dsl-unzip").apply { isDaemon = true }
        }
    }

    @Volatile
    private var decompressStarted = false

    @Volatile
    private var decompressDispatcherRef: kotlinx.coroutines.CoroutineDispatcher? = null

    /** Создаём пул распаковки при первом обращении — к этому моменту режим уже известен. */
    private val decompressDispatcher: kotlinx.coroutines.CoroutineDispatcher
        get() {
            decompressDispatcherRef?.let { return it }
            synchronized(this) {
                decompressDispatcherRef?.let { return it }
                val made: kotlinx.coroutines.CoroutineDispatcher =
                    decompressExecutor.asCoroutineDispatcher()
                decompressStarted = true
                decompressDispatcherRef = made
                return made
            }
        }

    private var lastSkipNotify = 0L

    /** Счётчики для итоговой проверки: было на месте / докачано / не удалось. */
    private val statFilesOk = AtomicInteger(0)

    private val statFilesFetched = AtomicInteger(0)

    private val statFilesMissing = AtomicInteger(0)

    /** Сколько файлов реально прочитано с диска и сверено. */
    private val statFilesChecked = AtomicInteger(0)

    /**
     * Файл уже лежит на диске и качать его не нужно. Всё равно сообщаем прогресс,
     * иначе полоса показывает только скачанное в этот заход, а не готовность всей игры.
     * Сообщаем не чаще пяти раз в секунду — файлов могут быть тысячи.
     */
    private fun notifyAlreadyHave(depot: DepotDownloadInfo, depotCounter: DepotDownloadCounter, fileName: String) {
        statFilesOk.incrementAndGet()

        val now = System.currentTimeMillis()
        synchronized(this) {
            if (now - lastSkipNotify < 200L) return
            lastSkipNotify = now
        }

        val total = depotCounter.completeDownloadSize
        if (total <= 0L) return

        val pct = depotCounter.sizeDownloaded.toFloat() / total
        notifyListeners { it.onFileCompleted(depot.depotId, fileName, pct) }
    }

    /**
     * Заранее посчитанные результаты сверки: какие куски файла надо докачать.
     * Пустой список — файл на диске целый. Ключ: номер части игры и имя файла.
     */
    private val checkPlan = ConcurrentHashMap<String, List<ChunkData>>()

    private fun planKey(depotId: Int, fileName: String) = "$depotId|$fileName"

    /** Что именно сверяем: часть игры и файл в ней. */
    private class CheckTarget(val depot: DepotDownloadInfo, val file: FileData)

    /**
     * ФАЗА 1 — сверка. Полностью проходим по файлам на диске и сравниваем их
     * с описью, полученной от Steam, ничего при этом не скачивая.
     * Только после этого начинается докачка недостающего — как в Steam на компьютере.
     */
    private suspend fun runCheckPass(depotsToDownload: List<DepotFilesData>): Unit = coroutineScope {
        val candidates = mutableListOf<CheckTarget>()

        depotsToDownload.forEach { data ->
            val depot = data.depotDownloadInfo
            data.filteredFiles.forEach { file ->
                if (file.flags.contains(EDepotFileFlag.Directory)) return@forEach
                val path = depot.installDir / file.fileName
                if (!filesystem.exists(path)) return@forEach
                val size = try {
                    filesystem.metadata(path).size ?: -1L
                } catch (e: Exception) {
                    -1L
                }
                // файлы неверного размера пусть разбирает обычный путь
                if (size == file.totalSize) {
                    candidates.add(CheckTarget(depot, file))
                }
            }
        }

        if (candidates.isEmpty()) {
            notifyListeners { it.onStatusUpdate("Проверять нечего: файлов игры на диске нет") }
            return@coroutineScope
        }

        notifyListeners { it.onStatusUpdate("Сверяю файлы на диске: 0 из ${candidates.size}") }

        val done = AtomicInteger(0)
        val broken = AtomicInteger(0)
        val gate = kotlinx.coroutines.sync.Semaphore(2)

        candidates.map { target ->
            async {
                gate.withPermit {
                    ensureActive()

                    val depot = target.depot
                    val file = target.file
                    val path = depot.installDir / file.fileName

                    // Главная проверка — SHA-1 всего файла из описи Steam. Это то же самое,
                    // чем Steam на компьютере решает, целый файл или нет.
                    var hashOk = false
                    if (file.fileHash != null && file.fileHash.isNotEmpty()) {
                        hashOk = try {
                            Util.fileSHAHash(path).contentEquals(file.fileHash)
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            false
                        }
                    }

                    var planned: List<ChunkData>? = null

                    if (hashOk) {
                        val nothingNeeded: List<ChunkData> = mutableListOf()
                        planned = nothingNeeded
                    } else {
                        // Файл не совпал целиком — ищем, каких именно кусков не хватает
                        var needed: List<ChunkData>? = null
                        try {
                            filesystem.openReadOnly(path).use { handle ->
                                needed = Util.validateSteam3FileChecksums(
                                    handle = handle,
                                    chunkData = file.chunks.sortedBy { it.offset }
                                )
                            }
                        } catch (e: CancellationException) {
                            throw e
                        } catch (e: Exception) {
                            logger?.error("Не смог проверить ${file.fileName}: ${e.message}")
                        }

                        val found: List<ChunkData>? = needed
                        if (found != null && found.isEmpty()) {
                            // Куски сошлись, а файл целиком — нет. Доверять кускам тут нельзя.
                            logger?.error(
                                "Расхождение по ${file.fileName}: куски совпали, а SHA-1 файла — нет"
                            )
                            val allChunks = mutableListOf<ChunkData>()
                            allChunks.addAll(file.chunks)
                            planned = allChunks
                        } else {
                            planned = found
                        }
                    }

                    val toStore: List<ChunkData>? = planned
                    if (toStore != null) {
                        checkPlan[planKey(depot.depotId, file.fileName)] = toStore
                        statFilesChecked.incrementAndGet()
                        if (toStore.isNotEmpty()) {
                            broken.incrementAndGet()
                        }
                    }

                    val n = done.incrementAndGet()
                    if (n % 20 == 0 || n == candidates.size) {
                        logger?.debug("Сверка: проверено $n из ${candidates.size}, требуют докачки ${broken.get()}")
                        notifyListeners {
                            it.onStatusUpdate("Сверка: $n из ${candidates.size} файлов")
                        }
                    }
                }
            }
        }.awaitAll()

        // Файлы, которых на диске нет совсем или размер не тот — их тоже надо назвать
        var absent = 0
        var absentBytes = 0L
        depotsToDownload.forEach { data ->
            val depot = data.depotDownloadInfo
            data.filteredFiles.forEach { f ->
                if (f.flags.contains(EDepotFileFlag.Directory)) return@forEach
                if (checkPlan.containsKey(planKey(depot.depotId, f.fileName))) return@forEach
                absent++
                absentBytes += f.totalSize
            }
        }

        var brokenBytes = 0L
        checkPlan.values.forEach { list -> list.forEach { brokenBytes += it.uncompressedLength.toLong() } }

        val intact = candidates.size - broken.get()
        val verdict = if (broken.get() == 0 && absent == 0) {
            "Сверка закончена: игра целая, все $intact файлов совпали с описью Steam"
        } else {
            "Сверка закончена: целых файлов $intact, повреждено или недокачано ${broken.get()}, " +
                "нет на диске $absent. Докачать надо примерно " +
                "${(brokenBytes + absentBytes) / (1024L * 1024L)} МБ"
        }

        logger?.debug(verdict)
        notifyListeners { it.onStatusUpdate(verdict) }
    }

    private suspend fun downloadSteam3(mainAppId: Int, depots: List<DepotDownloadInfo>): Unit = coroutineScope {
        val maxNumServers = maxDownloads.coerceIn(20, 64) // Hard clamp at 64. Not sure how high we can go.
        cdnClientPool?.updateServerList(maxNumServers)

        val downloadCounter = GlobalDownloadCounter()
        val depotsToDownload = ArrayList<DepotFilesData>(depots.size)
        val allFileNamesAllDepots = hashSetOf<String>()

        // Списки файлов берём параллельно, но не все разом: манифест большой игры
        // занимает много памяти, и шесть штук одновременно телефон не тянет.
        val manifestGate = kotlinx.coroutines.sync.Semaphore(2)
        val manifestResults = depots.map { depot ->
            async { manifestGate.withPermit { processDepotManifestAndFiles(depot, downloadCounter) } }
        }.awaitAll()

        manifestResults.forEach { result ->
            val depotFileData: DepotFilesData = result ?: return@forEach
            depotsToDownload.add(depotFileData)
            allFileNamesAllDepots.addAll(depotFileData.allFileNames)
            ensureActive()
        }

        // If we're about to write all the files to the same directory, we will need to first de-duplicate any files by path
        // This is in last-depot-wins order, from Steam or the list of depots supplied by the user
        if (config.installPath != null && depotsToDownload.isNotEmpty()) {
            val claimedFileNames = mutableSetOf<String>()
            for (i in depotsToDownload.indices.reversed()) {
                // For each depot, remove all files from the list that have been claimed by a later depot
                depotsToDownload[i].filteredFiles.removeAll { file -> file.fileName in claimedFileNames }
                claimedFileNames.addAll(depotsToDownload[i].allFileNames)
            }
        }

        if (depotsToDownload.isEmpty()) {
            finishDepotDownload(mainAppId)
        } else {
            notifyListeners { it.onStatusUpdate("Checking download servers") }
            probeDepotServers(depotsToDownload)

            // Сверяем файлы только когда это осмысленно: по кнопке проверки или после вылета.
            // После обычной паузы просто продолжаем с того места, где встали.
            if (config.verifyAll || DepotProgressStore.lastRunWasDirty || checkExisting) {
                runCheckPass(depotsToDownload)
            }

            // Показываем, в какой именно части игры лежат озвучки — чтобы было видно,
        // приходит английская из языкового куска или из общего
        depotsToDownload.forEach { data ->
            val voices = data.filteredFiles
                .map { it.fileName.replace('\\', '/') }
                .filter { it.contains("Voices_", ignoreCase = true) || it.contains("Voice", ignoreCase = true) }
                .map { it.substringAfterLast('/') }
                .distinct()
                .take(6)
            if (voices.isNotEmpty()) {
                val id = data.depotDownloadInfo.depotId
                val msg = "Озвучки в части $id: ${voices.joinToString(", ")}"
                logger?.debug(msg)
                notifyListeners { it.onStatusUpdate(msg) }
            }
        }

        depotsToDownload.forEachIndexed { index, depotFileData ->
                downloadSteam3DepotFiles(
                    mainAppId,
                    downloadCounter,
                    depotFileData,
                    allFileNamesAllDepots,
                    index == depotsToDownload.size - 1
                )
            }
        }

        logger?.debug(
            "Total downloaded: ${downloadCounter.totalBytesCompressed} bytes " +
                "(${downloadCounter.totalBytesUncompressed} bytes uncompressed) from ${depots.size} depots"
        )

        // Понятный итог: что уже лежало на диске, что пришлось качать, чего не хватило
        val ok = statFilesOk.get()
        val fetched = statFilesFetched.get()
        val missing = statFilesMissing.get()
        val checked = statFilesChecked.get()
        notifyListeners {
            it.onStatusUpdate(
                "Итог: проверено файлов на диске $checked, уже было готово $ok, докачано $fetched" +
                    if (missing > 0) ", НЕ УДАЛОСЬ скачать $missing" else ""
            )
        }
    }

    private suspend fun processDepotManifestAndFiles(
        depot: DepotDownloadInfo,
        downloadCounter: GlobalDownloadCounter,
    ): DepotFilesData? = withContext(Dispatchers.IO) {
        val depotCounter = DepotDownloadCounter()

        logger?.debug("Processing depot ${depot.depotId}")

        var oldManifest: DepotManifest? = null

        @Suppress("VariableInitializerIsRedundant")
        var newManifest: DepotManifest? = null

        val configDir = depot.installDir / CONFIG_DIR

        @Suppress("VariableInitializerIsRedundant")
        var lastManifestId = INVALID_MANIFEST_ID
        lastManifestId = DepotConfigStore.getInstance().installedManifestIDs[depot.depotId] ?: INVALID_MANIFEST_ID

        // In case we have an early exit, this will force equiv of verifyall next run.
        DepotConfigStore.getInstance().installedManifestIDs[depot.depotId] = INVALID_MANIFEST_ID
        DepotConfigStore.save()

        if (lastManifestId != INVALID_MANIFEST_ID && !config.verifyAll) {
            // We only have to show this warning if the old manifest ID was different
            val badHashWarning = lastManifestId != depot.manifestId
            oldManifest = Util.loadManifestFromFile(configDir, depot.depotId, lastManifestId, badHashWarning)
        }

        if (lastManifestId == depot.manifestId && oldManifest != null && !config.verifyAll) {
            newManifest = oldManifest
            logger?.debug("Already have manifest ${depot.manifestId} for depot ${depot.depotId}.")
        } else {
            // При проверке опись файлов берём только у Steam — местной копии не верим,
            // иначе сверяем игру сама с собой, а не с сервером.
            newManifest = if (config.verifyAll) {
                null
            } else {
                Util.loadManifestFromFile(configDir, depot.depotId, depot.manifestId, true)
            }

            if (newManifest != null) {
                logger?.debug("Already have manifest ${depot.manifestId} for depot ${depot.depotId}.")
            } else {
                logger?.debug("Downloading depot ${depot.depotId} manifest")
                notifyListeners { it.onStatusUpdate("Downloading manifest for depot ${depot.depotId}") }

                var manifestRequestCode: ULong = 0U
                var manifestRequestCodeExpiration = Instant.MIN

                do {
                    ensureActive()

                    var connection: Server? = null

                    try {
                        connection = cdnClientPool!!.getConnection(depot.depotId)

                        var cdnToken: String? = null

                        val authTokenCallbackPromise = steam3!!.cdnAuthTokens[depot.depotId to connection.host]
                        if (authTokenCallbackPromise != null) {
                            try {
                                val result = authTokenCallbackPromise.await()
                                cdnToken = result.token
                            } catch (e: Exception) {
                                logger?.error("Failed to get CDN auth token: ${e.message}")
                            }
                        }

                        val now = Instant.now()

                        // In order to download this manifest, we need the current manifest request code
                        // The manifest request code is only valid for a specific period in time
                        if (manifestRequestCode == 0UL || now >= manifestRequestCodeExpiration) {
                            manifestRequestCode = steam3!!.getDepotManifestRequestCode(
                                depotId = depot.depotId,
                                appId = depot.appId,
                                manifestId = depot.manifestId,
                                branch = depot.branch,
                            )

                            // This code will hopefully be valid for one period following the issuing period
                            manifestRequestCodeExpiration = now.plus(5, ChronoUnit.MINUTES)

                            // If we could not get the manifest code, this is a fatal error
                            if (manifestRequestCode == 0UL) {
                                // TODO this should be a fatal error and bail out. But I guess we can continue.
                                logger?.error("Manifest request code is 0. Skipping depot ${depot.depotId}")
                                return@withContext null
                                // cancel("manifestRequestCode is 0UL")
                            }
                        }

                        logger?.debug("Downloading manifest ${depot.manifestId} from $connection with ${cdnClientPool!!.proxyServer ?: "no proxy"}")

                        newManifest = cdnClientPool!!.cdnClient!!.downloadManifest(
                            depotId = depot.depotId,
                            manifestId = depot.manifestId,
                            manifestRequestCode = manifestRequestCode,
                            server = connection,
                            depotKey = depot.depotKey,
                            proxyServer = cdnClientPool!!.proxyServer,
                            cdnAuthToken = cdnToken,
                        )

                        cdnClientPool!!.returnConnection(connection)
                    } catch (e: CancellationException) {
                        // logger?.error("Connection timeout downloading depot manifest ${depot.depotId} ${depot.manifestId}. Retrying.")
                        logger?.error("Cancellation Exception thrown in process manifest", e)
                        break
                    } catch (e: SteamKitWebRequestException) {
                        // If the CDN returned 403, attempt to get a cdn auth if we didn't yet
                        if (e.statusCode == 403 && !steam3!!.cdnAuthTokens.containsKey(depot.depotId to connection!!.host)) {
                            steam3!!.requestCDNAuthToken(depot.appId, depot.depotId, connection)

                            cdnClientPool!!.returnConnection(connection)

                            continue
                        }

                        cdnClientPool!!.returnBrokenConnection(connection)

                        // Unauthorized || Forbidden
                        if (e.statusCode == 401 || e.statusCode == 403) {
                            logger?.error("Encountered ${depot.depotId} for depot manifest ${depot.manifestId} ${e.statusCode}. Aborting.")
                            break
                        }

                        // NotFound
                        if (e.statusCode == 404) {
                            logger?.error("Encountered 404 for depot manifest ${depot.depotId} ${depot.manifestId}. Aborting.")
                            break
                        }

                        logger?.error("Encountered error downloading depot manifest ${depot.depotId} ${depot.manifestId}: ${e.statusCode}")
                    } catch (e: Exception) {
                        cdnClientPool!!.returnBrokenConnection(connection)
                        logger?.error("Encountered error downloading manifest for depot ${depot.depotId} ${depot.manifestId}: ${e.message}")
                    }
                } while (newManifest == null)

                if (newManifest == null) {
                    logger?.error("\nUnable to download manifest ${depot.manifestId} for depot ${depot.depotId}")
                    cancel()
                }

                // Throw the cancellation exception if requested so that this task is marked failed
                ensureActive()

                Util.saveManifestToFile(configDir, newManifest!!)
            }
        }

        logger?.debug("Manifest ${depot.manifestId} (${newManifest.creationTime})")

        if (config.downloadManifestOnly) {
            Util.dumpManifestToTextFile(depot, newManifest)
            return@withContext null
        }

        val stagingDir = depot.installDir / STAGING_DIR

        val filesAfterExclusions = coroutineScope {
            newManifest.files.filter { file ->
                async { testIsFileIncluded(file.fileName) }.await()
            }
        }
        val allFileNames = HashSet<String>(filesAfterExclusions.size)

        // Ищем куски, встречающиеся в этой части игры несколько раз — их скачаем один раз,
        // а остальные разы возьмём из памяти.
        val seenChunkIds = HashSet<Long>()
        filesAfterExclusions.forEach { f ->
            f.chunks.forEach { c ->
                val key = chunkKey(c.chunkID)
                if (key != 0L && !seenChunkIds.add(key)) {
                    repeatedChunkIds.add(key)
                }
            }
        }

        // Pre-process
        filesAfterExclusions.forEachIndexed { index, file ->
            if (index % 50 == 0) {
                ensureActive() // Check cancellation periodically
            }

            allFileNames.add(file.fileName)

            val fileFinalPath = depot.installDir / file.fileName
            val fileStagingPath = stagingDir / file.fileName

            if (file.flags.contains(EDepotFileFlag.Directory)) {
                filesystem.createDirectories(fileFinalPath)
                filesystem.createDirectories(fileStagingPath)
            } else {
                // Some manifests don't explicitly include all necessary directories
                filesystem.createDirectories(fileFinalPath.parent!!)
                filesystem.createDirectories(fileStagingPath.parent!!)

                synchronized(downloadCounter) {
                    downloadCounter.completeDownloadSize += file.totalSize
                }
                depotCounter.completeDownloadSize += file.totalSize
            }
        }

        // раскладываем файлы прошлой версии по именам один раз, а не ищем перебором на каждый файл
        val previousByName = HashMap<String, FileData>()
        oldManifest?.files?.forEach { previousByName[it.fileName] = it }

        return@withContext DepotFilesData(
            depotDownloadInfo = depot,
            depotCounter = depotCounter,
            stagingDir = stagingDir,
            manifest = newManifest,
            previousManifest = oldManifest,
            filteredFiles = filesAfterExclusions.toMutableList(),
            allFileNames = allFileNames,
            previousFilesByName = previousByName,
        )
    }

    @OptIn(DelicateCoroutinesApi::class)
    private suspend fun downloadSteam3DepotFiles(
        mainAppId: Int,
        downloadCounter: GlobalDownloadCounter,
        depotFilesData: DepotFilesData,
        allFileNamesAllDepots: HashSet<String>,
        isLastDepot: Boolean,
    ) = withContext(Dispatchers.IO) {
        val depot = depotFilesData.depotDownloadInfo
        val depotCounter = depotFilesData.depotCounter

        logger?.debug("Downloading depot ${depot.depotId}")

        val files = depotFilesData.filteredFiles.filter { !it.flags.contains(EDepotFileFlag.Directory) }

        // При проверке каждый файл читается целиком и считается контрольная сумма.
        // Полсотни многогигабайтных архивов разом телефон не переживает — берём по чуть-чуть.
        val batchSize = if (config.verifyAll) 4 else 16

        try {
            coroutineScope {
                // Second parallel loop - process files and enqueue chunks
                files.chunked(batchSize).forEach { batch ->
                    yield()

                    batch.map { file ->
                        async {
                            downloadSteam3DepotFile(
                                downloadCounter = downloadCounter,
                                depotFilesData = depotFilesData,
                                file = file,
                            )
                        }
                    }.awaitAll()
                }
            }
        } finally {
            if (isLastDepot) {
                logger?.debug("Waiting for ${pendingChunks.get()} pending chunks to complete for depot ${depot.depotId}")

                // Ждём последние куски по сигналу; таймаут — страховка на случай пропущенного сигнала
                while (pendingChunks.get() > 0) {
                    withTimeoutOrNull(500) { chunksDrained.receive() }
                }

                logger?.debug("All chunks completed, canceling processing job for depot ${depot.depotId}")

                // Cancel the continuous flow job since no more chunks will be added
                chunkProcessingJob?.cancel()

                logger?.debug("Canceled chunk processing job for depot ${depot.depotId}")
            }
        }

        // Check for deleted files if updating the depot.
        if (depotFilesData.previousManifest != null) {
            val previousFilteredFiles = depotFilesData.previousManifest.files
                .filter { testIsFileIncluded(it.fileName) }
                .map { it.fileName }
                .toHashSet()

            // Check if we are writing to a single output directory. If not, each depot folder is managed independently
            if (config.installPath == null) {
                // Of the list of files in the previous manifest, remove any file names that exist in the current set of all file names
                previousFilteredFiles.removeAll(depotFilesData.allFileNames)
            } else {
                // Of the list of files in the previous manifest, remove any file names that exist in the current set of all file names across all depots being downloaded
                previousFilteredFiles.removeAll(allFileNamesAllDepots)
            }

            previousFilteredFiles.forEach { existingFileName ->
                val fileFinalPath = depot.installDir / existingFileName

                if (!filesystem.exists(fileFinalPath)) {
                    return@forEach
                }

                filesystem.delete(fileFinalPath)
                logger?.debug("Deleted $fileFinalPath")
            }
        }

        DepotConfigStore.getInstance().installedManifestIDs[depot.depotId] = depot.manifestId
        DepotConfigStore.save()
        DepotProgressStore.clearDepot(depot.depotId)

        // Notify depot completion
        notifyListeners { listener ->
            listener.onDepotCompleted(
                depotId = depot.depotId,
                compressedBytes = depotCounter.depotBytesCompressed,
                uncompressedBytes = depotCounter.depotBytesUncompressed
            )
        }

        logger?.debug("Depot ${depot.depotId} - Downloaded ${depotCounter.depotBytesCompressed} bytes (${depotCounter.depotBytesUncompressed} bytes uncompressed)")

        if (isLastDepot) {
            finishDepotDownload(mainAppId)
        }
    }

    private suspend fun downloadSteam3DepotFile(
        downloadCounter: GlobalDownloadCounter,
        depotFilesData: DepotFilesData,
        file: FileData,
    ) = withContext(Dispatchers.IO) {
        ensureActive()

        val depot = depotFilesData.depotDownloadInfo
        val stagingDir = depotFilesData.stagingDir
        val depotDownloadCounter = depotFilesData.depotCounter
        val oldProtoManifest = depotFilesData.previousManifest

        var oldManifestFile: FileData? = null
        if (oldProtoManifest != null) {
            oldManifestFile = depotFilesData.previousFilesByName[file.fileName]
        }

        val fileFinalPath = depot.installDir / file.fileName
        val fileStagingPath = stagingDir / file.fileName

        // This may still exist if the previous run exited before cleanup
        if (filesystem.exists(fileStagingPath)) {
            filesystem.delete(fileStagingPath)
        }

        // Быстрое продолжение: если этот файл уже был скачан целиком в прошлый заход,
        // не перечитываем его и не пересчитываем контрольные суммы заново.
        val fileHashHex = Strings.toHex(file.fileHash)

        // Этот файл уже сверен в первой фазе — второй раз с диска его не читаем
        val planned = checkPlan[planKey(depot.depotId, file.fileName)]

        // Что уже записано на диск по нашим записям (после штатной паузы им можно верить).
        // Доверяем только если файл на месте и нужного размера — иначе пойдём обычным путём.
        val knownChunks: Set<Long>? = if (config.verifyAll) {
            null
        } else {
            val sizeOk = try {
                filesystem.exists(fileFinalPath) &&
                    filesystem.metadata(fileFinalPath).size == file.totalSize
            } catch (e: Exception) {
                false
            }
            if (sizeOk) {
                DepotProgressStore.chunksDone(depot.depotId, file.fileName, fileHashHex)
            } else {
                null
            }
        }
        if (planned != null && planned.isEmpty()) {
            synchronized(depotDownloadCounter) {
                depotDownloadCounter.sizeDownloaded += file.totalSize
            }
            synchronized(downloadCounter) {
                downloadCounter.completeDownloadSize -= file.totalSize
            }
            DepotProgressStore.markDone(depot.depotId, file.fileName, fileHashHex)
            notifyAlreadyHave(depot, depotDownloadCounter, file.fileName)
            return@withContext
        }

        // Если файл только что сверили, верим сверке, а не старым записям:
        // иначе повреждённый файл проскочит как готовый
        if (planned == null && !config.verifyAll && !checkExisting &&
            DepotProgressStore.isDone(depot.depotId, file.fileName, fileHashHex) &&
            filesystem.exists(fileFinalPath) &&
            (filesystem.metadata(fileFinalPath).size ?: -1L) == file.totalSize
        ) {
            synchronized(depotDownloadCounter) {
                depotDownloadCounter.sizeDownloaded += file.totalSize
            }
            synchronized(downloadCounter) {
                downloadCounter.completeDownloadSize -= file.totalSize
            }
            notifyAlreadyHave(depot, depotDownloadCounter, file.fileName)
            return@withContext
        }

        var neededChunks: MutableList<ChunkData>? = null
        val fileDidExist = filesystem.exists(fileFinalPath)
        if (!fileDidExist) {
            logger?.debug("Pre-allocating: $fileFinalPath")
            notifyListeners { it.onStatusUpdate("Allocating file: ${file.fileName}") }

            // create new file. need all chunks
            try {
                // okio resize can OOM for large files on android.
                RandomAccessFile(fileFinalPath.toFile(), "rw").use {
                    it.setLength(file.totalSize)
                }
            } catch (e: IOException) {
                throw DepotDownloaderException("Failed to allocate file $fileFinalPath: ${e.message}")
            }

            neededChunks = ArrayList(file.chunks)
        } else if (planned != null) {
            // Список недостающих кусков уже получен в фазе сверки — файл не перечитываем
            neededChunks = ArrayList(planned)
        } else if (knownChunks != null) {
            // После обычной паузы мы точно знаем, какие куски уже записаны,
            // поэтому ничего не перечитываем — просто добираем остальное.
            val rest = ArrayList<ChunkData>()
            file.chunks.forEach { c ->
                if (!knownChunks.contains(c.offset)) {
                    rest.add(c)
                }
            }
            neededChunks = rest
            logger?.debug("Продолжаю ${file.fileName}: осталось ${rest.size} кусков из ${file.chunks.size}")
        } else {
            // open existing
            if (oldManifestFile != null) {
                neededChunks = arrayListOf()

                val hashMatches = oldManifestFile.fileHash.contentEquals(file.fileHash)
                if (config.verifyAll || !hashMatches) {
                    // we have a version of this file, but it doesn't fully match what we want
                    if (config.verifyAll) {
                        logger?.debug("Validating: $fileFinalPath")
                    }

                    val matchingChunks = arrayListOf<ChunkMatch>()

                    file.chunks.forEach { chunk ->
                        yield()

                        val oldChunk = oldManifestFile.chunks.firstOrNull { c ->
                            c.chunkID.contentEquals(chunk.chunkID)
                        }
                        if (oldChunk != null) {
                            val chunkMatch = ChunkMatch(oldChunk, chunk)
                            matchingChunks.add(chunkMatch)
                        } else {
                            neededChunks.add(chunk)
                        }
                    }

                    val orderedChunks = matchingChunks.sortedBy { x -> x.oldChunk.offset }

                    val copyChunks = arrayListOf<ChunkMatch>()

                    filesystem.openReadOnly(fileFinalPath).use { handle ->
                        orderedChunks.forEach { match ->
                            yield()

                            // Read the chunk data into a byte array
                            val length = match.oldChunk.uncompressedLength
                            val buffer = ByteArray(length)
                            handle.read(match.oldChunk.offset, buffer, 0, length)

                            // Calculate Adler32 checksum
                            val adler = Adler32.calculate(buffer)

                            if (adler != match.oldChunk.checksum) {
                                neededChunks.add(match.newChunk)
                            } else {
                                copyChunks.add(match)
                            }
                        }
                    }

                    if (!hashMatches || neededChunks.isNotEmpty()) {
                        filesystem.atomicMove(fileFinalPath, fileStagingPath)

                        try {
                            RandomAccessFile(fileFinalPath.toFile(), "rw").use { raf ->
                                raf.setLength(file.totalSize)
                            }
                        } catch (ex: IOException) {
                            throw DepotDownloaderException(
                                "Failed to resize file to expected size $fileFinalPath: ${ex.message}"
                            )
                        }

                        filesystem.openReadOnly(fileStagingPath).use { oldHandle ->
                            filesystem.openReadWrite(fileFinalPath).use { newHandle ->
                                // okio resize can OOM for large files on android.
                                for (match in copyChunks) {
                                    ensureActive()

                                    val tmp = ByteArray(match.oldChunk.uncompressedLength)
                                    oldHandle.read(match.oldChunk.offset, tmp, 0, tmp.size)
                                    newHandle.write(match.newChunk.offset, tmp, 0, tmp.size)
                                }
                            }
                        }

                        filesystem.delete(fileStagingPath)
                    }
                }
            } else {
                // No old manifest or file not in old manifest. We must validate.
                val fileSize = filesystem.metadata(fileFinalPath).size ?: 0L
                if (fileSize.toULong() != file.totalSize.toULong()) {
                    try {
                        // okio resize can OOM for large files on android.
                        RandomAccessFile(fileFinalPath.toFile(), "rw").use { raf ->
                            raf.setLength(file.totalSize)
                        }
                    } catch (ex: IOException) {
                        throw DepotDownloaderException(
                            "Failed to allocate file $fileFinalPath: ${ex.message}"
                        )
                    }
                }

                filesystem.openReadWrite(fileFinalPath).use { handle ->
                    logger?.debug("Validating $fileFinalPath")
                    statFilesChecked.incrementAndGet()
                    notifyListeners { it.onStatusUpdate("Validating: ${file.fileName}") }

                    neededChunks = Util.validateSteam3FileChecksums(
                        handle = handle,
                        chunkData = file.chunks.sortedBy { it.offset }
                    ).toMutableList()
                }
            }

            if (neededChunks!!.isEmpty()) {
                synchronized(depotDownloadCounter) {
                    depotDownloadCounter.sizeDownloaded += file.totalSize

                    val percentage =
                        (depotDownloadCounter.sizeDownloaded / depotDownloadCounter.completeDownloadSize.toFloat()) * 100.0f
                    logger?.debug("%.2f%% %s".format(percentage, fileFinalPath))
                }

                synchronized(downloadCounter) {
                    downloadCounter.completeDownloadSize -= file.totalSize
                }

                DepotProgressStore.markDone(depot.depotId, file.fileName, fileHashHex)
                notifyAlreadyHave(depot, depotDownloadCounter, file.fileName)
                return@withContext
            }

            val sizeOnDisk = file.totalSize - neededChunks!!.sumOf { it.uncompressedLength }
            synchronized(depotDownloadCounter) {
                depotDownloadCounter.sizeDownloaded += sizeOnDisk
            }

            synchronized(downloadCounter) {
                downloadCounter.completeDownloadSize -= sizeOnDisk
            }
        }

        val fileIsExecutable = file.flags.contains(EDepotFileFlag.Executable)
        if (fileIsExecutable &&
            (!fileDidExist || oldManifestFile == null || !oldManifestFile.flags.contains(EDepotFileFlag.Executable))
        ) {
            fileFinalPath.toFile().setExecutable(true)
        } else if (!fileIsExecutable &&
            oldManifestFile != null &&
            oldManifestFile.flags.contains(EDepotFileFlag.Executable)
        ) {
            fileFinalPath.toFile().setExecutable(false)
        }

        val fileStreamData = FileStreamData(
            fileHandle = null,
            fileLock = Mutex(),
            chunksToDownload = AtomicInteger(neededChunks!!.size)
        )

        neededChunks!!.forEach { chunk ->
            pendingChunks.incrementAndGet()
            networkChunkFlow.emit(
                NetworkChunkItem(
                    downloadCounter = downloadCounter,
                    depotFilesData = depotFilesData,
                    fileStreamData = fileStreamData,
                    fileData = file,
                    chunk = chunk,
                    totalChunksForFile = neededChunks!!.size,
                )
            )
        }
    }

    private suspend fun downloadSteam3DepotFileChunk(
        downloadCounter: GlobalDownloadCounter,
        depotFilesData: DepotFilesData,
        file: FileData,
        fileStreamData: FileStreamData,
        chunk: ChunkData,
    ): DecompressItem = withContext(Dispatchers.IO) {
        ensureActive()

        val depot = depotFilesData.depotDownloadInfo
        val depotDownloadCounter = depotFilesData.depotCounter

        val chunkID = Strings.toHex(chunk.chunkID)

        val isRepeated = repeatedChunkIds.contains(chunkKey(chunk.chunkID))
        if (isRepeated) {
            val cached = cachedChunk(chunkID)
            if (cached != null && cached.size == chunk.compressedLength) {
                // такой кусок уже качали в этой игре — второй раз из сети не тянем
                return@withContext DecompressItem(
                    depot = depot,
                    depotDownloadCounter = depotDownloadCounter,
                    downloadCounter = downloadCounter,
                    downloaded = cached.size,
                    file = file,
                    fileStreamData = fileStreamData,
                    chunk = chunk,
                    chunkBuffer = cached,
                )
            }
        }

        var downloaded = 0
        val chunkBuffer = ByteArray(chunk.compressedLength)

        var forbiddenTries = 0
        val maxForbiddenTries = 8

        do {
            ensureActive()

            var connection: Server? = null

            try {
                connection = cdnClientPool?.getConnection(depot.depotId)
                    ?: throw IllegalStateException("ContentDownloader already closed")

                var cdnToken: String? = null

                val authTokenCallbackPromise = steam3!!.cdnAuthTokens[depot.depotId to connection.host]
                if (authTokenCallbackPromise != null) {
                    try {
                        val result = authTokenCallbackPromise.await()
                        cdnToken = result.token
                    } catch (e: Exception) {
                        logger?.error("Failed to get CDN auth token: ${e.message}")
                    }
                }

                logger?.debug("Downloading chunk $chunkID from $connection with ${cdnClientPool!!.proxyServer ?: "no proxy"}")

                val startedAt = System.currentTimeMillis()

                downloaded = cdnClientPool!!.cdnClient!!.downloadDepotChunk(
                    depotId = depot.depotId,
                    chunk = chunk,
                    server = connection,
                    destination = chunkBuffer,
                    depotKey = depot.depotKey,
                    proxyServer = cdnClientPool!!.proxyServer,
                    cdnAuthToken = cdnToken,
                )

                noteServerTiming(connection.host ?: "неизвестный сервер", System.currentTimeMillis() - startedAt, downloaded)

                cdnClientPool!!.returnConnection(connection)

                break
            } catch (e: CancellationException) {
                logger?.error("Cancellation exception in download depot file chunk", e)
            } catch (e: SteamKitWebRequestException) {
                // If the CDN returned 403, attempt to get a cdn auth if we didn't yet,
                // if auth task already exists, make sure it didn't complete yet, so that it gets awaited above
                if (e.statusCode == 403 &&
                    (
                        !steam3!!.cdnAuthTokens.containsKey(depot.depotId to connection!!.host) ||
                            steam3!!.cdnAuthTokens[depot.depotId to connection.host]?.isCompleted == false
                        )
                ) {
                    steam3!!.requestCDNAuthToken(depot.appId, depot.depotId, connection)

                    cdnClientPool!!.returnConnection(connection)

                    continue
                }

                cdnClientPool!!.returnBrokenConnection(connection)

                // Unauthorized
                if (e.statusCode == 401) {
                    logger?.error("Encountered ${e.statusCode} for chunk $chunkID. Aborting.")
                    break
                }

                // Этот сервер не раздаёт данную часть игры — помечаем его и берём другой,
                // вместо того чтобы валить всю загрузку.
                if (e.statusCode == 403) {
                    cdnClientPool!!.blacklistForDepot(depot.depotId, connection)
                    forbiddenTries++
                    if (forbiddenTries > maxForbiddenTries) {
                        logger?.error("Encountered ${e.statusCode} for chunk $chunkID on every server. Aborting.")
                        break
                    }
                    continue
                }

                logger?.error("Encountered error downloading chunk $chunkID: ${e.statusCode}")
            } catch (e: Exception) {
                cdnClientPool!!.returnBrokenConnection(connection)
                logger?.error("Encountered unexpected error downloading chunk $chunkID", e)
            }
        } while (downloaded == 0)

        if (downloaded == 0) {
            statFilesMissing.incrementAndGet()
            logger?.error("Failed to find any server with chunk ${chunk.chunkID} for depot ${depot.depotId}. Aborting.")
            cancel()
        }

        // Throw the cancellation exception if requested so that this task is marked failed
        ensureActive()

        if (isRepeated && downloaded > 0) {
            cacheChunk(chunkID, chunkBuffer)
        }

        // Return the decompress item for the next stage in the pipeline
        return@withContext DecompressItem(
            depot = depot,
            depotDownloadCounter = depotDownloadCounter,
            downloadCounter = downloadCounter,
            downloaded = downloaded,
            file = file,
            fileStreamData = fileStreamData,
            chunk = chunk,
            chunkBuffer = chunkBuffer,
        )
    }

    private fun testIsFileIncluded(filename: String): Boolean {
        val normalizedFilename = filename.replace('\\', '/')

        // Список «не качать» проверяем первым: им отсекаются, например,
        // озвучки чужих языков, лежащие в общем куске игры
        for (regex in config.filesToSkipRegex) {
            if (regex.containsMatchIn(normalizedFilename)) {
                return false
            }
        }

        if (!config.usingFileList) {
            return true
        }

        if (normalizedFilename in config.filesToDownload) {
            return true
        }

        for (regex in config.filesToDownloadRegex) {
            if (regex.matches(normalizedFilename)) {
                return true
            }
        }

        return false
    }

    private suspend fun finishDepotDownload(mainAppId: Int) {
        val appItem = processingItemsMap[mainAppId]
        if (appItem != null) {
            notifyListeners { it.onDownloadCompleted(appItem) }
        }

        completionFuture.complete(null)
    }

    // endregion

    // region [REGION] Listener Operations

    fun addListener(listener: IDownloadListener) {
        listeners.add(listener)
    }

    fun removeListener(listener: IDownloadListener) {
        listeners.remove(listener)
    }

    private fun notifyListeners(action: (IDownloadListener) -> Unit) {
        scope.launch(Dispatchers.IO) {
            listeners.forEach { listener -> action(listener) }
        }
    }

    // endregion

    // region [REGION] Queue Operations

    /**
     * Add a singular item of either [AppItem], [PubFileItem], or [UgcItem]
     */
    fun add(item: DownloadItem) {
        runBlocking {
            try {
                processingChannel.send(item)
                notifyListeners { it.onItemAdded(item) }
            } catch (e: Exception) {
                logger?.error("Could not add item ${item.appId}", e)
                throw e
            }
        }
    }

    /**
     * Add a list items of either [AppItem], [PubFileItem], or [UgcItem]
     */
    fun addAll(items: List<DownloadItem>) {
        runBlocking {
            try {
                items.forEach { item ->
                    processingChannel.send(item)
                    notifyListeners { it.onItemAdded(item) }
                }
            } catch (e: Exception) {
                logger?.error("Could not add all files", e)
                throw e
            }
        }
    }

    /**
     * Signals that no more items will be added to the download queue.
     * After calling this, the downloader will complete once all queued items finish.
     *
     * This is called automatically by [close], but you can call it explicitly
     * if you want to wait for completion without closing the downloader.
     */
    fun finishAdding() {
        processingChannel.close()
    }

    // endregion

    private suspend fun processItems() = coroutineScope {
        if (useLanCache) {
            ClientLancache.detectLancacheServer()
        }

        if (ClientLancache.useLanCacheServer) {
            logger?.debug("Detected Lan-Cache server! Downloads will be directed through the LanCache.")
            if (maxDownloads == 8) {
                maxDownloads = 25
            }
        }

        // Launch the chunk processing pipeline using Flow
        chunkProcessingJob = scope.launch {
            createChunkProcessingFlow().collect()
        }

        for (item in processingChannel) {
            try {
                ensureActive()

                // Set configuration values
                config = config.copy(
                    downloadManifestOnly = item.downloadManifestOnly,
                    installPath = item.installDirectory?.toPath(),
                    installToGameNameDirectory = item.installToGameNameDirectory,
                    // раньше галочка «проверить файлы» до загрузчика не доходила вовсе
                    verifyAll = item.verify,
                )

                processingItemsMap[item.appId] = item

                when (item) {
                    is PubFileItem -> {
                        logger?.debug("Downloading PUB File for ${item.appId}")
                        notifyListeners { it.onDownloadStarted(item) }
                        downloadPubFile(item.appId, item.pubFile)
                    }

                    is UgcItem -> {
                        logger?.debug("Downloading UGC File for ${item.appId}")
                        notifyListeners { it.onDownloadStarted(item) }
                        downloadUGC(item.appId, item.ugcId)
                    }

                    is AppItem -> {
                        val branch = item.branch ?: DEFAULT_BRANCH
                        config = config.copy(betaPassword = item.branchPassword)

                        if (!config.betaPassword.isNullOrBlank() && branch.isBlank()) {
                            logger?.error("Error: Cannot specify 'branchpassword' when 'branch' is not specified.")
                            continue
                        }

                        config = config.copy(downloadAllPlatforms = item.downloadAllPlatforms)
                        val os = item.os

                        if (config.downloadAllPlatforms && !os.isNullOrBlank()) {
                            logger?.error("Error: Cannot specify `os` when `all-platforms` is specified.")
                            continue
                        }

                        config = config.copy(downloadAllArchs = item.downloadAllArchs)
                        val arch = item.osArch

                        if (config.downloadAllArchs && !arch.isNullOrBlank()) {
                            logger?.error("Error: Cannot specify `osarch` when `all-archs` is specified.")
                            continue
                        }

                        config = config.copy(downloadAllLanguages = item.downloadAllLanguages)
                        val language = item.language

                        if (config.downloadAllLanguages && !language.isNullOrBlank()) {
                            logger?.error("Error: Cannot specify `language` when `all-languages` is specified.")
                            continue
                        }

                        val depotManifestIds = mutableListOf<Pair<Int, Long>>()
                        val depotIdList = item.depot
                        val manifestIdList = item.manifest

                        if (manifestIdList.isNotEmpty()) {
                            if (depotIdList.size != manifestIdList.size) {
                                logger?.error("Error: `manifest` requires one id for every `depot` specified")
                                continue
                            }
                            depotManifestIds.addAll(depotIdList.zip(manifestIdList))
                        } else {
                            depotManifestIds.addAll(depotIdList.map { it to INVALID_MANIFEST_ID })
                        }

                        logger?.debug("Downloading App for ${item.appId}")
                        notifyListeners { it.onDownloadStarted(item) }
                        downloadApp(
                            appId = item.appId,
                            depotManifestIds = depotManifestIds,
                            branch = branch,
                            os = os,
                            arch = arch,
                            language = language,
                            lv = item.lowViolence,
                            isUgc = false,
                        )
                    }
                }
            } catch (e: Exception) {
                logger?.error("Error downloading item ${item.appId}: ${e.message}", e)
                notifyListeners { it.onDownloadFailed(item, e) }
            }
        }
    }

    private suspend fun processFileDecompress(item: DecompressItem): FileWriteItem = withContext(decompressDispatcher) {
        // Throw the cancellation exception if requested so that this task is marked failed
        ensureActive()

        val depot = item.depot
        val depotKey = depot.depotKey
        val downloaded = item.downloaded
        val chunk = item.chunk
        val chunkBuffer = item.chunkBuffer

        var written = downloaded
        var decompressedBuffer = chunkBuffer

        if (depotKey != null) {
            decompressedBuffer = ByteArray(chunk.uncompressedLength)
            written = DepotChunk.process(chunk, chunkBuffer, decompressedBuffer, depotKey)
        }

        return@withContext FileWriteItem(
            depot = depot,
            depotDownloadCounter = item.depotDownloadCounter,
            downloadCounter = item.downloadCounter,
            file = item.file,
            fileStreamData = item.fileStreamData,
            chunk = chunk,
            decompressed = written,
            decompressedBuffer = decompressedBuffer,
        )
    }

    private suspend fun processFileWrites(item: FileWriteItem): Unit = withContext(Dispatchers.IO) {
        // Throw the cancellation exception if requested so that this task is marked failed
        ensureActive()

        val depot = item.depot
        val depotDownloadCounter = item.depotDownloadCounter
        val downloadCounter = item.downloadCounter
        val file = item.file
        val fileStreamData = item.fileStreamData
        val chunk = item.chunk
        val written = item.decompressed
        val decompressedBuffer = item.decompressedBuffer

        try {
            fileStreamData.fileLock.lock()

            if (fileStreamData.fileHandle == null) {
                val fileFinalPath = depot.installDir / file.fileName
                fileStreamData.fileHandle = filesystem.openReadWrite(fileFinalPath)
            }

            fileStreamData.fileHandle!!.write(chunk.offset, decompressedBuffer, 0, written)
        } finally {
            fileStreamData.fileLock.unlock()
        }

        // Кусок лёг на диск — запоминаем его. При продолжении после паузы
        // это позволяет не перечитывать файл, а сразу качать недостающее.
        DepotProgressStore.markChunk(
            depot.depotId,
            file.fileName,
            Strings.toHex(file.fileHash),
            chunk.offset
        )

        val remainingChunks = fileStreamData.chunksToDownload.decrementAndGet()
        if (remainingChunks == 0) {
            fileStreamData.fileHandle?.close()

            DepotProgressStore.markDone(depot.depotId, file.fileName, Strings.toHex(file.fileHash))
            statFilesFetched.incrementAndGet()

            // File completed - notify with percentage
            val sizeDownloaded = synchronized(depotDownloadCounter) {
                depotDownloadCounter.sizeDownloaded += written.toLong()
                depotDownloadCounter.depotBytesCompressed += chunk.compressedLength
                depotDownloadCounter.depotBytesUncompressed += chunk.uncompressedLength
                depotDownloadCounter.sizeDownloaded
            }

            synchronized(downloadCounter) {
                downloadCounter.totalBytesCompressed += chunk.compressedLength
                downloadCounter.totalBytesUncompressed += chunk.uncompressedLength
            }

            val fileFinalPath = depot.installDir / file.fileName
            val depotPercentage = (sizeDownloaded.toFloat() / depotDownloadCounter.completeDownloadSize)

            notifyListeners { listener ->
                listener.onFileCompleted(
                    depotId = depot.depotId,
                    fileName = fileFinalPath.toString(),
                    depotPercentComplete = depotPercentage
                )
            }

            logger?.debug("%.2f%% %s".format(depotPercentage, fileFinalPath))
        } else {
            // Update counters and notify on chunk completion
            val sizeDownloaded: Long
            val depotPercentage: Float
            val compressedBytes: Long
            val uncompressedBytes: Long

            synchronized(depotDownloadCounter) {
                depotDownloadCounter.sizeDownloaded += written.toLong()
                depotDownloadCounter.depotBytesCompressed += chunk.compressedLength
                depotDownloadCounter.depotBytesUncompressed += chunk.uncompressedLength

                sizeDownloaded = depotDownloadCounter.sizeDownloaded
                compressedBytes = depotDownloadCounter.depotBytesCompressed
                uncompressedBytes = depotDownloadCounter.depotBytesUncompressed
                depotPercentage = (sizeDownloaded.toFloat() / depotDownloadCounter.completeDownloadSize)
            }

            synchronized(downloadCounter) {
                downloadCounter.totalBytesCompressed += chunk.compressedLength
                downloadCounter.totalBytesUncompressed += chunk.uncompressedLength
            }

            notifyListeners { listener ->
                listener.onChunkCompleted(
                    depotId = depot.depotId,
                    depotPercentComplete = depotPercentage,
                    compressedBytes = compressedBytes,
                    uncompressedBytes = uncompressedBytes
                )
            }
        }
    }

    /**
     * Returns a CompletableFuture that completes when all queued downloads finish.
     * @return CompletableFuture that completes when all downloads finish
     */
    fun getCompletion(): CompletableFuture<Void> = completionFuture

    /**
     * Blocks the current thread until all queued downloads complete.
     * Convenience method that calls `getCompletion().join()`.
     * @throws CompletionException if any download fails
     */
    fun awaitCompletion() {
        completionFuture.join()
    }

    override fun close() {
        DepotProgressStore.flush()

        processingChannel.close()

        try {
            if (decompressStarted) decompressExecutor.shutdownNow()
        } catch (e: Exception) {
            // ничего
        }

        scope.cancel("DepotDownloader Closing")

        httpClient.close()

        listeners.clear()

        steam3?.close()
        steam3 = null

        cdnClientPool?.close()
        cdnClientPool = null

        logger = null
    }
}
