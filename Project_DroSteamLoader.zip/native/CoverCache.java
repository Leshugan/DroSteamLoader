package leshugan.DSL;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Обложки игр: скачиваем один раз и держим на телефоне,
 * чтобы при каждом запуске они появлялись мгновенно.
 */
public class CoverCache {

    private static final String BASE = "https://shared.cloudflare.steamstatic.com/store_item_assets/steam/apps/";
    private static final String[] NAMES = {"library_600x900.jpg", "header.jpg"};

    private static ExecutorService pool;

    public interface Result {
        void done(String path, boolean missing);
    }

    private static synchronized ExecutorService pool() {
        if (pool == null) pool = Executors.newFixedThreadPool(4);
        return pool;
    }

    private static File dir(Context ctx) {
        File d = new File(ctx.getFilesDir(), "covers2");
        if (!d.exists()) //noinspection ResultOfMethodCallIgnored
            d.mkdirs();
        return d;
    }

    private static File file(Context ctx, int appId) {
        return new File(dir(ctx), appId + ".jpg");
    }

    private static File missMark(Context ctx, int appId) {
        return new File(dir(ctx), appId + ".none");
    }

    /** Отдаёт путь к обложке; если её ещё нет — качает в фоне. */
    public static void get(final Context ctx, final int appId, final Result cb) {
        File f = file(ctx, appId);
        if (f.exists() && f.length() > 0) {
            cb.done(f.getAbsolutePath(), false);
            return;
        }
        if (missMark(ctx, appId).exists()) {
            cb.done(null, true);
            return;
        }
        pool().execute(() -> {
            for (String name : NAMES) {
                if (download(BASE + appId + "/" + name, file(ctx, appId))) {
                    cb.done(file(ctx, appId).getAbsolutePath(), false);
                    return;
                }
            }
            try {
                //noinspection ResultOfMethodCallIgnored
                missMark(ctx, appId).createNewFile();
            } catch (Throwable ignored) {
            }
            cb.done(null, true);
        });
    }

    /**
     * Обложки приходят размером 600x900. В сетке они показываются мелко, а память
     * телефон тратит на полный размер — на полусотне игр это сотня мегабайт и вылет
     * при прокрутке. Поэтому сразу ужимаем картинку до разумного размера.
     */
    private static void shrink(File f) {
        try {
            android.graphics.BitmapFactory.Options probe = new android.graphics.BitmapFactory.Options();
            probe.inJustDecodeBounds = true;
            android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), probe);
            if (probe.outWidth <= 0 || probe.outHeight <= 0) return;
            if (probe.outWidth <= MAX_W) return;

            android.graphics.BitmapFactory.Options o = new android.graphics.BitmapFactory.Options();
            int sample = 1;
            while (probe.outWidth / (sample * 2) >= MAX_W) sample *= 2;
            o.inSampleSize = sample;
            o.inPreferredConfig = android.graphics.Bitmap.Config.RGB_565;

            android.graphics.Bitmap bmp = android.graphics.BitmapFactory.decodeFile(f.getAbsolutePath(), o);
            if (bmp == null) return;

            File tmp = new File(f.getAbsolutePath() + ".small");
            FileOutputStream out = new FileOutputStream(tmp);
            try {
                bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out);
            } finally {
                out.close();
                bmp.recycle();
            }
            if (tmp.length() > 512) {
                //noinspection ResultOfMethodCallIgnored
                tmp.renameTo(f);
            } else {
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
            }
        } catch (Throwable ignored) {
            // не смогли ужать — оставляем как есть
        }
    }

    private static final int MAX_W = 300;

    private static boolean download(String url, File to) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(20000);
            c.setInstanceFollowRedirects(true);
            if (c.getResponseCode() != 200) return false;
            InputStream in = c.getInputStream();
            File tmp = new File(to.getAbsolutePath() + ".part");
            FileOutputStream out = new FileOutputStream(tmp);
            try {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            } finally {
                out.close();
                in.close();
            }
            if (tmp.length() < 512) {
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
                return false;
            }
            //noinspection ResultOfMethodCallIgnored
            tmp.renameTo(to);
            shrink(to);
            return true;
        } catch (Throwable t) {
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
