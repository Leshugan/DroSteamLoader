package `in`.dragonbra.javasteam.depotdownloader

import `in`.dragonbra.javasteam.steam.cdn.Client
import `in`.dragonbra.javasteam.steam.cdn.Server
import `in`.dragonbra.javasteam.util.log.LogManager
import `in`.dragonbra.javasteam.util.log.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * Manages a pool of CDN server connections for efficient content downloading.
 * This class maintains a list of available CDN servers, automatically selects appropriate
 * servers based on load and app compatibility, and handles connection rotation when
 * servers fail or become unavailable.
 *
 * @param steamSession The Steam3 session for server communication
 * @param appId The application ID to download - used to filter compatible CDN servers
 * @param scope The coroutine scope for async operations
 * @param debug If true, enables debug logging
 *
 * @author Oxters
 * @author Lossy
 * @since Nov 7, 2024
 */
class CDNClientPool(
    private val steamSession: Steam3Session,
    private val appId: Int,
    private val scope: CoroutineScope,
    debug: Boolean = false,
) : AutoCloseable {

    companion object {
        /** Сколько сбоев подряд терпим, прежде чем перестать предлагать сервер. */
        private const val FAIL_LIMIT = 5

        /** Сколько кусков надо померить, чтобы верить скорости сервера. */
        private const val MEASURE_MIN = 2.0

        /** Минимальная доля от скорости лучшего сервера, ниже которой не опускаем вес. */
        private const val MIN_SHARE = 0.2

        /** Сервер, выбранный пользователем в настройках. Пусто — берём ближайший по нагрузке. */
        @JvmStatic
        var preferredHost: String? = null
    }

    private var logger: Logger? = null

    private val servers = AtomicReference<List<Server>>(emptyList())

    private var nextServer: AtomicInteger = AtomicInteger(0)

    private val mutex: Mutex = Mutex()

    /** Серверы, отказавшие по конкретной части игры: номер депота → адреса серверов. */
    private val blacklist =
        java.util.concurrent.ConcurrentHashMap<Int, java.util.concurrent.ConcurrentHashMap.KeySetView<String, Boolean>>()

    /** Сколько раз подряд сервер сбоил по сети. */
    private val failures = java.util.concurrent.ConcurrentHashMap<String, AtomicInteger>()

    var cdnClient: Client? = null
        private set

    var proxyServer: Server? = null
        private set

    init {
        cdnClient = Client(steamSession.steamClient)

        if (debug) {
            logger = LogManager.getLogger(CDNClientPool::class.java)
        }
    }

    override fun close() {
        logger?.debug("Closing...")

        servers.set(emptyList())
        blacklist.clear()
        failures.clear()
        speeds.clear()

        cdnClient = null
        proxyServer = null

        logger = null
    }

    @Throws(Exception::class)
    suspend fun updateServerList(maxNumServers: Int? = null) = mutex.withLock {
        val serversForSteamPipe = steamSession.steamContent!!.getServersForSteamPipe(
            cellId = steamSession.steamClient.cellID ?: 0,
            maxNumServers = maxNumServers,
            parentScope = scope
        ).await()

        proxyServer = serversForSteamPipe.firstOrNull { it.useAsProxy }

        val weightedCdnServers = serversForSteamPipe
            .filter { server ->
                val isEligibleForApp = server.allowedAppIds.isEmpty() || server.allowedAppIds.contains(appId)
                isEligibleForApp && (server.type == "SteamCache" || server.type == "CDN")
            }
            .sortedWith(
                // сначала обычные CDN (они раздают что угодно), потом кэш-серверы;
                // внутри группы — по загруженности
                compareBy<Server> { if (it.allowedAppIds.isEmpty()) 0 else 1 }
                    .thenBy { it.weightedLoad }
            )
            // один и тот же адрес в списке может встречаться несколько раз
            .distinctBy { it.host }
            .let { list ->
                val wanted = preferredHost
                if (wanted.isNullOrBlank()) {
                    list
                } else {
                    // выбранный сервер вперёд, остальные оставляем как запас
                    val picked = list.filter { it.host == wanted }
                    if (picked.isEmpty()) list else picked + list.filter { it.host != wanted }
                }
            }

        // ContentServerPenalty removed for now.

        servers.set(weightedCdnServers)

        // Круг для первых кусков строим по данным самого Steam: сколько «мест»
        // сервер стоит и насколько он сейчас загружен. Раньше все получали поровну,
        // и первые куски одинаково уходили и на мощный CDN, и на забитый кэш.
        val rotation = ArrayList<Server>()
        weightedCdnServers.forEach { s ->
            repeat(steamSlots(s)) { rotation.add(s) }
        }
        warmupRotation.set(if (rotation.isEmpty()) weightedCdnServers else rotation)

        nextServer.set(0)

        weightedCdnServers.take(6).forEach { s ->
            logger?.debug(
                "Сервер ${s.host}: мест ${s.numEntries}, загрузка ${s.load}, " +
                    "взвешенная ${s.weightedLoad}, мест в круге ${steamSlots(s)}"
            )
        }

        // servers.joinToString(separator = "\n", prefix = "Servers:\n") { "- $it" }
        logger?.debug("Found ${weightedCdnServers.size} Servers")

        if (weightedCdnServers.isEmpty()) {
            throw Exception("Failed to retrieve any download servers.")
        }
    }

    fun getConnection(): Server = getConnection(0)

    /**
     * Даёт сервер для скачивания. Пропускаются те, что уже отказали по этой части игры
     * (ответ 403 — «не раздаю этот депот») и те, что подряд сбоят по сети.
     */
    /** Круг раздачи на время разогрева — по весам от Steam. */
    private val warmupRotation = java.util.concurrent.atomic.AtomicReference<List<Server>>(emptyList())

    /**
     * Сколько мест в круге даёт Steam этому серверу: он сам сообщает «вес» сервера
     * и его загруженность. Ограничиваем сверху, чтобы один сервер не занял весь круг.
     */
    private fun steamSlots(s: Server): Int {
        val entries = if (s.numEntries > 0) s.numEntries else 1
        val load = if (s.weightedLoad > 0f) s.weightedLoad.toDouble() else 0.0
        val slots = Math.round(entries / (1.0 + load / 100.0)).toInt()
        return slots.coerceIn(1, 8)
    }

    /** Средняя скорость сервера в КБ/с и сколько кусков по нему уже померили. */
    private val speeds = java.util.concurrent.ConcurrentHashMap<String, DoubleArray>()

    /** Запомнить, за сколько миллисекунд сервер отдал кусок. */
    fun noteTiming(host: String, ms: Long, bytes: Int) {
        if (ms <= 0 || bytes <= 0) return

        val kbs = bytes.toDouble() / 1024.0 / (ms.toDouble() / 1000.0)
        val a = speeds.getOrPut(host) { DoubleArray(2) }
        synchronized(a) {
            // скользящее среднее: свежие замеры весят больше, чтобы успевать за сетью
            a[0] = if (a[1] < 1.0) kbs else a[0] * 0.7 + kbs * 0.3
            a[1] += 1.0
        }
    }

    fun getConnection(depotId: Int): Server {
        val all = servers.get()

        if (all.isEmpty()) {
            throw IllegalStateException("Нет доступных серверов загрузки")
        }

        val banned = blacklist[depotId]

        val healthy = all.filter { s ->
            banned?.contains(s.host) != true && (failures[s.host]?.get() ?: 0) < FAIL_LIMIT
        }

        // если здоровых не осталось — берём хотя бы не забаненные, иначе вообще любые
        val pool = if (healthy.isNotEmpty()) {
            healthy
        } else {
            val notBanned = all.filter { banned?.contains(it.host) != true }
            if (notBanned.isNotEmpty()) notBanned else all
        }

        val server = pickBySpeed(pool)

        logger?.debug("Getting connection $server")

        return server
    }

    /**
     * Пока про серверы ничего не известно — раздаём по кругу, чтобы всех замерить.
     * Дальше даём быстрым больше кусков, медленным меньше, а совсем провальных
     * изредка пробуем снова: сеть меняется, и вечно списывать сервер нельзя.
     */
    private fun pickBySpeed(pool: List<Server>): Server {
        if (pool.size == 1) return pool[0]

        var measured = 0
        var best = 0.0
        for (s in pool) {
            val a = speeds[s.host] ?: continue
            if (a[1] >= MEASURE_MIN) {
                measured++
                if (a[0] > best) best = a[0]
            }
        }

        // Пока не всех померили — идём по кругу, построенному на весах Steam
        if (measured < pool.size || best <= 0.0) {
            val warm = warmupRotation.get().filter { w -> pool.any { it.host == w.host } }
            val ring = if (warm.isEmpty()) pool else warm
            return ring[Math.floorMod(nextServer.getAndIncrement(), ring.size)]
        }

        // раз в двадцать кусков даём шанс любому, включая отстающих
        if (Math.floorMod(nextServer.getAndIncrement(), 20) == 0) {
            return pool[java.util.concurrent.ThreadLocalRandom.current().nextInt(pool.size)]
        }

        // вес = скорость, но не ниже пятой части лучшей, чтобы никого не выкинуть насовсем
        val floor = best * MIN_SHARE
        var total = 0.0
        val weights = DoubleArray(pool.size)
        for (i in pool.indices) {
            val a = speeds[pool[i].host]
            val v = if (a == null || a[1] < MEASURE_MIN) best else maxOf(a[0], floor)
            weights[i] = v
            total += v
        }

        var dice = java.util.concurrent.ThreadLocalRandom.current().nextDouble(total)
        for (i in pool.indices) {
            dice -= weights[i]
            if (dice <= 0.0) return pool[i]
        }
        return pool[pool.size - 1]
    }

    /** Есть ли ещё откуда качать. */
    fun hasServers(): Boolean = servers.get().isNotEmpty()

    /** Сервер отказался раздавать эту часть игры — больше его для неё не берём. */
    fun blacklistForDepot(depotId: Int, server: Server?) {
        if (server == null) return

        val set = blacklist.getOrPut(depotId) { java.util.concurrent.ConcurrentHashMap.newKeySet() }
        val servers = servers.get()

        // не даём забанить вообще все серверы — иначе качать будет неоткуда
        if (set.size >= servers.size - 1) return

        if (set.add(server.host)) {
            logger?.debug("Server ${server.host} blacklisted for depot $depotId")
        }
    }

    fun returnConnection(server: Server?) {
        if (server == null) {
            logger?.error("null server returned to cdn pool.")
            return
        }

        // успех — прошлые сбои этого сервера больше не в счёт
        failures[server.host]?.set(0)

        logger?.debug("Returning connection: $server")

        // (SK) nothing to do, maybe remove from ContentServerPenalty?
    }

    fun returnBrokenConnection(server: Server?) {
        if (server == null) {
            logger?.error("null broken server returned to pool")
            return
        }

        logger?.debug("Returning broken connection: $server")

        // считаем сбои: сервер, который сбоит подряд, временно перестаём предлагать
        failures.getOrPut(server.host) { AtomicInteger(0) }.incrementAndGet()
    }
}
