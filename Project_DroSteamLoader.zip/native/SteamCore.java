package leshugan.DSL;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.Closeable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

import in.dragonbra.javasteam.depotdownloader.DepotDownloader;
import in.dragonbra.javasteam.depotdownloader.IDownloadListener;
import in.dragonbra.javasteam.depotdownloader.data.AppItem;
import in.dragonbra.javasteam.depotdownloader.data.DownloadItem;
import in.dragonbra.javasteam.enums.EResult;
import in.dragonbra.javasteam.steam.authentication.AuthPollResult;
import in.dragonbra.javasteam.steam.authentication.AuthSessionDetails;
import in.dragonbra.javasteam.steam.authentication.CredentialsAuthSession;
import in.dragonbra.javasteam.steam.authentication.IAuthenticator;
import in.dragonbra.javasteam.steam.authentication.QrAuthSession;
import in.dragonbra.javasteam.steam.handlers.steamapps.License;
import in.dragonbra.javasteam.steam.handlers.steamapps.PICSProductInfo;
import in.dragonbra.javasteam.steam.handlers.steamapps.PICSRequest;
import in.dragonbra.javasteam.steam.handlers.steamapps.SteamApps;
import in.dragonbra.javasteam.steam.handlers.steamapps.callback.LicenseListCallback;
import in.dragonbra.javasteam.steam.handlers.steamapps.callback.PICSProductInfoCallback;
import in.dragonbra.javasteam.steam.handlers.steamapps.callback.PICSTokensCallback;
import in.dragonbra.javasteam.steam.handlers.steamuser.LogOnDetails;
import in.dragonbra.javasteam.steam.handlers.steamuser.SteamUser;
import in.dragonbra.javasteam.steam.handlers.steamuser.callback.LoggedOffCallback;
import in.dragonbra.javasteam.steam.handlers.steamuser.callback.LoggedOnCallback;
import in.dragonbra.javasteam.steam.steamclient.SteamClient;
import in.dragonbra.javasteam.steam.steamclient.callbackmgr.CallbackManager;
import in.dragonbra.javasteam.steam.steamclient.callbacks.ConnectedCallback;
import in.dragonbra.javasteam.steam.steamclient.callbacks.DisconnectedCallback;
import in.dragonbra.javasteam.steam.cdn.Server;
import in.dragonbra.javasteam.steam.handlers.steamcontent.SteamContent;
import in.dragonbra.javasteam.types.KeyValue;

/**
 * Одна сессия Steam на всё приложение: вход, список игр, сведения об игре, скачивание.
 */
public class SteamCore {

    public interface Emitter {
        void emit(String event, JSONObject data);
    }

    private static SteamCore instance;

    public static synchronized SteamCore get(Context ctx) {
        if (instance == null) instance = new SteamCore(ctx.getApplicationContext());
        return instance;
    }

    private final Context ctx;
    private final SharedPreferences prefs;
    private Emitter emitter;

    private SteamClient client;
    private CallbackManager manager;
    private SteamUser steamUser;
    private SteamApps steamApps;
    private SteamContent steamContent;
    private Thread loopThread;
    private volatile boolean running;

    private final List<Closeable> subs = new ArrayList<>();
    private volatile List<License> licenses = new ArrayList<>();
    private volatile boolean licensesReady;

    private volatile String state = "offline";
    private volatile String lastError = "";
    private volatile String accountName;

    private volatile String pendingUser, pendingPass;
    private volatile boolean pendingQr;
    private volatile boolean wantAuth;
    private volatile boolean authRunning;
    private volatile boolean lastLogonUsedToken;
    private volatile int reconnectTries;
    private volatile long nextConnectAt;
    private volatile boolean connecting;
    private volatile boolean background;
    private Thread keeperThread;
    private final Object authLock = new Object();
    private volatile CompletableFuture<String> guardFuture;
    private volatile String guardKind = "";

    private volatile DepotDownloader downloader;
    private volatile Thread downloadThread;
    private volatile boolean cancelRequested;

    private final Map<Integer, JSONObject> appCache = new LinkedHashMap<>();

    private java.io.File file(String name) {
        return new java.io.File(ctx.getFilesDir(), name);
    }

    private String readFile(String name) {
        try {
            java.io.File f = file(name);
            if (!f.exists()) return null;
            byte[] buf = new byte[(int) f.length()];
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            try {
                int read = 0;
                while (read < buf.length) {
                    int n = in.read(buf, read, buf.length - read);
                    if (n < 0) break;
                    read += n;
                }
            } finally {
                in.close();
            }
            return new String(buf, "UTF-8");
        } catch (Throwable t) {
            return null;
        }
    }

    private void writeFile(String name, String data) {
        try {
            java.io.FileOutputStream out = new java.io.FileOutputStream(file(name));
            try {
                out.write(data.getBytes("UTF-8"));
            } finally {
                out.close();
            }
        } catch (Throwable ignored) {
        }
    }

    /** Сохранённый список игр — показываем сразу при запуске, не дожидаясь Steam. */
    public JSONArray cachedLibrary() {
        String s = readFile("library.json");
        if (s == null) return new JSONArray();
        try {
            return new JSONArray(s);
        } catch (Throwable t) {
            return new JSONArray();
        }
    }

    /** Что уже качали: игра -> ветка, платформа, номер сборки. */
    public JSONObject installed() {
        String s = readFile("installed.json");
        if (s == null) return new JSONObject();
        try {
            return new JSONObject(s);
        } catch (Throwable t) {
            return new JSONObject();
        }
    }

    private void rememberInstalled(int appId, String name, String branch, String os, String dir) {
        try {
            JSONObject all = installed();
            JSONObject one = new JSONObject();
            one.put("appId", appId);
            one.put("name", name);
            one.put("branch", branch);
            one.put("os", os);
            one.put("dir", dir);
            one.put("time", System.currentTimeMillis());
            one.put("buildId", currentBuildId(appId, branch));
            all.put(String.valueOf(appId), one);
            writeFile("installed.json", all.toString());
        } catch (Throwable ignored) {
        }
    }

    private String currentBuildId(int appId, String branch) {
        try {
            JSONObject info = appInfo(appId);
            JSONArray br = info.getJSONArray("branches");
            for (int i = 0; i < br.length(); i++) {
                JSONObject b = br.getJSONObject(i);
                if (branch.equals(b.optString("name"))) return b.optString("buildId", "");
            }
        } catch (Throwable ignored) {
        }
        return "";
    }

    /** Проверка обновлений скачанных игр — только по запросу (при запуске приложения). */
    public JSONArray checkUpdates() throws Exception {
        requireLoggedOn();
        JSONObject all = installed();
        JSONArray out = new JSONArray();
        java.util.Iterator<String> it = all.keys();
        while (it.hasNext()) {
            String key = it.next();
            JSONObject one = all.optJSONObject(key);
            if (one == null) continue;
            int appId = one.optInt("appId", 0);
            String branch = one.optString("branch", "public");
            String was = one.optString("buildId", "");
            String now = currentBuildId(appId, branch);
            if (!now.isEmpty() && !now.equals(was)) {
                JSONObject u = new JSONObject();
                u.put("appId", appId);
                u.put("name", one.optString("name", String.valueOf(appId)));
                u.put("branch", branch);
                u.put("oldBuildId", was);
                u.put("newBuildId", now);
                out.put(u);
            }
        }
        log("Обновлений найдено: " + out.length());
        return out;
    }

    private SteamCore(Context c) {
        this.ctx = c;
        this.prefs = c.getSharedPreferences("dsl", Context.MODE_PRIVATE);
    }

    public void setEmitter(Emitter e) {
        this.emitter = e;
    }

    private void emit(String ev, JSONObject o) {
        Emitter e = emitter;
        if (e != null) e.emit(ev, o);
    }

    private boolean libLogHooked;

    private void hookLibraryLog() {
        if (libLogHooked) return;
        libLogHooked = true;
        try {
            in.dragonbra.javasteam.util.log.LogManager.addListener(new in.dragonbra.javasteam.util.log.LogListener() {
                @Override
                public void onLog(Class<?> clazz, String message, Throwable throwable) {
                    forward(clazz, message, throwable);
                }

                @Override
                public void onError(Class<?> clazz, String message, Throwable throwable) {
                    forward(clazz, message, throwable);
                }

                private void forward(Class<?> clazz, String message, Throwable throwable) {
                    String cls = clazz == null ? "" : clazz.getSimpleName();
                    if (cls.contains("Depot") || cls.contains("CDN") || cls.contains("Steam3")) {
                        log(cls + ": " + message + (throwable == null ? "" : " / " + throwable));
                    }
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private void log(String msg) {
        try {
            JSONObject o = new JSONObject();
            o.put("message", msg);
            emit("log", o);
        } catch (Exception ignored) {
        }
    }

    private void setState(String s) {
        state = s;
        try {
            JSONObject o = new JSONObject();
            o.put("state", s);
            o.put("account", accountName == null ? "" : accountName);
            o.put("error", lastError);
            emit("state", o);
        } catch (Exception ignored) {
        }
    }

    public String getState() {
        return state;
    }

    /** Приложение свёрнуто/развёрнуто. */
    public void setBackground(boolean bg) {
        background = bg;
        if (!bg) {
            // вернулись в приложение — сразу пробуем восстановить связь
            reconnectTries = 0;
            nextConnectAt = 0L;
        }
    }

    public String getAccountName() {
        return accountName == null ? "" : accountName;
    }

    public boolean hasSavedSession() {
        return prefs.getString("refreshToken", null) != null;
    }

    public String savedAccount() {
        return prefs.getString("accountName", "");
    }

    // region соединение

    private synchronized void ensureClient() {
        if (client != null) return;

        client = new SteamClient();
        manager = new CallbackManager(client);
        steamUser = client.getHandler(SteamUser.class);
        steamApps = client.getHandler(SteamApps.class);
        steamContent = client.getHandler(SteamContent.class);

        // выбранный сервер загрузки
        String srv = prefs.getString("cdnHost", "");
        in.dragonbra.javasteam.depotdownloader.CDNClientPool.setPreferredHost(srv.isEmpty() ? null : srv);

        subs.add(manager.subscribe(ConnectedCallback.class, this::onConnected));
        subs.add(manager.subscribe(DisconnectedCallback.class, this::onDisconnected));
        subs.add(manager.subscribe(LoggedOnCallback.class, this::onLoggedOn));
        subs.add(manager.subscribe(LoggedOffCallback.class, this::onLoggedOff));
        subs.add(manager.subscribe(LicenseListCallback.class, this::onLicenseList));

        running = true;
        loopThread = new Thread(() -> {
            while (running) {
                try {
                    manager.runWaitCallbacks(500L);
                } catch (Throwable t) {
                    // не даём петле умереть из-за одного сбойного колбэка
                }
            }
        }, "dsl-steam-loop");
        loopThread.setDaemon(true);
        loopThread.start();

        keeperThread = new Thread(() -> {
            while (running) {
                try {
                    Thread.sleep(2000L);
                    if (!wantAuth) continue;
                    if (client == null) continue;
                    // в фоне без загрузок сеть не дёргаем — Android всё равно её режет
                    if (background && !isDownloading() && !queueRunning) continue;
                    if (client.isConnected()) continue;
                    if (System.currentTimeMillis() < nextConnectAt) continue;
                    connecting = true;
                    reconnectTries++;
                    long wait = Math.min(30000L, 3000L * reconnectTries);
                    nextConnectAt = System.currentTimeMillis() + wait;
                    log("Подключаюсь к Steam (попытка " + reconnectTries + ")");
                    setState("connecting");
                    client.connect();
                } catch (Throwable ignored) {
                }
            }
        }, "dsl-keeper");
        keeperThread.setDaemon(true);
        keeperThread.start();
    }

    public void loginWithPassword(String user, String pass) {
        ensureClient();
        pendingQr = false;
        pendingUser = user;
        pendingPass = pass;
        beginLogin();
    }

    public void loginWithSavedToken() {
        ensureClient();
        pendingQr = false;
        pendingUser = prefs.getString("accountName", null);
        pendingPass = null;
        beginLogin();
    }

    public void loginWithQr() {
        ensureClient();
        pendingQr = true;
        pendingUser = null;
        pendingPass = null;
        beginLogin();
    }

    private void beginLogin() {
        wantAuth = true;
        reconnectTries = 0;
        nextConnectAt = 0L;
        lastError = "";
        setState("connecting");
        if (client.isConnected()) {
            startAuthThread();
        }
        // если соединения нет — его поднимет хранитель соединения
    }

    /** Авторизация запускается ровно один раз за подключение. */
    private void startAuthThread() {
        synchronized (authLock) {
            if (authRunning) return;
            authRunning = true;
        }
        Thread t = new Thread(() -> {
            try {
                doAuth();
            } finally {
                authRunning = false;
            }
        }, "dsl-auth");
        t.setDaemon(true);
        t.start();
    }

    public void submitGuardCode(String code) {
        CompletableFuture<String> f = guardFuture;
        if (f != null) f.complete(code);
    }

    public void logout() {
        try {
            cancelDownload();
        } catch (Throwable ignored) {
        }
        wantAuth = false;
        pendingUser = null;
        pendingPass = null;
        prefs.edit().remove("refreshToken").remove("accountName").apply();
        licensesReady = false;
        licenses = new ArrayList<>();
        appCache.clear();
        accountName = null;
        try {
            if (steamUser != null) steamUser.logOff();
        } catch (Throwable ignored) {
        }
        try {
            if (client != null) client.disconnect();
        } catch (Throwable ignored) {
        }
        setState("offline");
    }

    private void onConnected(ConnectedCallback cb) {
        log("Соединение со Steam установлено");
        connecting = false;
        reconnectTries = 0;
        nextConnectAt = 0L;
        if (!wantAuth) {
            setState("offline");
            return;
        }
        startAuthThread();
    }

    private void onDisconnected(DisconnectedCallback cb) {
        connecting = false;
        licensesReady = false;
        if (cb.isUserInitiated() || !running || !wantAuth) {
            log("Соединение закрыто");
            setState("offline");
            return;
        }
        // связь рвётся сама (сон телефона, смена сети) — молча поднимаем заново
        log("Связь со Steam потеряна, восстанавливаю");
        nextConnectAt = System.currentTimeMillis() + 1500L;
        setState("reconnecting");
    }

    private void doAuth() {
        try {
            String savedToken = prefs.getString("refreshToken", null);
            String savedName = prefs.getString("accountName", null);

            if (pendingQr) {
                AuthSessionDetails d = new AuthSessionDetails();
                d.deviceFriendlyName = "DroSteamLoader";
                d.persistentSession = true;
                d.authenticator = new GuardAuthenticator();

                QrAuthSession qr = client.getAuthentication().beginAuthSessionViaQR(d).get();
                emitQr(qr.getChallengeUrl());
                qr.setChallengeUrlChanged(session -> emitQr(qr.getChallengeUrl()));
                setState("qr");

                AuthPollResult r = qr.pollingWaitForResult().get();
                pendingQr = false;
                saveTokens(r);
                logOnWithToken(r.getAccountName(), r.getRefreshToken(), false);
                return;
            }

            boolean hasPassword = pendingUser != null && !pendingUser.isEmpty()
                    && pendingPass != null && !pendingPass.isEmpty();

            // сохранённый ключ сессии — главный путь: пароль спрашивать не нужно
            if (!hasPassword) {
                if (savedToken != null && savedName != null) {
                    log("Вхожу по сохранённому ключу сессии");
                    logOnWithToken(savedName, savedToken, true);
                } else {
                    wantAuth = false;
                    lastError = "Введите логин и пароль";
                    log("Входить нечем: нет ни пароля, ни сохранённого ключа");
                    setState("offline");
                }
                return;
            }

            AuthSessionDetails d = new AuthSessionDetails();
            d.username = pendingUser;
            d.password = pendingPass;
            d.deviceFriendlyName = "DroSteamLoader";
            d.persistentSession = true;
            d.authenticator = new GuardAuthenticator();

            log("Проверяю логин и пароль в Steam");
            CredentialsAuthSession session = client.getAuthentication().beginAuthSessionViaCredentials(d).get();
            AuthPollResult r = session.pollingWaitForResult().get();
            saveTokens(r);
            logOnWithToken(r.getAccountName(), r.getRefreshToken(), false);
        } catch (Throwable t) {
            String m = String.valueOf(t.getMessage());
            if (m.contains("InvalidPassword")) m = "Неверный логин или пароль";
            if (m.contains("RateLimitExceeded")) m = "Слишком много попыток, подождите 10-15 минут";
            lastError = m;
            log("Ошибка входа: " + m);
            setState("error");
        }
    }

    private void emitQr(String url) {
        try {
            JSONObject o = new JSONObject();
            o.put("url", url);
            emit("qr", o);
        } catch (Exception ignored) {
        }
    }

    private void saveTokens(AuthPollResult r) {
        prefs.edit()
                .putString("refreshToken", r.getRefreshToken())
                .putString("accountName", r.getAccountName())
                .apply();
    }

    private void logOnWithToken(String name, String token, boolean fromSaved) {
        accountName = name;
        lastLogonUsedToken = fromSaved;
        LogOnDetails details = new LogOnDetails();
        details.setUsername(name);
        details.setAccessToken(token);
        details.setShouldRememberPassword(true);
        details.setLoginID(1490);
        setState("loggingOn");
        steamUser.logOn(details);
    }

    private void onLoggedOn(LoggedOnCallback cb) {
        if (cb.getResult() != EResult.OK) {
            String res = String.valueOf(cb.getResult());
            boolean tokenDead = cb.getResult() == EResult.InvalidPassword
                    || cb.getResult() == EResult.AccessDenied
                    || cb.getResult() == EResult.Expired;

            if (lastLogonUsedToken && tokenDead) {
                prefs.edit().remove("refreshToken").apply();
                log("Сохранённый ключ сессии больше не годится");
                if (pendingUser != null && pendingPass != null && !pendingPass.isEmpty()) {
                    log("Пробую войти логином и паролем");
                    startAuthThread();
                    return;
                }
                lastError = "Сохранённый вход устарел — введите пароль";
            } else {
                lastError = "Не удалось войти: " + res;
            }
            wantAuth = false;
            log(lastError);
            setState("error");
            return;
        }
        pendingPass = null;
        reconnectTries = 0;
        log("Вход выполнен: " + accountName);
        setState("loggedOn");
    }

    private void onLoggedOff(LoggedOffCallback cb) {
        log("Выход из Steam: " + cb.getResult());
        if (!"error".equals(state)) setState("offline");
    }

    private void onLicenseList(LicenseListCallback cb) {
        if (cb.getResult() != EResult.OK) {
            log("Не удалось получить список лицензий");
            return;
        }
        licenses = new ArrayList<>(cb.getLicenseList());
        licensesReady = true;
        log("Лицензий у аккаунта: " + licenses.size());
        try {
            JSONObject o = new JSONObject();
            o.put("count", licenses.size());
            emit("licenses", o);
        } catch (Exception ignored) {
        }
    }

    private class GuardAuthenticator implements IAuthenticator {
        @Override
        public CompletableFuture<String> getDeviceCode(boolean previousCodeWasIncorrect) {
            return askCode("device", previousCodeWasIncorrect, null);
        }

        @Override
        public CompletableFuture<String> getEmailCode(String email, boolean previousCodeWasIncorrect) {
            return askCode("email", previousCodeWasIncorrect, email);
        }

        @Override
        public CompletableFuture<Boolean> acceptDeviceConfirmation() {
            // подтверждение в мобильном приложении Steam — ждём его, код спросим только если не выйдет
            try {
                JSONObject o = new JSONObject();
                o.put("kind", "confirm");
                emit("guard", o);
            } catch (Exception ignored) {
            }
            return CompletableFuture.completedFuture(true);
        }
    }

    private CompletableFuture<String> askCode(String kind, boolean wrong, String email) {
        guardKind = kind;
        guardFuture = new CompletableFuture<>();
        try {
            JSONObject o = new JSONObject();
            o.put("kind", kind);
            o.put("wrong", wrong);
            o.put("email", email == null ? "" : email);
            emit("guard", o);
        } catch (Exception ignored) {
        }
        setState("guard");
        return guardFuture;
    }

    // endregion

    // region PICS: библиотека и сведения об игре

    private void requireLoggedOn() throws Exception {
        // после переподключения даём немного времени на повторный вход
        long wait = System.currentTimeMillis() + 15000L;
        while (!"loggedOn".equals(state) && System.currentTimeMillis() < wait) Thread.sleep(300L);
        if (!"loggedOn".equals(state)) throw new Exception("Нет связи со Steam — подождите переподключения");
        long deadline = System.currentTimeMillis() + 20000L;
        while (!licensesReady && System.currentTimeMillis() < deadline) Thread.sleep(200L);
    }

    private List<PICSProductInfoCallback> picsBlocking(List<PICSRequest> apps, List<PICSRequest> packages) throws Exception {
        return steamApps.picsGetProductInfo(apps, packages, false)
                .toFuture().get(90, TimeUnit.SECONDS).getResults();
    }

    /** Список приложений, доступных аккаунту. */
    public JSONArray library(boolean onlyGames) throws Exception {
        requireLoggedOn();

        Set<Integer> appIds = new HashSet<>();
        List<PICSRequest> pkgReqs = new ArrayList<>();
        for (License l : licenses) {
            pkgReqs.add(new PICSRequest(l.getPackageID(), l.getAccessToken()));
        }

        log("Читаю пакеты аккаунта: " + pkgReqs.size());
        for (int i = 0; i < pkgReqs.size(); i += 200) {
            List<PICSRequest> chunk = pkgReqs.subList(i, Math.min(i + 200, pkgReqs.size()));
            for (PICSProductInfoCallback cb : picsBlocking(Collections.emptyList(), chunk)) {
                for (Map.Entry<Integer, PICSProductInfo> e : cb.getPackages().entrySet()) {
                    KeyValue kv = e.getValue().getKeyValues();
                    KeyValue ids = kv.get("appids");
                    if (ids == KeyValue.INVALID) {
                        // у корня иногда есть слой с id пакета
                        ids = kv.get(String.valueOf(e.getKey())).get("appids");
                    }
                    if (ids != KeyValue.INVALID) {
                        for (KeyValue child : ids.getChildren()) {
                            appIds.add(child.asInteger(0));
                        }
                    }
                }
            }
        }
        appIds.remove(0);

        List<Integer> all = new ArrayList<>(appIds);
        Collections.sort(all);
        log("Найдено приложений в пакетах: " + all.size());

        JSONArray out = new JSONArray();
        for (int i = 0; i < all.size(); i += 200) {
            List<Integer> chunk = all.subList(i, Math.min(i + 200, all.size()));

            PICSTokensCallback tokens = steamApps.picsGetAccessTokens(chunk, Collections.emptyList())
                    .toFuture().get(60, TimeUnit.SECONDS);

            List<PICSRequest> reqs = new ArrayList<>();
            for (Integer id : chunk) {
                Long t = tokens.getAppTokens().get(id);
                reqs.add(new PICSRequest(id, t == null ? 0L : t));
            }

            for (PICSProductInfoCallback cb : picsBlocking(reqs, Collections.emptyList())) {
                for (Map.Entry<Integer, PICSProductInfo> e : cb.getApps().entrySet()) {
                    KeyValue kv = e.getValue().getKeyValues();
                    KeyValue common = kv.get("common");
                    String name = common.get("name").asString();
                    String type = common.get("type").asString();
                    if (name == null) continue;
                    if (onlyGames && type != null && !type.isEmpty()
                            && !type.equalsIgnoreCase("game")
                            && !type.equalsIgnoreCase("application")) continue;

                    JSONObject o = new JSONObject();
                    o.put("appId", e.getKey());
                    o.put("name", name);
                    o.put("type", type == null ? "" : type.toLowerCase());
                    o.put("platforms", common.get("oslist").asString() == null ? "" : common.get("oslist").asString());
                    appCache.put(e.getKey(), o);
                    out.put(o);
                }
            }
            try {
                JSONObject p = new JSONObject();
                p.put("done", Math.min(i + 200, all.size()));
                p.put("total", all.size());
                emit("libraryProgress", p);
            } catch (Exception ignored) {
            }
        }
        log("В списке игр: " + out.length());
        writeFile("library.json", out.toString());
        return out;
    }

    /** Ветки (beta), депоты и размеры для одной игры. */
    public JSONObject appInfo(int appId) throws Exception {
        requireLoggedOn();

        PICSTokensCallback tokens = steamApps.picsGetAccessTokens(Collections.singletonList(appId), Collections.emptyList())
                .toFuture().get(60, TimeUnit.SECONDS);
        Long token = tokens.getAppTokens().get(appId);

        List<PICSRequest> reqs = new ArrayList<>();
        reqs.add(new PICSRequest(appId, token == null ? 0L : token));

        KeyValue root = null;
        for (PICSProductInfoCallback cb : picsBlocking(reqs, Collections.emptyList())) {
            PICSProductInfo info = cb.getApps().get(appId);
            if (info != null) root = info.getKeyValues();
        }
        if (root == null) throw new Exception("Steam не отдал сведения об игре " + appId);

        JSONObject out = new JSONObject();
        KeyValue common = root.get("common");
        out.put("appId", appId);
        out.put("name", common.get("name").asString() == null ? String.valueOf(appId) : common.get("name").asString());
        out.put("type", common.get("type").asString() == null ? "" : common.get("type").asString());
        out.put("platforms", common.get("oslist").asString() == null ? "" : common.get("oslist").asString());
        String installDir = root.get("config").get("installdir").asString();
        out.put("installDir", installDir == null ? "" : installDir);

        KeyValue depots = root.get("depots");

        JSONArray branches = new JSONArray();
        KeyValue br = depots.get("branches");
        if (br != KeyValue.INVALID) {
            for (KeyValue b : br.getChildren()) {
                JSONObject o = new JSONObject();
                o.put("name", b.getName());
                o.put("buildId", b.get("buildid").asString() == null ? "" : b.get("buildid").asString());
                o.put("description", b.get("description").asString() == null ? "" : b.get("description").asString());
                o.put("passwordRequired", b.get("pwdrequired").asBoolean(false));
                o.put("timeUpdated", b.get("timeupdated").asLong(0L));
                branches.put(o);
            }
        }
        out.put("branches", branches);

        JSONArray depotArr = new JSONArray();
        long totalSize = 0;
        for (KeyValue d : depots.getChildren()) {
            String n = d.getName();
            if (n == null) continue;
            boolean numeric = true;
            for (int i = 0; i < n.length(); i++) if (!Character.isDigit(n.charAt(i))) { numeric = false; break; }
            if (!numeric) continue;

            JSONObject o = new JSONObject();
            o.put("depotId", Integer.parseInt(n));
            o.put("name", d.get("name").asString() == null ? ("Depot " + n) : d.get("name").asString());
            KeyValue cfg = d.get("config");
            o.put("os", cfg.get("oslist").asString() == null ? "" : cfg.get("oslist").asString());
            o.put("arch", cfg.get("osarch").asString() == null ? "" : cfg.get("osarch").asString());
            o.put("language", cfg.get("language").asString() == null ? "" : cfg.get("language").asString());
            o.put("lowViolence", cfg.get("lowviolence").asBoolean(false));
            o.put("sharedFrom", d.get("depotfromapp").asString() == null ? "" : d.get("depotfromapp").asString());
            o.put("dlcAppId", d.get("dlcappid").asInteger(0));

            JSONObject perBranch = new JSONObject();
            KeyValue manifests = d.get("manifests");
            if (manifests != KeyValue.INVALID) {
                for (KeyValue m : manifests.getChildren()) {
                    JSONObject mo = new JSONObject();
                    mo.put("gid", m.get("gid").asString() == null ? m.asString() : m.get("gid").asString());
                    mo.put("size", m.get("size").asLong(0L));
                    mo.put("download", m.get("download").asLong(0L));
                    perBranch.put(m.getName(), mo);
                    if ("public".equals(m.getName())) totalSize += m.get("size").asLong(0L);
                }
            }
            o.put("manifests", perBranch);
            depotArr.put(o);
        }
        out.put("depots", depotArr);
        out.put("publicSize", totalSize);

        // дополнения: берём список из Steam и подтягиваем их названия
        JSONArray dlc = new JSONArray();
        String listOfDlc = root.get("extended").get("listofdlc").asString();
        List<Integer> dlcIds = new ArrayList<>();
        if (listOfDlc != null && !listOfDlc.isEmpty()) {
            for (String part : listOfDlc.split(",")) {
                try {
                    dlcIds.add(Integer.parseInt(part.trim()));
                } catch (Throwable ignored) {
                }
            }
        }
        if (!dlcIds.isEmpty()) {
            Map<Integer, String> names = appNames(dlcIds);
            for (Integer id : dlcIds) {
                JSONObject o = new JSONObject();
                o.put("appId", id);
                o.put("name", names.containsKey(id) ? names.get(id) : ("Дополнение " + id));
                // есть ли у дополнения собственные файлы внутри этой игры
                boolean files = false;
                for (int i = 0; i < depotArr.length(); i++) {
                    if (depotArr.getJSONObject(i).optInt("dlcAppId", 0) == id) {
                        files = true;
                        break;
                    }
                }
                o.put("hasFiles", files);
                dlc.put(o);
            }
        }
        out.put("dlc", dlc);
        return out;
    }

    /** Названия приложений по их номерам. */
    private Map<Integer, String> appNames(List<Integer> ids) {
        Map<Integer, String> out = new LinkedHashMap<>();
        try {
            for (int i = 0; i < ids.size(); i += 100) {
                List<Integer> chunk = ids.subList(i, Math.min(i + 100, ids.size()));
                PICSTokensCallback tokens = steamApps.picsGetAccessTokens(chunk, Collections.emptyList())
                        .toFuture().get(60, TimeUnit.SECONDS);
                List<PICSRequest> reqs = new ArrayList<>();
                for (Integer id : chunk) {
                    Long t = tokens.getAppTokens().get(id);
                    reqs.add(new PICSRequest(id, t == null ? 0L : t));
                }
                for (PICSProductInfoCallback cb : picsBlocking(reqs, Collections.emptyList())) {
                    for (Map.Entry<Integer, PICSProductInfo> e : cb.getApps().entrySet()) {
                        String n = e.getValue().getKeyValues().get("common").get("name").asString();
                        if (n != null) out.put(e.getKey(), n);
                    }
                }
            }
        } catch (Throwable ignored) {
        }
        return out;
    }

    // endregion

    /** Список серверов Steam, откуда можно качать. */
    public JSONArray servers() throws Exception {
        requireLoggedOn();
        java.util.List<Server> list = kotlinx.coroutines.future.FutureKt.asCompletableFuture(
                steamContent.getServersForSteamPipe(
                        client.getCellID() == null ? 0 : client.getCellID(), 50,
                        kotlinx.coroutines.GlobalScope.INSTANCE
                )
        ).get(60, TimeUnit.SECONDS);

        JSONArray out = new JSONArray();
        for (Server sv : list) {
            if (sv.getHost() == null) continue;
            String type = sv.getType() == null ? "" : sv.getType();
            if (!"CDN".equals(type) && !"SteamCache".equals(type)) continue;
            JSONObject o = new JSONObject();
            o.put("host", sv.getHost());
            o.put("type", type);
            o.put("cellId", sv.getCellId());
            o.put("load", sv.getLoad());
            o.put("weighted", sv.getWeightedLoad());
            out.put(o);
        }
        log("Серверов загрузки найдено: " + out.length());
        return out;
    }

    public String currentServer() {
        return prefs.getString("cdnHost", "");
    }

    public void setServer(String host) {
        prefs.edit().putString("cdnHost", host == null ? "" : host).apply();
        in.dragonbra.javasteam.depotdownloader.CDNClientPool.setPreferredHost(
                host == null || host.isEmpty() ? null : host);
        log(host == null || host.isEmpty() ? "Сервер загрузки: ближайший" : "Сервер загрузки: " + host);
    }

    // region скачивание

    public boolean isDownloading() {
        return downloadThread != null && downloadThread.isAlive();
    }

    // region очередь загрузок

    private final List<JSONObject> tasks = Collections.synchronizedList(new ArrayList<JSONObject>());
    private volatile boolean queueRunning;
    private volatile boolean pauseRequested;
    private volatile int currentTaskApp;

    private void loadTasks() {
        if (!tasks.isEmpty()) return;
        String raw = readFile("tasks.json");
        if (raw == null) return;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject t = arr.getJSONObject(i);
                if ("running".equals(t.optString("status"))) t.put("status", "paused");
                tasks.add(t);
            }
        } catch (Throwable ignored) {
        }
    }

    private void saveTasks() {
        JSONArray arr = new JSONArray();
        synchronized (tasks) {
            for (JSONObject t : tasks) arr.put(t);
        }
        writeFile("tasks.json", arr.toString());
    }

    private void emitTasks() {
        try {
            JSONObject o = new JSONObject();
            o.put("tasks", tasksJson());
            emit("tasks", o);
        } catch (Exception ignored) {
        }
    }

    public JSONArray tasksJson() {
        loadTasks();
        JSONArray arr = new JSONArray();
        synchronized (tasks) {
            for (JSONObject t : tasks) arr.put(t);
        }
        return arr;
    }

    private JSONObject findTask(int appId) {
        loadTasks();
        synchronized (tasks) {
            for (JSONObject t : tasks) if (t.optInt("appId") == appId) return t;
        }
        return null;
    }

    private void setTaskStatus(JSONObject task, String status, String error) {
        if (task == null) return;
        try {
            task.put("status", status);
            task.put("error", error == null ? "" : error);
        } catch (Exception ignored) {
        }
        saveTasks();
        emitTasks();
    }

    private void updateTaskProgress(JSONObject task, float percent, long downloaded, long speed) {
        if (task == null) return;
        try {
            task.put("percent", percent);
            task.put("downloaded", downloaded);
            task.put("speed", speed);
        } catch (Exception ignored) {
        }
        emitTasks();
    }

    /** Поставить игру в очередь. Уже была — просто запускаем снова, недостающее докачается. */
    public void addTask(JSONObject p) throws Exception {
        loadTasks();
        int appId = p.optInt("appId", 0);
        JSONObject t = findTask(appId);
        if (t == null) {
            t = new JSONObject();
            t.put("appId", appId);
            tasks.add(t);
        }
        t.put("name", p.optString("appName", String.valueOf(appId)));
        t.put("params", p);
        t.put("status", "queued");
        t.put("speed", 0);
        t.put("error", "");
        t.put("dir", p.optString("dir", DslPaths.defaultRoot()));
        t.put("folder", p.optString("installDir", ""));
        saveTasks();
        emitTasks();
        startQueue();
    }

    public void pauseTask(int appId) {
        JSONObject t = findTask(appId);
        if (t == null) return;
        if (appId == currentTaskApp && isDownloading()) {
            pauseRequested = true;
            cancelDownload();
        }
        setTaskStatus(t, "paused", "");
    }

    public void resumeTask(int appId) {
        JSONObject t = findTask(appId);
        if (t == null) return;
        setTaskStatus(t, "queued", "");
        startQueue();
    }

    public void removeTask(int appId, boolean withFiles) {
        JSONObject t = findTask(appId);
        if (t == null) return;
        if (appId == currentTaskApp && isDownloading()) {
            pauseRequested = true;
            cancelDownload();
        }
        if (withFiles) {
            String dir = t.optString("dir", "");
            String folder = t.optString("folder", "");
            if (!dir.isEmpty() && !folder.isEmpty()) {
                deleteTree(new java.io.File(new java.io.File(dir), folder));
                log("Удалены файлы: " + dir + "/" + folder);
            }
        }
        synchronized (tasks) {
            tasks.remove(t);
        }
        saveTasks();
        emitTasks();
    }

    private void deleteTree(java.io.File f) {
        if (f == null || !f.exists()) return;
        java.io.File[] kids = f.listFiles();
        if (kids != null) for (java.io.File k : kids) deleteTree(k);
        //noinspection ResultOfMethodCallIgnored
        f.delete();
    }

    private synchronized void startQueue() {
        if (queueRunning) return;
        queueRunning = true;
        Thread q = new Thread(() -> {
            try {
                while (running) {
                    JSONObject next = null;
                    synchronized (tasks) {
                        for (JSONObject t : tasks) {
                            if ("queued".equals(t.optString("status"))) {
                                next = t;
                                break;
                            }
                        }
                    }
                    if (next == null) break;
                    runTask(next);
                }
            } finally {
                queueRunning = false;
                DownloadService.stop(ctx);
            }
        }, "dsl-queue");
        q.setDaemon(true);
        q.start();
    }

    private void runTask(JSONObject t) {
        currentTaskApp = t.optInt("appId");
        pauseRequested = false;
        cancelRequested = false;
        setTaskStatus(t, "running", "");
        DownloadService.start(ctx);

        JSONObject params = t.optJSONObject("params");
        if (params == null) params = new JSONObject();

        downloadThread = Thread.currentThread();
        runDownload(params, t);
        downloadThread = null;
        currentTaskApp = 0;
        saveTasks();
        emitTasks();
    }

    public void startDownload(final JSONObject p) throws Exception {
        requireLoggedOn();
        addTask(p);
    }

    // endregion

    private void runDownload(JSONObject p, JSONObject task) {
        DepotDownloader dd = null;
        int appId = p.optInt("appId", 0);
        String appName = p.optString("appName", String.valueOf(appId));
        final long[] counters = new long[]{0L, 0L, System.currentTimeMillis(), 0L}; // compressed, uncompressed, t0, lastEmit

        try {
            List<Integer> depotIds = new ArrayList<>();
            JSONArray da = p.optJSONArray("depots");
            if (da != null) for (int i = 0; i < da.length(); i++) depotIds.add(da.getInt(i));

            List<Long> manifestIds = new ArrayList<>();
            JSONArray ma = p.optJSONArray("manifests");
            if (ma != null) for (int i = 0; i < ma.length(); i++) manifestIds.add(Long.parseLong(ma.getString(i)));

            String branch = p.optString("branch", "public");
            String password = p.optString("branchPassword", "");
            String os = p.optString("os", "windows");
            String arch = p.optString("arch", "64");
            String language = p.optString("language", "english");
            boolean allPlatforms = p.optBoolean("allPlatforms", false);
            boolean allArchs = p.optBoolean("allArchs", false);
            boolean allLanguages = p.optBoolean("allLanguages", false);
            boolean lowViolence = p.optBoolean("lowViolence", false);
            boolean manifestOnly = p.optBoolean("manifestOnly", false);
            boolean verify = p.optBoolean("verify", false);
            String dir = p.optString("dir", DslPaths.defaultRoot());
            int maxDownloads = Math.max(1, Math.min(32, p.optInt("maxDownloads", 8)));

            DslPaths.ensure(dir);
            java.io.File probe = new java.io.File(dir);
            if (!probe.exists() || !probe.canWrite()) {
                throw new Exception("Нет доступа к папке " + dir
                        + ". Разрешите доступ ко всем файлам в настройках приложения.");
            }
            log("Папка загрузки готова: " + dir);

            hookLibraryLog();
            dd = new DepotDownloader(client, licenses, true, false, maxDownloads, 8, 1, true, null);
            downloader = dd;

            dd.addListener(new IDownloadListener() {
                @Override
                public void onItemAdded(DownloadItem item) {
                }

                @Override
                public void onDownloadStarted(DownloadItem item) {
                    emitProgress("started", appId, appName, 0f, counters, "");
                }

                @Override
                public void onDownloadCompleted(DownloadItem item) {
                    emitProgress("completed", appId, appName, 1f, counters, "");
                }

                @Override
                public void onDownloadFailed(DownloadItem item, Throwable error) {
                    emitProgress("failed", appId, appName, 0f, counters, String.valueOf(error.getMessage()));
                }

                @Override
                public void onStatusUpdate(String message) {
                    log(message);
                }

                @Override
                public void onFileCompleted(int depotId, String fileName, float depotPercentComplete) {
                    emitProgress("file", appId, appName, depotPercentComplete, counters, fileName);
                }

                @Override
                public void onChunkCompleted(int depotId, float depotPercentComplete, long compressedBytes, long uncompressedBytes) {
                    counters[0] = compressedBytes;
                    counters[1] = uncompressedBytes;
                    long now = System.currentTimeMillis();
                    if (now - counters[3] < 400L) return;
                    counters[3] = now;
                    long elapsed = Math.max(1L, now - counters[2]);
                    updateTaskProgress(task, depotPercentComplete, compressedBytes, compressedBytes * 1000L / elapsed);
                    emitProgress("progress", appId, appName, depotPercentComplete, counters, "");
                }

                @Override
                public void onDepotCompleted(int depotId, long compressedBytes, long uncompressedBytes) {
                    log("Депот " + depotId + " готов");
                }
            });

            AppItem item = new AppItem(
                    appId,
                    p.optBoolean("nameFolder", true),
                    dir,
                    branch,
                    password,
                    allPlatforms,
                    os,
                    allArchs,
                    arch,
                    allLanguages,
                    language,
                    lowViolence,
                    depotIds,
                    manifestIds,
                    verify,
                    manifestOnly
            );

            log("Задача отправлена загрузчику, жду ответа Steam…");
            final long[] lastMove = new long[]{System.currentTimeMillis()};
            Thread watch = new Thread(() -> {
                while (isDownloading()) {
                    try {
                        Thread.sleep(20000L);
                    } catch (Throwable ignored) {
                        return;
                    }
                    if (counters[0] > 0) {
                        lastMove[0] = System.currentTimeMillis();
                    } else if (System.currentTimeMillis() - lastMove[0] > 60000L) {
                        log("Больше минуты нет ни одного скачанного куска — Steam не отдаёт файлы. Проверь доступ к папке и связь.");
                        lastMove[0] = System.currentTimeMillis();
                    }
                }
            }, "dsl-watch");
            watch.setDaemon(true);
            watch.start();

            dd.add(item);
            dd.finishAdding();
            dd.awaitCompletion();

            if (!cancelRequested) {
                if (!manifestOnly) rememberInstalled(appId, appName, branch, os, dir);
                updateTaskProgress(task, 1f, counters[0], 0L);
                setTaskStatus(task, "done", "");
                emitProgress("completed", appId, appName, 1f, counters, "");
            }
        } catch (Throwable t) {
            if (pauseRequested || cancelRequested) {
                setTaskStatus(task, "paused", "");
                emitProgress("paused", appId, appName, 0f, counters, "");
            } else {
                setTaskStatus(task, "failed", String.valueOf(t.getMessage()));
                emitProgress("failed", appId, appName, 0f, counters, String.valueOf(t.getMessage()));
            }
        } finally {
            try {
                if (dd != null) dd.close();
            } catch (Throwable ignored) {
            }
            downloader = null;
            downloadThread = null;
        }
    }

    private void emitProgress(String kind, int appId, String appName, float percent, long[] counters, String extra) {
        try {
            long elapsed = Math.max(1L, System.currentTimeMillis() - counters[2]);
            JSONObject o = new JSONObject();
            o.put("kind", kind);
            o.put("appId", appId);
            o.put("appName", appName);
            o.put("percent", Math.max(0f, Math.min(1f, percent)));
            o.put("compressed", counters[0]);
            o.put("uncompressed", counters[1]);
            o.put("speed", counters[0] * 1000L / elapsed);
            o.put("extra", extra == null ? "" : extra);
            emit("download", o);
            DownloadService.update(ctx, appName, (int) (percent * 100), kind);
        } catch (Exception ignored) {
        }
    }

    public void cancelDownload() {
        cancelRequested = true;
        DepotDownloader dd = downloader;
        if (dd != null) {
            try {
                dd.close();
            } catch (Throwable ignored) {
            }
        }
        Thread t = downloadThread;
        if (t != null) t.interrupt();
    }

    // endregion
}
