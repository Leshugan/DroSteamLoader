import React, { useEffect, useMemo, useRef, useState } from 'react'
import { registerPlugin } from '@capacitor/core'

const Steam = registerPlugin('Steam')

const OS_TITLE = { windows: 'Windows', linux: 'Linux', macos: 'macOS' }
const LANGS = ['english', 'russian', 'german', 'french', 'spanish', 'schinese', 'japanese']

const STATE_TEXT = {
  offline: 'не подключено',
  connecting: 'подключаюсь…',
  reconnecting: 'восстанавливаю связь…',
  loggingOn: 'вхожу…',
  guard: 'Steam Guard',
  qr: 'QR-код',
  error: 'ошибка'
}

function stateText (s) {
  if (s.state === 'loggedOn') return s.account
  return STATE_TEXT[s.state] || s.state
}

function fmtBytes (n) {
  if (!n) return '0 Б'
  const u = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ']
  let i = 0
  let v = Number(n)
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++ }
  return v.toFixed(v >= 10 || i === 0 ? 0 : 1) + ' ' + u[i]
}

function fmtDate (sec) {
  if (!sec) return ''
  try { return new Date(Number(sec) * 1000).toLocaleDateString('ru-RU') } catch { return '' }
}

function Cover ({ app }) {
  const urls = [
    `https://cdn.cloudflare.steampowered.com/steam/apps/${app.appId}/library_600x900.jpg`,
    `https://cdn.cloudflare.steampowered.com/steam/apps/${app.appId}/header.jpg`
  ]
  const [idx, setIdx] = useState(0)
  if (idx >= urls.length) {
    return <div className="cover fallback"><span>{app.name}</span></div>
  }
  return (
    <img
      className="cover"
      src={urls[idx]}
      alt={app.name}
      loading="lazy"
      onError={() => setIdx(i => i + 1)}
    />
  )
}

export default function App () {
  const [tab, setTab] = useState('library')
  const [status, setStatus] = useState({ state: 'offline', account: '', hasSaved: false, savedAccount: '' })
  const [menuOpen, setMenuOpen] = useState(false)
  const [logLines, setLogLines] = useState([])
  const [guard, setGuard] = useState(null)
  const [guardCode, setGuardCode] = useState('')
  const [qrUrl, setQrUrl] = useState('')
  const [error, setError] = useState('')

  const [user, setUser] = useState('')
  const [pass, setPass] = useState('')

  const [apps, setApps] = useState([])
  const [installed, setInstalled] = useState({})
  const [updates, setUpdates] = useState([])
  const [libLoading, setLibLoading] = useState(false)
  const [libProgress, setLibProgress] = useState(null)
  const [search, setSearch] = useState('')

  const [dialog, setDialog] = useState(null)   // { app, info, loading }
  const [os, setOs] = useState('windows')
  const [arch, setArch] = useState('64')
  const [branch, setBranch] = useState('public')
  const [branchPassword, setBranchPassword] = useState('')
  const [language, setLanguage] = useState('russian')
  const [withDlc, setWithDlc] = useState(true)

  const [dir, setDir] = useState('')
  const [free, setFree] = useState(0)
  const [threads, setThreads] = useState(8)

  const [dl, setDl] = useState(null)
  const logRef = useRef(null)
  const startedRef = useRef(false)

  useEffect(() => {
    const subs = []
    Steam.addListener('state', s => {
      setStatus(v => ({ ...v, state: s.state, account: s.account }))
      if (s.state === 'error') setError(s.error || 'Ошибка')
      if (['loggedOn', 'connecting', 'reconnecting'].includes(s.state)) setError('')
      if (s.state === 'loggedOn') {
        setGuard(null)
        setQrUrl('')
        refreshInBackground()
      }
    }).then(h => subs.push(h))
    Steam.addListener('log', s => setLogLines(l => [...l.slice(-300), s.message])).then(h => subs.push(h))
    Steam.addListener('guard', s => { setGuard(s); setTab('login') }).then(h => subs.push(h))
    Steam.addListener('qr', s => setQrUrl(s.url)).then(h => subs.push(h))
    Steam.addListener('libraryProgress', s => setLibProgress(s)).then(h => subs.push(h))
    Steam.addListener('download', s => {
      setDl(s)
      if (['completed', 'failed', 'cancelled'].includes(s.kind)) Steam.downloadFinished()
    }).then(h => subs.push(h))

    // 1) мгновенно показываем сохранённые карточки
    Steam.cachedLibrary().then(r => {
      setApps(r.apps || [])
      setInstalled(r.installed || {})
    })

    // 2) входим сохранённым ключом и обновляем список в фоне
    Steam.status().then(s => {
      setStatus(s)
      if (s.state !== 'loggedOn' && s.hasSaved) Steam.loginSaved().catch(() => {})
      if (s.state !== 'loggedOn' && !s.hasSaved) setTab('login')
      if (s.state === 'loggedOn') refreshInBackground()
    })

    Steam.storageInfo({}).then(s => { setDir(s.dir); setFree(s.free) })

    return () => { subs.forEach(h => h && h.remove && h.remove()) }
  }, [])

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight
  }, [logLines])

  // обновление списка игр и проверка обновлений — один раз за запуск
  async function refreshInBackground () {
    if (startedRef.current) return
    startedRef.current = true
    try {
      const r = await Steam.library({ onlyGames: true })
      const list = (r.apps || []).sort((a, b) => a.name.localeCompare(b.name))
      if (list.length) setApps(list)
    } catch (e) {
      setLogLines(l => [...l, 'Список игр: ' + String(e.message || e)])
    }
    try {
      const u = await Steam.checkUpdates()
      setUpdates(u.updates || [])
    } catch { /* обновления не критичны */ }
    try {
      const c = await Steam.cachedLibrary()
      setInstalled(c.installed || {})
    } catch { /* пусто */ }
  }

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    const list = q ? apps.filter(a => a.name.toLowerCase().includes(q) || String(a.appId) === q) : apps
    return list.slice(0, 600)
  }, [apps, search])

  const updateFor = id => updates.find(u => u.appId === id)

  async function doLogin () {
    setError('')
    try { await Steam.login({ username: user, password: pass }) } catch (e) { setError(String(e.message || e)) }
  }
  async function doLoginQr () {
    setError('')
    try { await Steam.loginQr() } catch (e) { setError(String(e.message || e)) }
  }
  async function sendGuard () {
    await Steam.submitGuard({ code: guardCode.trim() })
    setGuardCode('')
    setGuard(null)
  }
  async function doLogout () {
    setMenuOpen(false)
    await Steam.logout()
    startedRef.current = false
    setTab('login')
  }

  // ——— диалог скачивания ———

  async function openDialog (a) {
    setDialog({ app: a, info: null, loading: true })
    setBranchPassword('')
    try {
      const info = await Steam.appInfo({ appId: a.appId })
      const platforms = availablePlatforms(info)
      const first = platforms[0] || 'windows'
      setOs(first)
      const names = (info.branches || []).map(b => b.name)
      setBranch(names.includes('public') ? 'public' : (names[0] || 'public'))
      setWithDlc(true)
      setDialog({ app: a, info, loading: false })
    } catch (e) {
      setDialog(null)
      setError(String(e.message || e))
    }
  }

  function availablePlatforms (info) {
    const set = new Set()
    for (const d of info.depots || []) {
      if (!d.os) continue
      for (const p of d.os.split(',')) {
        const v = p.trim().toLowerCase()
        if (OS_TITLE[v]) set.add(v)
      }
    }
    if (!set.size) {
      for (const p of (info.platforms || '').split(',')) {
        const v = p.trim().toLowerCase()
        if (OS_TITLE[v]) set.add(v)
      }
    }
    if (!set.size) set.add('windows')
    return ['windows', 'linux', 'macos'].filter(p => set.has(p))
  }

  const dialogDepots = useMemo(() => {
    if (!dialog?.info) return []
    return (dialog.info.depots || []).filter(d => {
      if (d.os && !d.os.split(',').map(s => s.trim()).includes(os)) return false
      return true
    })
  }, [dialog, os])

  const hasDlc = useMemo(() => {
    if (!dialog?.info) return false
    if ((dialog.info.dlc || []).length) return true
    return (dialog.info.depots || []).some(d => Number(d.dlcAppId) > 0)
  }, [dialog])

  const archOptions = useMemo(() => {
    const set = new Set()
    for (const d of dialogDepots) if (d.arch) set.add(d.arch.trim())
    return set.size ? Array.from(set) : []
  }, [dialogDepots])

  const dialogSize = useMemo(() => {
    let total = 0
    for (const d of dialogDepots) {
      if (!withDlc && Number(d.dlcAppId) > 0) continue
      const m = d.manifests?.[branch] || d.manifests?.public
      if (m) total += Number(m.size || 0)
    }
    return total
  }, [dialogDepots, branch, withDlc])

  const branchObj = useMemo(
    () => (dialog?.info?.branches || []).find(b => b.name === branch) || null,
    [dialog, branch]
  )

  async function startDownload () {
    if (!dialog?.app) return
    setError('')
    // без DLC — перечисляем нужные депоты сами, иначе отдаём выбор Steam
    const depots = withDlc ? [] : dialogDepots.filter(d => !Number(d.dlcAppId)).map(d => d.depotId)
    try {
      await Steam.startDownload({
        appId: dialog.app.appId,
        appName: dialog.app.name,
        branch,
        branchPassword,
        os,
        arch: archOptions.length ? arch : '64',
        language,
        allLanguages: false,
        allPlatforms: false,
        allArchs: archOptions.length === 0,
        lowViolence: false,
        manifestOnly: false,
        nameFolder: true,
        dir,
        maxDownloads: Number(threads) || 8,
        depots,
        manifests: []
      })
      setDl({ kind: 'started', appName: dialog.app.name, percent: 0 })
      setDialog(null)
      setTab('downloads')
    } catch (e) {
      setError(String(e.message || e))
    }
  }

  return (
    <div className="app">
      <div className="head">
        <h1>DroSteamLoader</h1>
        <span className="acc" onClick={() => setMenuOpen(v => !v)}>
          {stateText(status)} ▾
        </span>
        {menuOpen && (
          <div className="menu">
            <button onClick={() => { setMenuOpen(false); setTab('login') }}>Сменить аккаунт</button>
            <button onClick={doLogout}>Выход</button>
          </div>
        )}
      </div>

      <div className="body" onClick={() => menuOpen && setMenuOpen(false)}>
        {error ? <div className="card"><span className="err">{error}</span></div> : null}

        {tab === 'library' && (
          <>
            <div className="searchbar">
              <input placeholder="Поиск по названию или ID" value={search} onChange={e => setSearch(e.target.value)} />
              {libLoading || libProgress ? <span className="muted">обновляю…</span> : <span className="muted">{apps.length} игр</span>}
            </div>

            {apps.length === 0 && (
              <div className="card">
                <h2>Библиотека пуста</h2>
                <p className="muted">Список подтянется сам после входа в Steam. Если он не появился — загляни в «Загрузки» → «Журнал».</p>
                <button className="ghost" onClick={() => { startedRef.current = false; refreshInBackground() }}>
                  Обновить сейчас
                </button>
              </div>
            )}

            <div className="grid">
              {filtered.map(a => {
                const up = updateFor(a.appId)
                const inst = installed[String(a.appId)]
                return (
                  <div className="tile" key={a.appId} onClick={() => openDialog(a)}>
                    <Cover app={a} />
                    {up && <span className="badge upd">обновление</span>}
                    {!up && inst && <span className="badge inst">скачано</span>}
                    <div className="tname">{a.name}</div>
                  </div>
                )
              })}
            </div>
          </>
        )}

        {tab === 'downloads' && (
          <>
            <div className="card">
              <h2>{dl?.appName || 'Загрузок нет'}</h2>
              {dl && (
                <>
                  <div className="bar"><div style={{ width: (100 * (dl.percent || 0)) + '%' }} /></div>
                  <div className="muted">
                    {(100 * (dl.percent || 0)).toFixed(1)}% · скачано {fmtBytes(dl.compressed)} · {fmtBytes(dl.speed)}/с
                  </div>
                  <div className="muted">
                    {dl.kind === 'completed' ? 'Готово'
                      : dl.kind === 'failed' ? ('Ошибка: ' + dl.extra)
                        : dl.kind === 'cancelled' ? 'Отменено' : (dl.extra || '')}
                  </div>
                  {!['completed', 'failed', 'cancelled'].includes(dl.kind) && (
                    <button className="ghost" onClick={() => Steam.cancelDownload()}>Отменить</button>
                  )}
                </>
              )}
            </div>

            {updates.length > 0 && (
              <div className="card">
                <h2>Вышли обновления</h2>
                {updates.map(u => (
                  <div className="item" key={u.appId}>
                    <div className="name">
                      {u.name}
                      <div className="sub">ветка {u.branch} · сборка {u.oldBuildId} → {u.newBuildId}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="card">
              <h2>Журнал</h2>
              <div className="log" ref={logRef}>{logLines.join('\n')}</div>
            </div>
          </>
        )}

        {tab === 'login' && (
          <>
            <div className="card">
              <h2>Вход в Steam</h2>
              {status.hasSaved && (
                <button className="ghost" onClick={() => Steam.loginSaved()}>
                  Войти как {status.savedAccount}
                </button>
              )}
              <label>Логин</label>
              <input value={user} onChange={e => setUser(e.target.value)} autoCapitalize="none" autoCorrect="off" />
              <label>Пароль</label>
              <input type="password" value={pass} onChange={e => setPass(e.target.value)} />
              <button className="primary" onClick={doLogin}>Войти</button>
              <button className="ghost" onClick={doLoginQr}>Вход по QR-коду</button>
            </div>

            {guard && (
              <div className="card">
                <h2>Steam Guard</h2>
                <p className="muted">
                  {guard.kind === 'email'
                    ? 'Код отправлен на почту ' + (guard.email || '')
                    : guard.kind === 'confirm'
                      ? 'Подтвердите вход в приложении Steam. Если не приходит — введите код ниже.'
                      : 'Введите код из приложения Steam Guard'}
                  {guard.wrong ? ' (прошлый код не подошёл)' : ''}
                </p>
                <input value={guardCode} onChange={e => setGuardCode(e.target.value)} autoCapitalize="characters" />
                <button className="primary" onClick={sendGuard}>Отправить код</button>
              </div>
            )}

            {qrUrl && (
              <div className="card center">
                <h2>QR для входа</h2>
                <img
                  alt="QR"
                  style={{ width: '70%', maxWidth: 260 }}
                  src={'https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=' + encodeURIComponent(qrUrl)}
                />
                <p className="muted">Отсканируйте в приложении Steam</p>
              </div>
            )}
          </>
        )}

        {tab === 'settings' && (
          <div className="card">
            <h2>Настройки</h2>
            <label>Папка загрузок</label>
            <input value={dir} onChange={e => setDir(e.target.value)} />
            <p className="muted">Свободно: {fmtBytes(free)}</p>
            <label>Потоков загрузки</label>
            <select value={threads} onChange={e => setThreads(e.target.value)}>
              {[4, 8, 12, 16, 24].map(n => <option key={n} value={n}>{n}</option>)}
            </select>
            <label>Язык игр по умолчанию</label>
            <select value={language} onChange={e => setLanguage(e.target.value)}>
              {LANGS.map(l => <option key={l} value={l}>{l}</option>)}
            </select>
            <button className="ghost" onClick={() => Steam.requestStorageAccess()}>Доступ ко всем файлам</button>
            <button className="ghost" onClick={doLogout}>Выйти из аккаунта</button>
          </div>
        )}
      </div>

      {dialog && (
        <div className="sheetbg" onClick={() => setDialog(null)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            <h2>{dialog.app.name}</h2>

            {dialog.loading && <p className="muted">Спрашиваю Steam о версиях…</p>}

            {dialog.info && (
              <>
                <label>Платформа</label>
                <div>
                  {availablePlatforms(dialog.info).map(p => (
                    <span key={p} className={'chip ' + (os === p ? 'on' : '')} onClick={() => setOs(p)}>
                      {OS_TITLE[p]}
                    </span>
                  ))}
                </div>

                <label>Версия</label>
                <select value={branch} onChange={e => setBranch(e.target.value)}>
                  {(dialog.info.branches || []).map(b => (
                    <option key={b.name} value={b.name}>
                      {b.name === 'public' ? 'обычная (public)' : b.name}
                      {b.passwordRequired ? ' 🔒' : ''} · сборка {b.buildId}
                      {b.timeUpdated ? ' · ' + fmtDate(b.timeUpdated) : ''}
                    </option>
                  ))}
                </select>
                {branchObj?.description ? <p className="muted">{branchObj.description}</p> : null}
                {branchObj?.passwordRequired && (
                  <>
                    <label>Пароль ветки</label>
                    <input value={branchPassword} onChange={e => setBranchPassword(e.target.value)} />
                  </>
                )}

                {hasDlc && (
                  <>
                    <label>Дополнения (DLC)</label>
                    <div>
                      <span className={'chip ' + (withDlc ? 'on' : '')} onClick={() => setWithDlc(true)}>с DLC</span>
                      <span className={'chip ' + (!withDlc ? 'on' : '')} onClick={() => setWithDlc(false)}>без DLC</span>
                    </div>
                  </>
                )}

                {archOptions.length > 1 && (
                  <>
                    <label>Разрядность</label>
                    <select value={arch} onChange={e => setArch(e.target.value)}>
                      {archOptions.map(a => <option key={a} value={a}>{a} бит</option>)}
                    </select>
                  </>
                )}

                <label>Язык</label>
                <select value={language} onChange={e => setLanguage(e.target.value)}>
                  {LANGS.map(l => <option key={l} value={l}>{l}</option>)}
                </select>

                <p className="muted">
                  Примерный размер: {fmtBytes(dialogSize)} · свободно {fmtBytes(free)}
                </p>
                <p className="muted">Куда: {dir}</p>

                <button className="primary" onClick={startDownload}>Скачать</button>
                <button className="ghost" onClick={() => setDialog(null)}>Отмена</button>
              </>
            )}
          </div>
        </div>
      )}

      <div className="tabs">
        <button className={tab === 'library' ? 'on' : ''} onClick={() => setTab('library')}>Библиотека</button>
        <button className={tab === 'downloads' ? 'on' : ''} onClick={() => setTab('downloads')}>Загрузки</button>
        <button className={tab === 'settings' ? 'on' : ''} onClick={() => setTab('settings')}>⚙ Настройки</button>
      </div>
    </div>
  )
}
