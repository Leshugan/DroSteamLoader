import React, { useEffect, useMemo, useRef, useState } from 'react'
import { registerPlugin } from '@capacitor/core'

const Steam = registerPlugin('Steam')

const OS_LIST = [
  { id: 'windows', title: 'Windows' },
  { id: 'linux', title: 'Linux' },
  { id: 'macos', title: 'macOS' }
]
const ARCH_LIST = ['64', '32']
const LANGS = ['english', 'russian', 'german', 'french', 'spanish', 'schinese', 'japanese']

function fmtBytes (n) {
  if (!n) return '0 Б'
  const u = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ']
  let i = 0
  let v = Number(n)
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++ }
  return v.toFixed(v >= 10 || i === 0 ? 0 : 1) + ' ' + u[i]
}

function fmtDate (sec) {
  if (!sec) return ''
  try { return new Date(Number(sec) * 1000).toLocaleDateString('ru-RU') } catch { return '' }
}

const STATE_TEXT = {
  offline: 'не подключено',
  connecting: 'подключаюсь…',
  reconnecting: 'восстанавливаю связь…',
  loggingOn: 'вхожу…',
  guard: 'Steam Guard',
  qr: 'QR-код',
  error: 'ошибка'
}

function stateText (s) {
  if (s.state === 'loggedOn') return s.account
  return STATE_TEXT[s.state] || s.state
}

export default function App () {
  const [tab, setTab] = useState('login')
  const [status, setStatus] = useState({ state: 'offline', account: '', hasSaved: false, savedAccount: '' })
  const [logLines, setLogLines] = useState([])
  const [guard, setGuard] = useState(null)
  const [guardCode, setGuardCode] = useState('')
  const [qrUrl, setQrUrl] = useState('')
  const [error, setError] = useState('')

  const [user, setUser] = useState('')
  const [pass, setPass] = useState('')

  const [apps, setApps] = useState([])
  const [libLoading, setLibLoading] = useState(false)
  const [libProgress, setLibProgress] = useState(null)
  const [search, setSearch] = useState('')
  const [onlyGames, setOnlyGames] = useState(true)

  const [sel, setSel] = useState(null)
  const [info, setInfo] = useState(null)
  const [infoLoading, setInfoLoading] = useState(false)

  const [branch, setBranch] = useState('public')
  const [branchPassword, setBranchPassword] = useState('')
  const [os, setOs] = useState('windows')
  const [arch, setArch] = useState('64')
  const [language, setLanguage] = useState('english')
  const [allLanguages, setAllLanguages] = useState(false)
  const [allPlatforms, setAllPlatforms] = useState(false)
  const [lowViolence, setLowViolence] = useState(false)
  const [manifestOnly, setManifestOnly] = useState(false)
  const [pickedDepots, setPickedDepots] = useState([])
  const [manualManifest, setManualManifest] = useState('')
  const [dir, setDir] = useState('')
  const [free, setFree] = useState(0)
  const [threads, setThreads] = useState(8)

  const [dl, setDl] = useState(null)
  const logRef = useRef(null)

  useEffect(() => {
    const subs = []
    Steam.addListener('state', s => {
      setStatus(v => ({ ...v, state: s.state, account: s.account }))
      if (s.state === 'loggedOn') { setGuard(null); setQrUrl(''); setTab('library') }
      if (s.state === 'error') setError(s.error || 'Ошибка')
      if (s.state === 'loggedOn' || s.state === 'connecting' || s.state === 'reconnecting') setError('')
    }).then(h => subs.push(h))
    Steam.addListener('log', s => setLogLines(l => [...l.slice(-300), s.message])).then(h => subs.push(h))
    Steam.addListener('guard', s => setGuard(s)).then(h => subs.push(h))
    Steam.addListener('qr', s => setQrUrl(s.url)).then(h => subs.push(h))
    Steam.addListener('libraryProgress', s => setLibProgress(s)).then(h => subs.push(h))
    Steam.addListener('download', s => {
      setDl(s)
      if (['completed', 'failed', 'cancelled'].includes(s.kind)) Steam.downloadFinished()
    }).then(h => subs.push(h))

    Steam.status().then(s => {
      setStatus(s)
      if (s.state === 'loggedOn') setTab('library')
    })
    Steam.storageInfo({}).then(s => { setDir(s.dir); setFree(s.free) })
    Steam.hasStorageAccess().then(s => { if (!s.granted) setError('Нужен доступ ко всем файлам — кнопка ниже') })

    return () => { subs.forEach(h => h && h.remove && h.remove()) }
  }, [])

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight
  }, [logLines])

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    const list = q ? apps.filter(a => a.name.toLowerCase().includes(q) || String(a.appId) === q) : apps
    return list.slice(0, 400)
  }, [apps, search])

  async function doLogin () {
    setError('')
    try { await Steam.login({ username: user, password: pass }) } catch (e) { setError(String(e.message || e)) }
  }
  async function doLoginSaved () {
    setError('')
    try { await Steam.loginSaved() } catch (e) { setError(String(e.message || e)) }
  }
  async function doLoginQr () {
    setError('')
    try { await Steam.loginQr() } catch (e) { setError(String(e.message || e)) }
  }
  async function sendGuard () {
    await Steam.submitGuard({ code: guardCode.trim() })
    setGuardCode('')
    setGuard(null)
  }

  async function loadLibrary () {
    setLibLoading(true)
    setError('')
    setLibProgress(null)
    try {
      const r = await Steam.library({ onlyGames })
      setApps((r.apps || []).sort((a, b) => a.name.localeCompare(b.name)))
    } catch (e) {
      setError(String(e.message || e))
    } finally {
      setLibLoading(false)
      setLibProgress(null)
    }
  }

  async function openApp (a) {
    setSel(a)
    setInfo(null)
    setInfoLoading(true)
    setError('')
    setTab('app')
    setPickedDepots([])
    setManualManifest('')
    try {
      const r = await Steam.appInfo({ appId: a.appId })
      setInfo(r)
      const names = (r.branches || []).map(b => b.name)
      setBranch(names.includes('public') ? 'public' : (names[0] || 'public'))
      const plat = (r.platforms || '').toLowerCase()
      if (plat && !plat.includes('windows')) setOs(plat.includes('linux') ? 'linux' : 'macos')
    } catch (e) {
      setError(String(e.message || e))
    } finally {
      setInfoLoading(false)
    }
  }

  const depotsForOs = useMemo(() => {
    if (!info) return []
    return (info.depots || []).filter(d => {
      if (allPlatforms) return true
      if (!d.os) return true
      return d.os.split(',').map(s => s.trim()).includes(os)
    })
  }, [info, os, allPlatforms])

  const branchObj = useMemo(
    () => (info?.branches || []).find(b => b.name === branch) || null,
    [info, branch]
  )

  const sizeForBranch = useMemo(() => {
    if (!info) return 0
    let total = 0
    for (const d of depotsForOs) {
      const m = d.manifests?.[branch] || d.manifests?.public
      if (m) total += Number(m.size || 0)
    }
    return total
  }, [info, depotsForOs, branch])

  async function start () {
    setError('')
    if (!sel) return
    const depots = pickedDepots.length ? pickedDepots : []
    const manifests = []
    if (manualManifest.trim() && depots.length === 1) manifests.push(manualManifest.trim())
    try {
      await Steam.startDownload({
        appId: sel.appId,
        appName: sel.name,
        branch,
        branchPassword,
        os,
        arch,
        language,
        allLanguages,
        allPlatforms,
        allArchs: false,
        lowViolence,
        manifestOnly,
        nameFolder: true,
        dir,
        maxDownloads: Number(threads) || 8,
        depots,
        manifests
      })
      setDl({ kind: 'started', appName: sel.name, percent: 0 })
      setTab('downloads')
    } catch (e) {
      setError(String(e.message || e))
    }
  }

  return (
    <div className="app">
      <div className="head">
        <h1>DroSteamLoader</h1>
        <span className="acc">{stateText(status)}</span>
      </div>

      <div className="body">
        {error ? <div className="card"><span className="err">{error}</span></div> : null}

        {tab === 'login' && (
          <>
            <div className="card">
              <h2>Вход в Steam</h2>
              {status.hasSaved && (
                <button className="ghost" onClick={doLoginSaved}>
                  Войти как {status.savedAccount}
                </button>
              )}
              <label>Логин</label>
              <input value={user} onChange={e => setUser(e.target.value)} autoCapitalize="none" autoCorrect="off" />
              <label>Пароль</label>
              <input type="password" value={pass} onChange={e => setPass(e.target.value)} />
              <button className="primary" onClick={doLogin}>Войти</button>
              <button className="ghost" onClick={doLoginQr}>Вход по QR-коду</button>
              <p className="muted">
                Вход официальный, через серверы Steam. Пароль никуда, кроме Steam, не уходит и не сохраняется —
                сохраняется только ключ сессии.
              </p>
            </div>

            {qrUrl && (
              <div className="card center">
                <h2>QR для входа</h2>
                <img
                  alt="QR"
                  style={{ width: '70%', maxWidth: 260 }}
                  src={'https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=' + encodeURIComponent(qrUrl)}
                />
                <p className="muted">Отсканируйте в мобильном приложении Steam</p>
              </div>
            )}

            <div className="card">
              <h2>Доступ к памяти</h2>
              <p className="muted">Нужен, чтобы складывать игры в обычную папку, а не во внутренний каталог.</p>
              <button className="ghost" onClick={() => Steam.requestStorageAccess()}>Разрешить доступ ко всем файлам</button>
            </div>
          </>
        )}

        {guard && (
          <div className="card">
            <h2>Steam Guard</h2>
            <p className="muted">
              {guard.kind === 'email'
                ? 'Код отправлен на почту ' + (guard.email || '')
                : guard.kind === 'confirm'
                  ? 'Подтвердите вход в мобильном приложении Steam. Если не приходит — введите код ниже.'
                  : 'Введите код из приложения Steam Guard'}
              {guard.wrong ? ' (прошлый код не подошёл)' : ''}
            </p>
            <input value={guardCode} onChange={e => setGuardCode(e.target.value)} autoCapitalize="characters" />
            <button className="primary" onClick={sendGuard}>Отправить код</button>
          </div>
        )}

        {tab === 'library' && (
          <>
            <div className="card">
              <div className="row">
                <input placeholder="Поиск по названию или ID" value={search} onChange={e => setSearch(e.target.value)} />
              </div>
              <div style={{ marginTop: 8 }}>
                <span className={'chip ' + (onlyGames ? 'on' : '')} onClick={() => setOnlyGames(v => !v)}>
                  только игры
                </span>
                <span className="chip">{apps.length} шт.</span>
              </div>
              <button className="primary" onClick={loadLibrary} disabled={libLoading}>
                {libLoading ? 'Гружу…' : 'Обновить библиотеку'}
              </button>
              {libProgress && (
                <div className="bar"><div style={{ width: (100 * libProgress.done / libProgress.total) + '%' }} /></div>
              )}
            </div>

            {filtered.map(a => (
              <div className="item" key={a.appId} onClick={() => openApp(a)}>
                <div className="name">
                  {a.name}
                  <div className="sub">{a.appId} · {a.platforms || '—'}</div>
                </div>
                <span className="chip">открыть</span>
              </div>
            ))}
          </>
        )}

        {tab === 'app' && sel && (
          <>
            <div className="card">
              <h2>{sel.name}</h2>
              <div className="sub muted">appId {sel.appId}</div>
              {infoLoading && <p className="muted">Читаю сведения из Steam…</p>}
            </div>

            {info && (
              <>
                <div className="card">
                  <h2>Версия / ветка</h2>
                  <select value={branch} onChange={e => setBranch(e.target.value)}>
                    {(info.branches || []).map(b => (
                      <option key={b.name} value={b.name}>
                        {b.name}{b.passwordRequired ? ' 🔒' : ''} · build {b.buildId} · {fmtDate(b.timeUpdated)}
                      </option>
                    ))}
                  </select>
                  {branchObj?.description ? <p className="muted">{branchObj.description}</p> : null}
                  {branchObj?.passwordRequired && (
                    <>
                      <label>Пароль ветки</label>
                      <input value={branchPassword} onChange={e => setBranchPassword(e.target.value)} />
                    </>
                  )}
                </div>

                <div className="card">
                  <h2>Платформа</h2>
                  <div>
                    {OS_LIST.map(o => (
                      <span key={o.id} className={'chip ' + (os === o.id ? 'on' : '')} onClick={() => setOs(o.id)}>
                        {o.title}
                      </span>
                    ))}
                  </div>
                  <label>Разрядность</label>
                  <select value={arch} onChange={e => setArch(e.target.value)}>
                    {ARCH_LIST.map(a => <option key={a} value={a}>{a} бит</option>)}
                  </select>
                  <label>Язык</label>
                  <select value={language} onChange={e => setLanguage(e.target.value)} disabled={allLanguages}>
                    {LANGS.map(l => <option key={l} value={l}>{l}</option>)}
                  </select>
                  <div style={{ marginTop: 8 }}>
                    <span className={'chip ' + (allLanguages ? 'on' : '')} onClick={() => setAllLanguages(v => !v)}>все языки</span>
                    <span className={'chip ' + (allPlatforms ? 'on' : '')} onClick={() => setAllPlatforms(v => !v)}>все платформы</span>
                    <span className={'chip ' + (lowViolence ? 'on' : '')} onClick={() => setLowViolence(v => !v)}>low violence</span>
                    <span className={'chip ' + (manifestOnly ? 'on' : '')} onClick={() => setManifestOnly(v => !v)}>только манифест</span>
                  </div>
                </div>

                <div className="card">
                  <h2>Файлы (депоты)</h2>
                  <p className="muted">
                    Ничего не отмечено — качается всё, что подходит под платформу и язык. Примерный размер: {fmtBytes(sizeForBranch)}
                  </p>
                  {depotsForOs.map(d => {
                    const on = pickedDepots.includes(d.depotId)
                    const m = d.manifests?.[branch] || d.manifests?.public
                    return (
                      <div
                        className={'item ' + (on ? 'sel' : '')}
                        key={d.depotId}
                        onClick={() => setPickedDepots(v => on ? v.filter(x => x !== d.depotId) : [...v, d.depotId])}
                      >
                        <div className="name">
                          {d.name}
                          <div className="sub">
                            {d.depotId} · {d.os || 'любая ОС'} {d.arch ? '· ' + d.arch : ''} {d.language ? '· ' + d.language : ''}
                            {m ? ' · ' + fmtBytes(m.size) : ''}
                          </div>
                        </div>
                        <span className={'chip ' + (on ? 'on' : '')}>{on ? '✓' : '+'}</span>
                      </div>
                    )
                  })}
                  {pickedDepots.length === 1 && (
                    <>
                      <label>ID манифеста (если нужна конкретная старая версия)</label>
                      <input value={manualManifest} onChange={e => setManualManifest(e.target.value)} inputMode="numeric" />
                    </>
                  )}
                </div>

                <div className="card">
                  <h2>Куда качать</h2>
                  <input value={dir} onChange={e => setDir(e.target.value)} />
                  <p className="muted">Свободно: {fmtBytes(free)}</p>
                  <label>Потоков загрузки</label>
                  <select value={threads} onChange={e => setThreads(e.target.value)}>
                    {[4, 8, 12, 16, 24].map(n => <option key={n} value={n}>{n}</option>)}
                  </select>
                  <button className="primary" onClick={start}>Скачать</button>
                </div>
              </>
            )}
          </>
        )}

        {tab === 'downloads' && (
          <>
            <div className="card">
              <h2>{dl?.appName || 'Загрузок нет'}</h2>
              {dl && (
                <>
                  <div className="bar"><div style={{ width: (100 * (dl.percent || 0)) + '%' }} /></div>
                  <div className="muted">
                    {(100 * (dl.percent || 0)).toFixed(1)}% · скачано {fmtBytes(dl.compressed)} · {fmtBytes(dl.speed)}/с
                  </div>
                  <div className="muted">
                    {dl.kind === 'completed' ? 'Готово' : dl.kind === 'failed' ? ('Ошибка: ' + dl.extra) : dl.kind === 'cancelled' ? 'Отменено' : (dl.extra || '')}
                  </div>
                  {!['completed', 'failed', 'cancelled'].includes(dl.kind) && (
                    <button className="ghost" onClick={() => Steam.cancelDownload()}>Отменить</button>
                  )}
                </>
              )}
            </div>
            <div className="card">
              <h2>Журнал</h2>
              <div className="log" ref={logRef}>{logLines.join('\n')}</div>
            </div>
          </>
        )}

        {tab === 'settings' && (
          <div className="card">
            <h2>Настройки</h2>
            <label>Папка загрузок</label>
            <input value={dir} onChange={e => setDir(e.target.value)} />
            <button className="ghost" onClick={() => Steam.requestStorageAccess()}>Доступ ко всем файлам</button>
            <button className="ghost" onClick={() => Steam.logout().then(() => setTab('login'))}>Выйти из аккаунта</button>
            <p className="muted">Вход и скачивание идут через официальные серверы Steam по вашему аккаунту.</p>
          </div>
        )}
      </div>

      <div className="tabs">
        <button className={tab === 'library' ? 'on' : ''} onClick={() => setTab('library')}>Библиотека</button>
        <button className={tab === 'downloads' ? 'on' : ''} onClick={() => setTab('downloads')}>Загрузки</button>
        <button className={tab === 'app' ? 'on' : ''} onClick={() => setTab('app')} disabled={!sel}>Игра</button>
        <button className={tab === 'login' ? 'on' : ''} onClick={() => setTab('login')}>Вход</button>
        <button className={tab === 'settings' ? 'on' : ''} onClick={() => setTab('settings')}>⚙</button>
      </div>
    </div>
  )
}
