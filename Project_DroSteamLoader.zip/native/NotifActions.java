package leshugan.DSL;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Кнопки уведомления. Отдельный приёмник, объявленный в манифесте, а не внутри службы:
 * на паузе служба останавливается, и приёмник внутри неё умирал вместе с ней —
 * поэтому кнопка «Возобновить» раньше не работала.
 */
public class NotifActions extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (context == null || intent == null || intent.getAction() == null) return;

        // номер игры кладём в само намерение: статические поля не переживают
        // выгрузку приложения из памяти
        int appId = intent.getIntExtra("appId", 0);

        try {
            SteamCore core = SteamCore.get(context.getApplicationContext());
            String a = intent.getAction();

            if (DownloadService.ACTION_PAUSE.equals(a)) {
                core.pauseTask(appId);
            } else if (DownloadService.ACTION_RESUME.equals(a)) {
                core.resumeTask(appId);
            } else if (DownloadService.ACTION_CANCEL.equals(a)) {
                core.removeTask(appId, false);
                DownloadService.dismiss(context);
            } else if (DownloadService.ACTION_CLOSE.equals(a)) {
                DownloadService.dismiss(context);
            }
        } catch (Throwable ignored) {
        }
    }
}
