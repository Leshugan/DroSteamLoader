package leshugan.DSL;

import android.os.Environment;

import java.io.File;

public class DslPaths {

    public static String defaultRoot() {
        // по умолчанию — папка «Загрузки» телефона
        File dl = new File(Environment.getExternalStorageDirectory(), "Download");
        if (!dl.exists()) dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        File f = new File(dl, "DroSteamLoader");
        return f.getAbsolutePath();
    }

    public static void ensure(String path) {
        File f = new File(path);
        if (!f.exists()) //noinspection ResultOfMethodCallIgnored
            f.mkdirs();
    }

    public static long freeSpace(String path) {
        try {
            File f = new File(path);
            while (f != null && !f.exists()) f = f.getParentFile();
            return f == null ? 0L : f.getUsableSpace();
        } catch (Throwable t) {
            return 0L;
        }
    }
}
