import React, { useEffect, useMemo, useRef, useState } from 'react'
import { registerPlugin, Capacitor } from '@capacitor/core'
import { App as CapApp } from '@capacitor/app'

const Steam = registerPlugin('Steam')

const OS_TITLE = { windows: 'Windows', linux: 'Linux', macos: 'macOS' }
const LANGS = ['english', 'russian', 'german', 'french', 'spanish', 'schinese', 'japanese']
const CDN = 'https://shared.cloudflare.steamstatic.com/store_item_assets/steam/apps/'
const PAGE = 24

const STATE_TEXT = {
  offline: 'не подключено',
  connecting: 'подключаюсь…',
  reconnecting: 'восстанавливаю связь…',
  loggingOn: 'вхожу…',
  guard: 'Steam Guard',
  qr: 'QR-код',
  error: 'ошибка'
}

function stateText (s) {
  if (s.state === 'loggedOn') return s.account
  return STATE_TEXT[s.state] || s.state
}

function fmtBytes (n) {
  if (!n) return '0 Б'
  const u = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ']
  let i = 0
  let v = Number(n)
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++ }
  return v.toFixed(v >= 10 || i === 0 ? 0 : 1) + ' ' + u[i]
}

function fmtDate (sec) {
  if (!sec) return ''
  try { return new Date(Number(sec) * 1000).toLocaleDateString('ru-RU') } catch { return '' }
}

function fmtTime (sec) {
  if (!sec || !isFinite(sec) || sec <= 0) return '—'
  const s = Math.round(sec)
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const r = s % 60
  if (h) return h + ' ч ' + m + ' мин'
  if (m) return m + ' мин ' + r + ' с'
  return r + ' с'
}

/** Обложка: берём из кэша на телефоне, скачивается один раз. */
function Cover ({ app }) {
  const [src, setSrc] = useState(null)
  const [missing, setMissing] = useState(false)
  const boxRef = useRef(null)

  useEffect(() => {
    let alive = true
    let io = null
    const load = () => {
      Steam.cover({ appId: app.appId }).then(r => {
        if (!alive) return
        if (r.missing || !r.path) setMissing(true)
        else setSrc(Capacitor.convertFileSrc(r.path))
      }).catch(() => alive && setMissing(true))
    }
    // качаем только то, что рядом с экраном
    if (typeof IntersectionObserver !== 'undefined' && boxRef.current) {
      io = new IntersectionObserver(entries => {
        if (entries.some(e => e.isIntersecting)) {
          io.disconnect()
          load()
        }
      }, { rootMargin: '400px' })
      io.observe(boxRef.current)
    } else {
      load()
    }
    return () => { alive = false; if (io) io.disconnect() }
  }, [app.appId])

  return (
    <div className="shot" ref={boxRef}>
      {src && <img className="cover" src={src} alt="" decoding="async" />}
      {!src && <div className="cover fallback"><span>{missing ? app.name : ''}</span></div>}
    </div>
  )
}

/** Простой выбор папки по дереву телефона. */
function FolderPicker ({ start, onPick, onClose }) {
  const [data, setData] = useState(null)
  useEffect(() => { load(start || '/storage/emulated/0') }, [])
  async function load (path) {
    try {
      const r = await Steam.listFolders({ path })
      setData(r)
    } catch {
      setData({ path, parent: '', items: [] })
    }
  }
  return (
    <div className="sheetbg" onClick={onClose}>
      <div className="sheet" onClick={e => e.stopPropagation()}>
        <h2>Куда сохранять</h2>
        <p className="muted">{data ? data.path : 'читаю…'}</p>
        {data?.parent ? (
          <div className="item" onClick={() => load(data.parent)}><div className="name">⬅ наверх</div></div>
        ) : null}
        {(data?.items || []).map(f => (
          <div className="item" key={f.path} onClick={() => load(f.path)}>
            <div className="name">📁 {f.name}</div>
          </div>
        ))}
        <button className="primary" onClick={() => { onPick(data.path); onClose() }}>Выбрать эту папку</button>
        <button className="ghost" onClick={onClose}>Отмена</button>
      </div>
    </div>
  )
}

export default function App () {
  const [tab, setTab] = useState('library')
  const [status, setStatus] = useState({ state: 'offline', account: '', hasSaved: false, savedAccount: '' })
  const [menuOpen, setMenuOpen] = useState(false)
  const [logLines, setLogLines] = useState([])
  const [guard, setGuard] = useState(null)
  const [guardCode, setGuardCode] = useState('')
  const [qrUrl, setQrUrl] = useState('')
  const [error, setError] = useState('')

  const [user, setUser] = useState('')
  const [pass, setPass] = useState('')

  const [apps, setApps] = useState([])
  const [installed, setInstalled] = useState({})
  const [updates, setUpdates] = useState([])
  const [refreshing, setRefreshing] = useState(false)
  const [search, setSearch] = useState('')
  const [shown, setShown] = useState(PAGE)

  const [dialog, setDialog] = useState(null)
  const [os, setOs] = useState('windows')
  const [arch, setArch] = useState('64')
  const [branch, setBranch] = useState('public')
  const [branchPassword, setBranchPassword] = useState('')
  const [language, setLanguage] = useState('russian')
  const [dlcMode, setDlcMode] = useState('all')      // all | none | pick
  const [pickedDlc, setPickedDlc] = useState([])
  const [oldVersion, setOldVersion] = useState(false)
  const [oldDepot, setOldDepot] = useState('')
  const [oldManifest, setOldManifest] = useState('')

  const [dir, setDir] = useState('')
  const [free, setFree] = useState(0)
  const [threads, setThreads] = useState(8)
  const [showApps, setShowApps] = useState(() => {
    try { return localStorage.getItem('showApps') === '1' } catch { return false }
  })
  const [picker, setPicker] = useState(null)
  const [advanced, setAdvanced] = useState(false)
  const [servers, setServers] = useState([])
  const [server, setServer] = useState('')
  const [serversLoading, setServersLoading] = useState(false)         // 'dialog' | 'settings'

  const [dl, setDl] = useState(null)
  const [tasks, setTasks] = useState([])
  const [dlTotal, setDlTotal] = useState(0)
  const [dlStart, setDlStart] = useState(0)
  const [askDelete, setAskDelete] = useState(null)
  const logRef = useRef(null)
  const startedRef = useRef(false)
  const bodyRef = useRef(null)
  const backRef = useRef(() => false)

  useEffect(() => {
    const subs = []
    Steam.addListener('state', s => {
      setStatus(v => ({ ...v, state: s.state, account: s.account }))
      if (s.state === 'error') setError(s.error || 'Ошибка')
      if (['loggedOn', 'connecting', 'reconnecting'].includes(s.state)) setError('')
      if (s.state === 'loggedOn') {
        setGuard(null)
        setQrUrl('')
        refreshInBackground()
      }
    }).then(h => subs.push(h))
    Steam.addListener('log', s => setLogLines(l => [...l.slice(-300), s.message])).then(h => subs.push(h))
    Steam.addListener('guard', s => { setGuard(s); setTab('login') }).then(h => subs.push(h))
    Steam.addListener('qr', s => setQrUrl(s.url)).then(h => subs.push(h))
    Steam.addListener('download', s => setDl(s)).then(h => subs.push(h))
    Steam.addListener('tasks', s => setTasks(s.tasks || [])).then(h => subs.push(h))
    Steam.tasks().then(r => setTasks(r.tasks || []))

    const stateSub = CapApp.addListener('appStateChange', ({ isActive }) => {
      Steam.setBackground({ background: !isActive })
      if (isActive) Steam.tasks().then(r => setTasks(r.tasks || []))
    })
    stateSub.then(h => subs.push(h))

    const backSub = CapApp.addListener('backButton', () => {
      // закрываем то, что открыто сверху; с Библиотеки — выходим
      if (backRef.current()) return
      CapApp.exitApp()
    })
    backSub.then(h => subs.push(h))

    Steam.cachedLibrary().then(r => {
      setApps(r.apps || [])
      setInstalled(r.installed || {})
    })

    Steam.status().then(s => {
      setStatus(s)
      if (s.state !== 'loggedOn' && s.hasSaved) Steam.loginSaved().catch(() => {})
      if (s.state !== 'loggedOn' && !s.hasSaved) setTab('login')
      if (s.state === 'loggedOn') refreshInBackground()
    })

    Steam.storageInfo({}).then(s => { setDir(s.dir); setFree(s.free) })

    return () => { subs.forEach(h => h && h.remove && h.remove()) }
  }, [])

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight
  }, [logLines])

  backRef.current = () => {
    if (picker) { setPicker(null); return true }
    if (askDelete) { setAskDelete(null); return true }
    if (dialog) { setDialog(null); return true }
    if (menuOpen) { setMenuOpen(false); return true }
    if (search) { setSearch(''); return true }
    if (tab !== 'library') { setTab('library'); return true }
    return false
  }

  async function refreshInBackground () {
    if (startedRef.current) return
    startedRef.current = true
    setRefreshing(true)
    try {
      const r = await Steam.library({ onlyGames: !showApps })
      const list = (r.apps || []).sort((a, b) => a.name.localeCompare(b.name))
      if (list.length) setApps(list)
    } catch (e) {
      setLogLines(l => [...l, 'Список игр: ' + String(e.message || e)])
    }
    setRefreshing(false)
    try {
      const u = await Steam.checkUpdates()
      setUpdates(u.updates || [])
    } catch { /* не критично */ }
    try {
      const c = await Steam.cachedLibrary()
      setInstalled(c.installed || {})
    } catch { /* пусто */ }
  }

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return q ? apps.filter(a => a.name.toLowerCase().includes(q) || String(a.appId) === q) : apps
  }, [apps, search])

  useEffect(() => { setShown(PAGE) }, [search])

  function onScroll (e) {
    const el = e.currentTarget
    if (el.scrollTop + el.clientHeight > el.scrollHeight - 400) {
      setShown(v => (v < filtered.length ? v + PAGE : v))
    }
  }

  const updateFor = id => updates.find(u => u.appId === id)

  async function doLogin () {
    setError('')
    try { await Steam.login({ username: user, password: pass }) } catch (e) { setError(String(e.message || e)) }
  }
  async function doLoginQr () {
    setError('')
    try { await Steam.loginQr() } catch (e) { setError(String(e.message || e)) }
  }
  async function sendGuard () {
    await Steam.submitGuard({ code: guardCode.trim() })
    setGuardCode('')
    setGuard(null)
  }
  async function doLogout () {
    setMenuOpen(false)
    await Steam.logout()
    startedRef.current = false
    setTab('login')
  }

  // ——— окно скачивания ———

  async function openDialog (a) {
    setDialog({ app: a, info: null, loading: true })
    setBranchPassword('')
    setDlcMode('all')
    setPickedDlc([])
    setOldVersion(false)
    setOldManifest('')
    setOldDepot('')
    setAdvanced(false)
    try {
      const info = await Steam.appInfo({ appId: a.appId })
      const platforms = availablePlatforms(info)
      setOs(platforms[0] || 'windows')
      const names = (info.branches || []).map(b => b.name)
      setBranch(names.includes('public') ? 'public' : (names[0] || 'public'))
      setDialog({ app: a, info, loading: false })
    } catch (e) {
      setDialog(null)
      setError(String(e.message || e))
    }
  }

  function availablePlatforms (info) {
    const set = new Set()
    for (const d of info.depots || []) {
      if (!d.os) continue
      for (const p of d.os.split(',')) {
        const v = p.trim().toLowerCase()
        if (OS_TITLE[v]) set.add(v)
      }
    }
    if (!set.size) {
      for (const p of (info.platforms || '').split(',')) {
        const v = p.trim().toLowerCase()
        if (OS_TITLE[v]) set.add(v)
      }
    }
    if (!set.size) set.add('windows')
    return ['windows', 'linux', 'macos'].filter(p => set.has(p))
  }

  const platformDepots = useMemo(() => {
    if (!dialog?.info) return []
    return (dialog.info.depots || []).filter(d => {
      if (!d.os) return true
      return d.os.split(',').map(s => s.trim()).includes(os)
    })
  }, [dialog, os])

  const dlcList = useMemo(() => (dialog?.info?.dlc || []), [dialog])

  const baseDepots = useMemo(() => platformDepots.filter(d => !Number(d.dlcAppId)), [platformDepots])
  const dlcDepots = useMemo(() => platformDepots.filter(d => Number(d.dlcAppId) > 0), [platformDepots])

  const chosenDepots = useMemo(() => {
    if (dlcMode === 'all' && !oldVersion) return []            // пусть Steam сам решает
    let list = baseDepots.map(d => d.depotId)
    if (dlcMode === 'all') list = list.concat(dlcDepots.map(d => d.depotId))
    if (dlcMode === 'pick') list = list.concat(pickedDlc)
    return list
  }, [dlcMode, pickedDlc, baseDepots, dlcDepots, oldVersion])

  const sizeEstimate = useMemo(() => {
    let total = 0
    const wanted = dlcMode === 'all'
      ? platformDepots
      : platformDepots.filter(d => !Number(d.dlcAppId) || pickedDlc.includes(d.depotId))
    for (const d of wanted) {
      const m = d.manifests?.[branch] || d.manifests?.public
      if (m) total += Number(m.size || 0)
    }
    return total
  }, [platformDepots, branch, dlcMode, pickedDlc])

  const branchObj = useMemo(
    () => (dialog?.info?.branches || []).find(b => b.name === branch) || null,
    [dialog, branch]
  )

  const archOptions = useMemo(() => {
    const set = new Set()
    for (const d of platformDepots) if (d.arch) set.add(d.arch.trim())
    return Array.from(set)
  }, [platformDepots])

  async function startDownload () {
    if (!dialog?.app) return
    setError('')
    let depots = chosenDepots
    let manifests = []
    if (oldVersion && oldDepot && oldManifest.trim()) {
      depots = [Number(oldDepot)]
      manifests = [oldManifest.trim()]
    }
    try {
      await Steam.startDownload({
        appId: dialog.app.appId,
        appName: dialog.app.name,
        branch,
        branchPassword,
        os,
        arch: archOptions.length ? arch : '64',
        language,
        allLanguages: false,
        allPlatforms: false,
        allArchs: archOptions.length === 0,
        lowViolence: false,
        manifestOnly: false,
        nameFolder: true,
        installDir: dialog.info?.installDir || '',
        dir,
        maxDownloads: Number(threads) || 8,
        depots,
        manifests
      })
      setDlTotal(sizeEstimate)
      setDlStart(Date.now())
      setDl({ kind: 'started', appName: dialog.app.name, percent: 0 })
      setDialog(null)
      setTab('downloads')
    } catch (e) {
      setError(String(e.message || e))
    }
  }

  const eta = useMemo(() => {
    if (!dl || !dlStart) return null
    const p = Number(dl.percent || 0)
    if (p <= 0.01) return null
    const elapsed = (Date.now() - dlStart) / 1000
    return elapsed / p - elapsed
  }, [dl, dlStart])

  return (
    <div className="app">
      <div className="head">
        <h1>DroSteamLoader</h1>
        <span className="acc" onClick={() => setMenuOpen(v => !v)}>{stateText(status)} ▾</span>
        {menuOpen && (
          <div className="menu">
            <button onClick={() => { setMenuOpen(false); setTab('login') }}>Сменить аккаунт</button>
            <button onClick={doLogout}>Выход</button>
          </div>
        )}
      </div>

      <div className="body" ref={bodyRef} onScroll={onScroll} onClick={() => menuOpen && setMenuOpen(false)}>
        {error ? <div className="card"><span className="err">{error}</span></div> : null}

        {tab === 'library' && (
          <>
            <div className="searchbar">
              <input placeholder="Поиск по названию или ID" value={search} onChange={e => setSearch(e.target.value)} />
              <span className="muted">{refreshing ? 'обновляю…' : apps.length + ' игр'}</span>
            </div>

            {apps.length === 0 && (
              <div className="card">
                <h2>Библиотека пуста</h2>
                <p className="muted">Список подтянется сам после входа. Если пусто — загляни в «Загрузки» → «Журнал».</p>
                <button className="ghost" onClick={() => { startedRef.current = false; refreshInBackground() }}>
                  Обновить сейчас
                </button>
              </div>
            )}

            <div className="grid">
              {filtered.slice(0, shown).map(a => {
                const up = updateFor(a.appId)
                const inst = installed[String(a.appId)]
                return (
                  <div className="tile" key={a.appId} onClick={() => openDialog(a)}>
                    <Cover app={a} />
                    {up && <span className="badge upd">обновление</span>}
                    {!up && inst && <span className="badge inst">скачано</span>}
                    <div className="tname">{a.name}</div>
                  </div>
                )
              })}
            </div>

            {shown < filtered.length && (
              <button className="ghost" onClick={() => setShown(v => v + PAGE)}>
                Показать ещё ({filtered.length - shown})
              </button>
            )}
          </>
        )}

        {tab === 'downloads' && (
          <>
            {tasks.length === 0 && (
              <div className="card">
                <h2>Загрузок нет</h2>
                <p className="muted">Выбери игру в библиотеке — она встанет сюда в очередь.</p>
              </div>
            )}

            {tasks.map(t => {
              const st = t.status
              const pct = 100 * Number(t.percent || 0)
              return (
                <div className="card" key={t.appId}>
                  <h2>{t.name}</h2>
                  <div className="bar"><div style={{ width: pct + '%' }} /></div>
                  <div className="muted">
                    {pct.toFixed(1)}% · скачано {fmtBytes(t.downloaded)} · {fmtBytes(t.speed)}/с
                  </div>
                  <div className="muted">
                    {st === 'running' ? 'качается'
                      : st === 'queued' ? 'в очереди'
                        : st === 'paused' ? 'на паузе'
                          : st === 'done' ? 'готово'
                            : st === 'failed' ? ('ошибка: ' + (t.error || '')) : st}
                  </div>
                  <div className="row">
                    {st === 'running' && (
                      <button className="ghost" onClick={() => Steam.pauseTask({ appId: t.appId })}>Пауза</button>
                    )}
                    {(st === 'paused' || st === 'failed') && (
                      <button className="ghost" onClick={() => Steam.resumeTask({ appId: t.appId })}>Продолжить</button>
                    )}
                    {st === 'queued' && (
                      <button className="ghost" onClick={() => Steam.pauseTask({ appId: t.appId })}>Отложить</button>
                    )}
                    <button className="ghost" onClick={() => setAskDelete(t)}>Удалить</button>
                  </div>
                </div>
              )
            })}
          </>
        )}

        {tab === 'debug' && (
          <>
            <div className="card">
              <h2>Текущее событие</h2>
              <div className="muted">
                {dl
                  ? `${dl.appName} · ${(100 * (dl.percent || 0)).toFixed(1)}% · ${fmtBytes(dl.compressed)} · ${fmtBytes(dl.speed)}/с · осталось ${fmtTime(eta)}`
                  : 'нет'}
              </div>
            </div>

            {updates.length > 0 && (
              <div className="card">
                <h2>Вышли обновления</h2>
                {updates.map(u => (
                  <div className="item" key={u.appId}>
                    <div className="name">
                      {u.name}
                      <div className="sub">ветка {u.branch} · сборка {u.oldBuildId} → {u.newBuildId}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="card">
              <h2>Журнал</h2>
              <div className="log" ref={logRef}>{logLines.join('\n')}</div>
            </div>
          </>
        )}

        {tab === 'login' && (
          <>
            <div className="card">
              <h2>Вход в Steam</h2>
              {status.hasSaved && (
                <button className="ghost" onClick={() => Steam.loginSaved()}>
                  Войти как {status.savedAccount}
                </button>
              )}
              <label>Логин</label>
              <input value={user} onChange={e => setUser(e.target.value)} autoCapitalize="none" autoCorrect="off" />
              <label>Пароль</label>
              <input type="password" value={pass} onChange={e => setPass(e.target.value)} />
              <button className="primary" onClick={doLogin}>Войти</button>
              <button className="ghost" onClick={doLoginQr}>Вход по QR-коду</button>
            </div>

            {guard && (
              <div className="card">
                <h2>Steam Guard</h2>
                <p className="muted">
                  {guard.kind === 'email'
                    ? 'Код отправлен на почту ' + (guard.email || '')
                    : guard.kind === 'confirm'
                      ? 'Подтвердите вход в приложении Steam. Если не приходит — введите код ниже.'
                      : 'Введите код из приложения Steam Guard'}
                  {guard.wrong ? ' (прошлый код не подошёл)' : ''}
                </p>
                <input value={guardCode} onChange={e => setGuardCode(e.target.value)} autoCapitalize="characters" />
                <button className="primary" onClick={sendGuard}>Отправить код</button>
              </div>
            )}

            {qrUrl && (
              <div className="card center">
                <h2>QR для входа</h2>
                <img
                  alt="QR"
                  style={{ width: '70%', maxWidth: 260 }}
                  src={'https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=' + encodeURIComponent(qrUrl)}
                />
                <p className="muted">Отсканируйте в приложении Steam</p>
              </div>
            )}
          </>
        )}

        {tab === 'settings' && (
          <div className="card">
            <h2>Настройки</h2>
            <label>Папка загрузок</label>
            <input value={dir} onChange={e => setDir(e.target.value)} />
            <button className="ghost" onClick={() => setPicker('settings')}>Выбрать папку</button>
            <p className="muted">Свободно: {fmtBytes(free)}</p>
            <label>Потоков загрузки</label>
            <select value={threads} onChange={e => setThreads(e.target.value)}>
              {[4, 8, 12, 16, 24].map(n => <option key={n} value={n}>{n}</option>)}
            </select>
            <label>Язык игр по умолчанию</label>
            <select value={language} onChange={e => setLanguage(e.target.value)}>
              {LANGS.map(l => <option key={l} value={l}>{l}</option>)}
            </select>
            <label>Что показывать в библиотеке</label>
            <div
              className="check"
              onClick={() => {
                const v = !showApps
                setShowApps(v)
                try { localStorage.setItem('showApps', v ? '1' : '0') } catch {}
                startedRef.current = false
                refreshInBackground()
              }}
            >
              <span className={'box ' + (showApps ? 'on' : '')}>{showApps ? '✓' : ''}</span>
              Отображать программы (не только игры)
            </div>
            <label>Сервер загрузки</label>
            <select
              value={server}
              onChange={e => { setServer(e.target.value); Steam.setServer({ host: e.target.value }) }}
            >
              <option value="">Ближайший (выбирает Steam)</option>
              {servers.map(sv => (
                <option key={sv.host} value={sv.host}>
                  {sv.host} · загружен на {Math.round(sv.load)}%
                </option>
              ))}
            </select>
            <button
              className="ghost"
              disabled={serversLoading}
              onClick={async () => {
                setServersLoading(true)
                try {
                  const r = await Steam.servers()
                  setServers(r.servers || [])
                  setServer(r.current || '')
                } catch (e) {
                  setError(String(e.message || e))
                }
                setServersLoading(false)
              }}
            >
              {serversLoading ? 'Ищу серверы…' : 'Показать доступные серверы'}
            </button>

            <button className="ghost" onClick={() => Steam.requestStorageAccess()}>Доступ ко всем файлам</button>
            <button className="ghost" onClick={doLogout}>Выйти из аккаунта</button>
          </div>
        )}
      </div>

      {dialog && (
        <div className="sheetbg" onClick={() => setDialog(null)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            <h2>{dialog.app.name}</h2>
            {dialog.loading && <p className="muted">Смотрю, что доступно в Steam…</p>}

            {dialog.info && (
              <>
                <label>Для какой системы</label>
                <div>
                  {availablePlatforms(dialog.info).map(p => (
                    <span key={p} className={'chip ' + (os === p ? 'on' : '')} onClick={() => setOs(p)}>
                      {OS_TITLE[p]}
                    </span>
                  ))}
                </div>
                {availablePlatforms(dialog.info).length === 1 && (
                  <p className="muted">Других сборок у этой игры в Steam нет.</p>
                )}

                <label>Какую версию</label>
                <select value={branch} onChange={e => setBranch(e.target.value)}>
                  {(dialog.info.branches || []).map(b => (
                    <option key={b.name} value={b.name}>
                      {b.name === 'public' ? 'Основная (public)' : b.name}
                      {b.buildId ? ' · сборка ' + b.buildId : ''}
                      {b.timeUpdated ? ' · от ' + fmtDate(b.timeUpdated) : ''}
                      {b.passwordRequired ? ' · нужен пароль' : ''}
                    </option>
                  ))}
                </select>
                <p className="muted">
                  {branchObj?.description
                    ? branchObj.description
                    : (branch === 'public'
                        ? 'Та версия, которую Steam ставит всем по умолчанию.'
                        : 'Отдельная ветка разработчика — Steam выдаёт её под этим названием.')}
                </p>
                {branchObj?.passwordRequired && (
                  <>
                    <label>Пароль от тестовой версии</label>
                    <input value={branchPassword} onChange={e => setBranchPassword(e.target.value)} />
                  </>
                )}

                {(dlcList.length > 0 || dlcDepots.length > 0) && (
                  <>
                    <label>Дополнения (DLC)</label>
                    {dlcDepots.length > 0 ? (
                      <>
                        <div>
                          <span className={'chip ' + (dlcMode === 'all' ? 'on' : '')} onClick={() => setDlcMode('all')}>Скачать все</span>
                          <span className={'chip ' + (dlcMode === 'none' ? 'on' : '')} onClick={() => setDlcMode('none')}>Только игру</span>
                          <span className={'chip ' + (dlcMode === 'pick' ? 'on' : '')} onClick={() => setDlcMode('pick')}>Выбрать</span>
                        </div>
                        {dlcMode === 'pick' && dlcDepots.map(d => {
                          const on = pickedDlc.includes(d.depotId)
                          const m = d.manifests?.[branch] || d.manifests?.public
                          const named = dlcList.find(x => x.appId === Number(d.dlcAppId))
                          return (
                            <div
                              className={'item ' + (on ? 'sel' : '')}
                              key={d.depotId}
                              onClick={() => setPickedDlc(v => on ? v.filter(x => x !== d.depotId) : [...v, d.depotId])}
                            >
                              <div className="name">
                                {named ? named.name : d.name}
                                <div className="sub">{m ? fmtBytes(m.size) : ''}</div>
                              </div>
                              <span className={'chip ' + (on ? 'on' : '')}>{on ? '✓' : '+'}</span>
                            </div>
                          )
                        })}
                      </>
                    ) : (
                      <>
                        <p className="muted">
                          У этой игры {dlcList.length} дополнени{dlcList.length === 1 ? 'е' : 'й'}, но отдельных файлов
                          для них Steam не хранит — они уже внутри самой игры и включаются вашей покупкой.
                        </p>
                        {dlcList.slice(0, 12).map(d => (
                          <div className="item" key={d.appId}><div className="name">{d.name}</div></div>
                        ))}
                        {dlcList.length > 12 && <p className="muted">…и ещё {dlcList.length - 12}</p>}
                      </>
                    )}
                  </>
                )}

                <label>Язык игры</label>
                <select value={language} onChange={e => setLanguage(e.target.value)}>
                  {LANGS.map(l => <option key={l} value={l}>{l}</option>)}
                </select>

                <p className="muted">
                  Размер: примерно {fmtBytes(sizeEstimate)} · на телефоне свободно {fmtBytes(free)}
                </p>
                <p className="muted">Сохранится в: {dir}</p>

                <button className="primary" onClick={startDownload}>Скачать</button>

                <button className="ghost" onClick={() => setAdvanced(v => !v)}>
                  {advanced ? 'Скрыть тонкие настройки' : 'Тонкие настройки'}
                </button>

                {advanced && (
                  <>
                    {archOptions.length > 1 && (
                      <>
                        <label>Разрядность Windows</label>
                        <select value={arch} onChange={e => setArch(e.target.value)}>
                          {archOptions.map(a => <option key={a} value={a}>{a === '64' ? '64-битная' : '32-битная'}</option>)}
                        </select>
                      </>
                    )}

                    <label>Скачать старую версию игры</label>
                    <div>
                      <span className={'chip ' + (!oldVersion ? 'on' : '')} onClick={() => setOldVersion(false)}>Свежую</span>
                      <span className={'chip ' + (oldVersion ? 'on' : '')} onClick={() => setOldVersion(true)}>Старую по номеру</span>
                    </div>
                    {oldVersion && (
                      <>
                        <p className="muted">
                          Steam хранит только свежую версию каждой ветки и списка старых не выдаёт.
                          Номер старой версии смотрят на сайте SteamDB (страница игры → Depots → Manifests) и вписывают сюда.
                        </p>
                        <label>Часть игры, которую нужно откатить</label>
                        <select value={oldDepot} onChange={e => setOldDepot(e.target.value)}>
                          <option value="">— выбери —</option>
                          {platformDepots.map(d => (
                            <option key={d.depotId} value={d.depotId}>{d.name}</option>
                          ))}
                        </select>
                        <label>Номер версии со SteamDB</label>
                        <input value={oldManifest} onChange={e => setOldManifest(e.target.value)} inputMode="numeric" />
                      </>
                    )}

                    <label>Куда сохранить</label>
                    <input value={dir} onChange={e => setDir(e.target.value)} />
                    <button className="ghost" onClick={() => setPicker('dialog')}>Выбрать папку</button>
                  </>
                )}

                <button className="ghost" onClick={() => setDialog(null)}>Отмена</button>
              </>
            )}
          </div>
        </div>
      )}

      {askDelete && (
        <div className="sheetbg" onClick={() => setAskDelete(null)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            <h2>Удалить «{askDelete.name}»</h2>
            <p className="muted">Можно убрать только запись из списка, а скачанное оставить на телефоне.</p>
            <button className="ghost" onClick={() => { Steam.removeTask({ appId: askDelete.appId, withFiles: false }); setAskDelete(null) }}>
              Убрать только задачу
            </button>
            <button className="primary" onClick={() => { Steam.removeTask({ appId: askDelete.appId, withFiles: true }); setAskDelete(null) }}>
              Удалить вместе с файлами
            </button>
            <button className="ghost" onClick={() => setAskDelete(null)}>Отмена</button>
          </div>
        </div>
      )}

      {picker && (
        <FolderPicker
          start={dir}
          onClose={() => setPicker(null)}
          onPick={p => {
            setDir(p)
            Steam.storageInfo({ dir: p }).then(s => setFree(s.free)).catch(() => {})
          }}
        />
      )}

      <div className="tabs">
        <button className={tab === 'library' ? 'on' : ''} onClick={() => setTab('library')}>Библиотека</button>
        <button className={tab === 'downloads' ? 'on' : ''} onClick={() => setTab('downloads')}>Загрузки</button>
        <button className={tab === 'settings' ? 'on' : ''} onClick={() => setTab('settings')}>⚙ Настройки</button>
        <button className={tab === 'debug' ? 'on' : ''} onClick={() => setTab('debug')}>Отладка</button>
      </div>
    </div>
  )
}
