package leshugan.DSL;

import android.os.Environment;

import java.io.File;

public class DslPaths {

    public static String defaultRoot() {
        // по умолчанию — сама папка «Загрузки» телефона, без своей подпапки
        File dl = new File(Environment.getExternalStorageDirectory(), "Download");
        if (!dl.exists()) dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        return dl.getAbsolutePath();
    }

    /** Журнал кладём в свою подпапку, чтобы не сорить в «Загрузках». */
    public static String logsRoot() {
        return new File(defaultRoot(), "DroSteamLoader").getAbsolutePath();
    }

    public static void ensure(String path) {
        File f = new File(path);
        if (!f.exists()) //noinspection ResultOfMethodCallIgnored
            f.mkdirs();
    }

    public static long freeSpace(String path) {
        try {
            File f = new File(path);
            while (f != null && !f.exists()) f = f.getParentFile();
            return f == null ? 0L : f.getUsableSpace();
        } catch (Throwable t) {
            return 0L;
        }
    }
}
