package leshugan.DSL;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/**
 * Держит процесс живым, пока идёт скачивание, и показывает уведомление с прогрессом.
 */
public class DownloadService extends Service {

    private static final String CHANNEL = "dsl_downloads";
    private static final int NOTIF_ID = 4201;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel(this);
        startForeground(NOTIF_ID, build(this, "DroSteamLoader", 0, "waiting"));
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static void start(Context ctx) {
        Intent i = new Intent(ctx, DownloadService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(i);
        } else {
            ctx.startService(i);
        }
    }

    public static void stop(Context ctx) {
        ctx.stopService(new Intent(ctx, DownloadService.class));
    }

    public static void update(Context ctx, String title, int percent, String kind) {
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        if ("completed".equals(kind) || "failed".equals(kind) || "cancelled".equals(kind)) {
            nm.notify(NOTIF_ID, build(ctx, title, percent, kind));
            return;
        }
        nm.notify(NOTIF_ID, build(ctx, title, percent, kind));
    }

    private static void createChannel(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Загрузки", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
    }

    private static Notification build(Context ctx, String title, int percent, String kind) {
        createChannel(ctx);

        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open, flags);

        String text;
        boolean done = false;
        if ("completed".equals(kind)) {
            text = "Готово";
            done = true;
        } else if ("failed".equals(kind)) {
            text = "Ошибка";
            done = true;
        } else if ("cancelled".equals(kind)) {
            text = "Отменено";
            done = true;
        } else {
            text = percent + "%";
        }

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            b = new Notification.Builder(ctx, CHANNEL);
        } else {
            b = new Notification.Builder(ctx);
        }
        b.setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(ctx.getApplicationInfo().icon)
                .setOngoing(!done)
                .setOnlyAlertOnce(true)
                .setContentIntent(pi);
        if (!done) b.setProgress(100, Math.max(0, Math.min(100, percent)), percent <= 0);
        return b.build();
    }
}
