package `in`.dragonbra.javasteam.depotdownloader

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okio.FileSystem
import okio.Path

/**
 * Помнит, какие файлы уже полностью скачаны для каждой части игры (депота).
 *
 * Нужно, чтобы при продолжении прерванной загрузки не перечитывать и не пересчитывать
 * заново все уже готовые файлы игры — на больших играх это гигабайты и очень долгий старт.
 * Ключ файла — его имя вместе с хешем из манифеста, поэтому запись не подойдёт к другой
 * версии игры, а на диске проверяется ещё и наличие файла нужного размера.
 *
 * Сохраняется пачками (раз в несколько готовых файлов) и при остановке загрузчика, чтобы
 * не переписывать файл прогресса на каждый мелкий файл.
 */
@Serializable
data class DepotProgressStore(
    val completed: MutableMap<Int, MutableSet<String>> = mutableMapOf(),
) {
    companion object {
        private var instance: DepotProgressStore? = null

        private var filePath: Path? = null

        private val json = Json { ignoreUnknownKeys = true }

        private val lock = Any()

        private var dirtySinceSave = 0

        private const val SAVE_EVERY = 25

        fun loadFromFile(path: Path) {
            synchronized(lock) {
                instance = try {
                    if (FileSystem.SYSTEM.exists(path)) {
                        FileSystem.SYSTEM.read(path) {
                            json.decodeFromString<DepotProgressStore>(readUtf8())
                        }
                    } else {
                        DepotProgressStore()
                    }
                } catch (e: Exception) {
                    DepotProgressStore()
                }
                filePath = path
                dirtySinceSave = 0
            }
        }

        private fun key(fileName: String, fileHashHex: String): String = "$fileName\u0000$fileHashHex"

        fun isDone(depotId: Int, fileName: String, fileHashHex: String): Boolean = synchronized(lock) {
            instance?.completed?.get(depotId)?.contains(key(fileName, fileHashHex)) == true
        }

        fun markDone(depotId: Int, fileName: String, fileHashHex: String) {
            synchronized(lock) {
                val inst = instance ?: return
                val set = inst.completed.getOrPut(depotId) { mutableSetOf() }
                if (set.add(key(fileName, fileHashHex))) {
                    dirtySinceSave++
                    if (dirtySinceSave >= SAVE_EVERY) {
                        saveLocked()
                    }
                }
            }
        }

        /** Часть игры скачана целиком — её список готовых файлов больше не нужен. */
        fun clearDepot(depotId: Int) {
            synchronized(lock) {
                val inst = instance ?: return
                if (inst.completed.remove(depotId) != null) {
                    saveLocked()
                }
            }
        }

        fun flush() {
            synchronized(lock) { saveLocked() }
        }

        private fun saveLocked() {
            val inst = instance ?: return
            val path = filePath ?: return
            try {
                path.parent?.let { FileSystem.SYSTEM.createDirectories(it) }
                FileSystem.SYSTEM.write(path) {
                    writeUtf8(json.encodeToString(inst))
                }
                dirtySinceSave = 0
            } catch (e: Exception) {
                // прогресс не критичен — не роняем загрузку из-за сбоя записи
            }
        }
    }
}
