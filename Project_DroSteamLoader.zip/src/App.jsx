import React, { useEffect, useMemo, useRef, useState } from 'react'
import { registerPlugin } from '@capacitor/core'

const Steam = registerPlugin('Steam')

const OS_TITLE = { windows: 'Windows', linux: 'Linux', macos: 'macOS' }
const LANGS = ['english', 'russian', 'german', 'french', 'spanish', 'schinese', 'japanese']
const CDN = 'https://shared.cloudflare.steamstatic.com/store_item_assets/steam/apps/'
const PAGE = 60

const STATE_TEXT = {
  offline: 'не подключено',
  connecting: 'подключаюсь…',
  reconnecting: 'восстанавливаю связь…',
  loggingOn: 'вхожу…',
  guard: 'Steam Guard',
  qr: 'QR-код',
  error: 'ошибка'
}

function stateText (s) {
  if (s.state === 'loggedOn') return s.account
  return STATE_TEXT[s.state] || s.state
}

function fmtBytes (n) {
  if (!n) return '0 Б'
  const u = ['Б', 'КБ', 'МБ', 'ГБ', 'ТБ']
  let i = 0
  let v = Number(n)
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++ }
  return v.toFixed(v >= 10 || i === 0 ? 0 : 1) + ' ' + u[i]
}

function fmtDate (sec) {
  if (!sec) return ''
  try { return new Date(Number(sec) * 1000).toLocaleDateString('ru-RU') } catch { return '' }
}

function fmtTime (sec) {
  if (!sec || !isFinite(sec) || sec <= 0) return '—'
  const s = Math.round(sec)
  const h = Math.floor(s / 3600)
  const m = Math.floor((s % 3600) / 60)
  const r = s % 60
  if (h) return h + ' ч ' + m + ' мин'
  if (m) return m + ' мин ' + r + ' с'
  return r + ' с'
}

/** Обложка: сначала пробуем вертикальную, потом широкую, удачный адрес запоминаем. */
function Cover ({ app }) {
  const key = 'cover:' + app.appId
  const variants = [
    CDN + app.appId + '/library_600x900.jpg',
    CDN + app.appId + '/header.jpg'
  ]
  const saved = (() => { try { return localStorage.getItem(key) } catch { return null } })()
  const [idx, setIdx] = useState(() => {
    if (saved === 'none') return variants.length
    if (saved) {
      const i = variants.indexOf(saved)
      return i >= 0 ? i : 0
    }
    return 0
  })

  if (idx >= variants.length) {
    return <div className="cover fallback"><span>{app.name}</span></div>
  }
  return (
    <img
      className="cover"
      src={variants[idx]}
      alt=""
      loading="lazy"
      decoding="async"
      onLoad={() => { try { localStorage.setItem(key, variants[idx]) } catch {} }}
      onError={() => {
        const next = idx + 1
        setIdx(next)
        try { localStorage.setItem(key, next >= variants.length ? 'none' : variants[next]) } catch {}
      }}
    />
  )
}

/** Простой выбор папки по дереву телефона. */
function FolderPicker ({ start, onPick, onClose }) {
  const [data, setData] = useState(null)
  useEffect(() => { load(start || '/storage/emulated/0') }, [])
  async function load (path) {
    try {
      const r = await Steam.listFolders({ path })
      setData(r)
    } catch {
      setData({ path, parent: '', items: [] })
    }
  }
  return (
    <div className="sheetbg" onClick={onClose}>
      <div className="sheet" onClick={e => e.stopPropagation()}>
        <h2>Куда сохранять</h2>
        <p className="muted">{data ? data.path : 'читаю…'}</p>
        {data?.parent ? (
          <div className="item" onClick={() => load(data.parent)}><div className="name">⬅ наверх</div></div>
        ) : null}
        {(data?.items || []).map(f => (
          <div className="item" key={f.path} onClick={() => load(f.path)}>
            <div className="name">📁 {f.name}</div>
          </div>
        ))}
        <button className="primary" onClick={() => { onPick(data.path); onClose() }}>Выбрать эту папку</button>
        <button className="ghost" onClick={onClose}>Отмена</button>
      </div>
    </div>
  )
}

export default function App () {
  const [tab, setTab] = useState('library')
  const [status, setStatus] = useState({ state: 'offline', account: '', hasSaved: false, savedAccount: '' })
  const [menuOpen, setMenuOpen] = useState(false)
  const [logLines, setLogLines] = useState([])
  const [guard, setGuard] = useState(null)
  const [guardCode, setGuardCode] = useState('')
  const [qrUrl, setQrUrl] = useState('')
  const [error, setError] = useState('')

  const [user, setUser] = useState('')
  const [pass, setPass] = useState('')

  const [apps, setApps] = useState([])
  const [installed, setInstalled] = useState({})
  const [updates, setUpdates] = useState([])
  const [refreshing, setRefreshing] = useState(false)
  const [search, setSearch] = useState('')
  const [shown, setShown] = useState(PAGE)

  const [dialog, setDialog] = useState(null)
  const [os, setOs] = useState('windows')
  const [arch, setArch] = useState('64')
  const [branch, setBranch] = useState('public')
  const [branchPassword, setBranchPassword] = useState('')
  const [language, setLanguage] = useState('russian')
  const [dlcMode, setDlcMode] = useState('all')      // all | none | pick
  const [pickedDlc, setPickedDlc] = useState([])
  const [oldVersion, setOldVersion] = useState(false)
  const [oldDepot, setOldDepot] = useState('')
  const [oldManifest, setOldManifest] = useState('')

  const [dir, setDir] = useState('')
  const [free, setFree] = useState(0)
  const [threads, setThreads] = useState(8)
  const [picker, setPicker] = useState(null)         // 'dialog' | 'settings'

  const [dl, setDl] = useState(null)
  const [dlTotal, setDlTotal] = useState(0)
  const [dlStart, setDlStart] = useState(0)
  const logRef = useRef(null)
  const startedRef = useRef(false)
  const bodyRef = useRef(null)

  useEffect(() => {
    const subs = []
    Steam.addListener('state', s => {
      setStatus(v => ({ ...v, state: s.state, account: s.account }))
      if (s.state === 'error') setError(s.error || 'Ошибка')
      if (['loggedOn', 'connecting', 'reconnecting'].includes(s.state)) setError('')
      if (s.state === 'loggedOn') {
        setGuard(null)
        setQrUrl('')
        refreshInBackground()
      }
    }).then(h => subs.push(h))
    Steam.addListener('log', s => setLogLines(l => [...l.slice(-300), s.message])).then(h => subs.push(h))
    Steam.addListener('guard', s => { setGuard(s); setTab('login') }).then(h => subs.push(h))
    Steam.addListener('qr', s => setQrUrl(s.url)).then(h => subs.push(h))
    Steam.addListener('download', s => {
      setDl(s)
      if (['completed', 'failed', 'cancelled'].includes(s.kind)) Steam.downloadFinished()
    }).then(h => subs.push(h))

    Steam.cachedLibrary().then(r => {
      setApps(r.apps || [])
      setInstalled(r.installed || {})
    })

    Steam.status().then(s => {
      setStatus(s)
      if (s.state !== 'loggedOn' && s.hasSaved) Steam.loginSaved().catch(() => {})
      if (s.state !== 'loggedOn' && !s.hasSaved) setTab('login')
      if (s.state === 'loggedOn') refreshInBackground()
    })

    Steam.storageInfo({}).then(s => { setDir(s.dir); setFree(s.free) })

    return () => { subs.forEach(h => h && h.remove && h.remove()) }
  }, [])

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight
  }, [logLines])

  async function refreshInBackground () {
    if (startedRef.current) return
    startedRef.current = true
    setRefreshing(true)
    try {
      const r = await Steam.library({ onlyGames: true })
      const list = (r.apps || []).sort((a, b) => a.name.localeCompare(b.name))
      if (list.length) setApps(list)
    } catch (e) {
      setLogLines(l => [...l, 'Список игр: ' + String(e.message || e)])
    }
    setRefreshing(false)
    try {
      const u = await Steam.checkUpdates()
      setUpdates(u.updates || [])
    } catch { /* не критично */ }
    try {
      const c = await Steam.cachedLibrary()
      setInstalled(c.installed || {})
    } catch { /* пусто */ }
  }

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    return q ? apps.filter(a => a.name.toLowerCase().includes(q) || String(a.appId) === q) : apps
  }, [apps, search])

  useEffect(() => { setShown(PAGE) }, [search])

  function onScroll (e) {
    const el = e.currentTarget
    if (el.scrollTop + el.clientHeight > el.scrollHeight - 400) {
      setShown(v => (v < filtered.length ? v + PAGE : v))
    }
  }

  const updateFor = id => updates.find(u => u.appId === id)

  async function doLogin () {
    setError('')
    try { await Steam.login({ username: user, password: pass }) } catch (e) { setError(String(e.message || e)) }
  }
  async function doLoginQr () {
    setError('')
    try { await Steam.loginQr() } catch (e) { setError(String(e.message || e)) }
  }
  async function sendGuard () {
    await Steam.submitGuard({ code: guardCode.trim() })
    setGuardCode('')
    setGuard(null)
  }
  async function doLogout () {
    setMenuOpen(false)
    await Steam.logout()
    startedRef.current = false
    setTab('login')
  }

  // ——— окно скачивания ———

  async function openDialog (a) {
    setDialog({ app: a, info: null, loading: true })
    setBranchPassword('')
    setDlcMode('all')
    setPickedDlc([])
    setOldVersion(false)
    setOldManifest('')
    setOldDepot('')
    try {
      const info = await Steam.appInfo({ appId: a.appId })
      const platforms = availablePlatforms(info)
      setOs(platforms[0] || 'windows')
      const names = (info.branches || []).map(b => b.name)
      setBranch(names.includes('public') ? 'public' : (names[0] || 'public'))
      setDialog({ app: a, info, loading: false })
    } catch (e) {
      setDialog(null)
      setError(String(e.message || e))
    }
  }

  function availablePlatforms (info) {
    const set = new Set()
    for (const d of info.depots || []) {
      if (!d.os) continue
      for (const p of d.os.split(',')) {
        const v = p.trim().toLowerCase()
        if (OS_TITLE[v]) set.add(v)
      }
    }
    if (!set.size) {
      for (const p of (info.platforms || '').split(',')) {
        const v = p.trim().toLowerCase()
        if (OS_TITLE[v]) set.add(v)
      }
    }
    if (!set.size) set.add('windows')
    return ['windows', 'linux', 'macos'].filter(p => set.has(p))
  }

  const platformDepots = useMemo(() => {
    if (!dialog?.info) return []
    return (dialog.info.depots || []).filter(d => {
      if (!d.os) return true
      return d.os.split(',').map(s => s.trim()).includes(os)
    })
  }, [dialog, os])

  const baseDepots = useMemo(() => platformDepots.filter(d => !Number(d.dlcAppId)), [platformDepots])
  const dlcDepots = useMemo(() => platformDepots.filter(d => Number(d.dlcAppId) > 0), [platformDepots])

  const chosenDepots = useMemo(() => {
    if (dlcMode === 'all' && !oldVersion) return []            // пусть Steam сам решает
    let list = baseDepots.map(d => d.depotId)
    if (dlcMode === 'all') list = list.concat(dlcDepots.map(d => d.depotId))
    if (dlcMode === 'pick') list = list.concat(pickedDlc)
    return list
  }, [dlcMode, pickedDlc, baseDepots, dlcDepots, oldVersion])

  const sizeEstimate = useMemo(() => {
    let total = 0
    const wanted = dlcMode === 'all'
      ? platformDepots
      : platformDepots.filter(d => !Number(d.dlcAppId) || pickedDlc.includes(d.depotId))
    for (const d of wanted) {
      const m = d.manifests?.[branch] || d.manifests?.public
      if (m) total += Number(m.size || 0)
    }
    return total
  }, [platformDepots, branch, dlcMode, pickedDlc])

  const branchObj = useMemo(
    () => (dialog?.info?.branches || []).find(b => b.name === branch) || null,
    [dialog, branch]
  )

  const archOptions = useMemo(() => {
    const set = new Set()
    for (const d of platformDepots) if (d.arch) set.add(d.arch.trim())
    return Array.from(set)
  }, [platformDepots])

  async function startDownload () {
    if (!dialog?.app) return
    setError('')
    let depots = chosenDepots
    let manifests = []
    if (oldVersion && oldDepot && oldManifest.trim()) {
      depots = [Number(oldDepot)]
      manifests = [oldManifest.trim()]
    }
    try {
      await Steam.startDownload({
        appId: dialog.app.appId,
        appName: dialog.app.name,
        branch,
        branchPassword,
        os,
        arch: archOptions.length ? arch : '64',
        language,
        allLanguages: false,
        allPlatforms: false,
        allArchs: archOptions.length === 0,
        lowViolence: false,
        manifestOnly: false,
        nameFolder: true,
        dir,
        maxDownloads: Number(threads) || 8,
        depots,
        manifests
      })
      setDlTotal(sizeEstimate)
      setDlStart(Date.now())
      setDl({ kind: 'started', appName: dialog.app.name, percent: 0 })
      setDialog(null)
      setTab('downloads')
    } catch (e) {
      setError(String(e.message || e))
    }
  }

  const eta = useMemo(() => {
    if (!dl || !dlStart) return null
    const p = Number(dl.percent || 0)
    if (p <= 0.01) return null
    const elapsed = (Date.now() - dlStart) / 1000
    return elapsed / p - elapsed
  }, [dl, dlStart])

  return (
    <div className="app">
      <div className="head">
        <h1>DroSteamLoader</h1>
        <span className="acc" onClick={() => setMenuOpen(v => !v)}>{stateText(status)} ▾</span>
        {menuOpen && (
          <div className="menu">
            <button onClick={() => { setMenuOpen(false); setTab('login') }}>Сменить аккаунт</button>
            <button onClick={doLogout}>Выход</button>
          </div>
        )}
      </div>

      <div className="body" ref={bodyRef} onScroll={onScroll} onClick={() => menuOpen && setMenuOpen(false)}>
        {error ? <div className="card"><span className="err">{error}</span></div> : null}

        {tab === 'library' && (
          <>
            <div className="searchbar">
              <input placeholder="Поиск по названию или ID" value={search} onChange={e => setSearch(e.target.value)} />
              <span className="muted">{refreshing ? 'обновляю…' : apps.length + ' игр'}</span>
            </div>

            {apps.length === 0 && (
              <div className="card">
                <h2>Библиотека пуста</h2>
                <p className="muted">Список подтянется сам после входа. Если пусто — загляни в «Загрузки» → «Журнал».</p>
                <button className="ghost" onClick={() => { startedRef.current = false; refreshInBackground() }}>
                  Обновить сейчас
                </button>
              </div>
            )}

            <div className="grid">
              {filtered.slice(0, shown).map(a => {
                const up = updateFor(a.appId)
                const inst = installed[String(a.appId)]
                return (
                  <div className="tile" key={a.appId} onClick={() => openDialog(a)}>
                    <div className="shot"><Cover app={a} /></div>
                    {up && <span className="badge upd">обновление</span>}
                    {!up && inst && <span className="badge inst">скачано</span>}
                    <div className="tname">{a.name}</div>
                  </div>
                )
              })}
            </div>

            {shown < filtered.length && (
              <button className="ghost" onClick={() => setShown(v => v + PAGE)}>
                Показать ещё ({filtered.length - shown})
              </button>
            )}
          </>
        )}

        {tab === 'downloads' && (
          <>
            <div className="card">
              <h2>{dl?.appName || 'Загрузок нет'}</h2>
              {dl && (
                <>
                  <div className="bar"><div style={{ width: (100 * (dl.percent || 0)) + '%' }} /></div>
                  <div className="muted">
                    {(100 * (dl.percent || 0)).toFixed(1)}% · {fmtBytes(dl.compressed)}
                    {dlTotal ? ' из ~' + fmtBytes(dlTotal) : ''} · {fmtBytes(dl.speed)}/с
                  </div>
                  <div className="muted">
                    Осталось примерно: {['completed', 'failed', 'cancelled'].includes(dl.kind) ? '—' : fmtTime(eta)}
                  </div>
                  <div className="muted">
                    {dl.kind === 'completed' ? 'Готово'
                      : dl.kind === 'failed' ? ('Ошибка: ' + dl.extra)
                        : dl.kind === 'cancelled' ? 'Отменено' : (dl.extra || '')}
                  </div>
                  {!['completed', 'failed', 'cancelled'].includes(dl.kind) && (
                    <button className="ghost" onClick={() => Steam.cancelDownload()}>Отменить</button>
                  )}
                </>
              )}
            </div>

            {updates.length > 0 && (
              <div className="card">
                <h2>Вышли обновления</h2>
                {updates.map(u => (
                  <div className="item" key={u.appId}>
                    <div className="name">
                      {u.name}
                      <div className="sub">ветка {u.branch} · сборка {u.oldBuildId} → {u.newBuildId}</div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            <div className="card">
              <h2>Журнал</h2>
              <div className="log" ref={logRef}>{logLines.join('\n')}</div>
            </div>
          </>
        )}

        {tab === 'login' && (
          <>
            <div className="card">
              <h2>Вход в Steam</h2>
              {status.hasSaved && (
                <button className="ghost" onClick={() => Steam.loginSaved()}>
                  Войти как {status.savedAccount}
                </button>
              )}
              <label>Логин</label>
              <input value={user} onChange={e => setUser(e.target.value)} autoCapitalize="none" autoCorrect="off" />
              <label>Пароль</label>
              <input type="password" value={pass} onChange={e => setPass(e.target.value)} />
              <button className="primary" onClick={doLogin}>Войти</button>
              <button className="ghost" onClick={doLoginQr}>Вход по QR-коду</button>
            </div>

            {guard && (
              <div className="card">
                <h2>Steam Guard</h2>
                <p className="muted">
                  {guard.kind === 'email'
                    ? 'Код отправлен на почту ' + (guard.email || '')
                    : guard.kind === 'confirm'
                      ? 'Подтвердите вход в приложении Steam. Если не приходит — введите код ниже.'
                      : 'Введите код из приложения Steam Guard'}
                  {guard.wrong ? ' (прошлый код не подошёл)' : ''}
                </p>
                <input value={guardCode} onChange={e => setGuardCode(e.target.value)} autoCapitalize="characters" />
                <button className="primary" onClick={sendGuard}>Отправить код</button>
              </div>
            )}

            {qrUrl && (
              <div className="card center">
                <h2>QR для входа</h2>
                <img
                  alt="QR"
                  style={{ width: '70%', maxWidth: 260 }}
                  src={'https://api.qrserver.com/v1/create-qr-code/?size=400x400&data=' + encodeURIComponent(qrUrl)}
                />
                <p className="muted">Отсканируйте в приложении Steam</p>
              </div>
            )}
          </>
        )}

        {tab === 'settings' && (
          <div className="card">
            <h2>Настройки</h2>
            <label>Папка загрузок</label>
            <input value={dir} onChange={e => setDir(e.target.value)} />
            <button className="ghost" onClick={() => setPicker('settings')}>Выбрать папку</button>
            <p className="muted">Свободно: {fmtBytes(free)}</p>
            <label>Потоков загрузки</label>
            <select value={threads} onChange={e => setThreads(e.target.value)}>
              {[4, 8, 12, 16, 24].map(n => <option key={n} value={n}>{n}</option>)}
            </select>
            <label>Язык игр по умолчанию</label>
            <select value={language} onChange={e => setLanguage(e.target.value)}>
              {LANGS.map(l => <option key={l} value={l}>{l}</option>)}
            </select>
            <button className="ghost" onClick={() => Steam.requestStorageAccess()}>Доступ ко всем файлам</button>
            <button className="ghost" onClick={doLogout}>Выйти из аккаунта</button>
          </div>
        )}
      </div>

      {dialog && (
        <div className="sheetbg" onClick={() => setDialog(null)}>
          <div className="sheet" onClick={e => e.stopPropagation()}>
            <h2>{dialog.app.name}</h2>
            {dialog.loading && <p className="muted">Спрашиваю Steam о версиях…</p>}

            {dialog.info && (
              <>
                <label>Платформа</label>
                <div>
                  {availablePlatforms(dialog.info).map(p => (
                    <span key={p} className={'chip ' + (os === p ? 'on' : '')} onClick={() => setOs(p)}>
                      {OS_TITLE[p]}
                    </span>
                  ))}
                </div>

                <label>Версия</label>
                <select value={branch} onChange={e => setBranch(e.target.value)}>
                  {(dialog.info.branches || []).map(b => (
                    <option key={b.name} value={b.name}>
                      {b.name === 'public' ? 'обычная (public)' : b.name}
                      {b.passwordRequired ? ' 🔒' : ''} · сборка {b.buildId}
                      {b.timeUpdated ? ' · ' + fmtDate(b.timeUpdated) : ''}
                    </option>
                  ))}
                </select>
                {branchObj?.description ? <p className="muted">{branchObj.description}</p> : null}
                {branchObj?.passwordRequired && (
                  <>
                    <label>Пароль ветки</label>
                    <input value={branchPassword} onChange={e => setBranchPassword(e.target.value)} />
                  </>
                )}

                {dlcDepots.length > 0 && (
                  <>
                    <label>Дополнения (DLC)</label>
                    <div>
                      <span className={'chip ' + (dlcMode === 'all' ? 'on' : '')} onClick={() => setDlcMode('all')}>все</span>
                      <span className={'chip ' + (dlcMode === 'none' ? 'on' : '')} onClick={() => setDlcMode('none')}>без DLC</span>
                      <span className={'chip ' + (dlcMode === 'pick' ? 'on' : '')} onClick={() => setDlcMode('pick')}>выбрать</span>
                    </div>
                    {dlcMode === 'pick' && dlcDepots.map(d => {
                      const on = pickedDlc.includes(d.depotId)
                      const m = d.manifests?.[branch] || d.manifests?.public
                      return (
                        <div
                          className={'item ' + (on ? 'sel' : '')}
                          key={d.depotId}
                          onClick={() => setPickedDlc(v => on ? v.filter(x => x !== d.depotId) : [...v, d.depotId])}
                        >
                          <div className="name">
                            {d.name}
                            <div className="sub">{d.depotId}{m ? ' · ' + fmtBytes(m.size) : ''}</div>
                          </div>
                          <span className={'chip ' + (on ? 'on' : '')}>{on ? '✓' : '+'}</span>
                        </div>
                      )
                    })}
                  </>
                )}

                {archOptions.length > 1 && (
                  <>
                    <label>Разрядность</label>
                    <select value={arch} onChange={e => setArch(e.target.value)}>
                      {archOptions.map(a => <option key={a} value={a}>{a} бит</option>)}
                    </select>
                  </>
                )}

                <label>Язык</label>
                <select value={language} onChange={e => setLanguage(e.target.value)}>
                  {LANGS.map(l => <option key={l} value={l}>{l}</option>)}
                </select>

                <label>Старая версия</label>
                <div>
                  <span className={'chip ' + (!oldVersion ? 'on' : '')} onClick={() => setOldVersion(false)}>текущая</span>
                  <span className={'chip ' + (oldVersion ? 'on' : '')} onClick={() => setOldVersion(true)}>по ID сборки</span>
                </div>
                {oldVersion && (
                  <>
                    <p className="muted">
                      Steam не выдаёт список прошлых версий — он хранит только текущие для каждой ветки.
                      ID старой сборки берётся со SteamDB и вводится вручную.
                    </p>
                    <select value={oldDepot} onChange={e => setOldDepot(e.target.value)}>
                      <option value="">— выбери файл (депот) —</option>
                      {platformDepots.map(d => (
                        <option key={d.depotId} value={d.depotId}>{d.depotId} · {d.name}</option>
                      ))}
                    </select>
                    <label>ID манифеста</label>
                    <input value={oldManifest} onChange={e => setOldManifest(e.target.value)} inputMode="numeric" />
                  </>
                )}

                <label>Куда сохранить</label>
                <input value={dir} onChange={e => setDir(e.target.value)} />
                <button className="ghost" onClick={() => setPicker('dialog')}>Выбрать папку</button>

                <p className="muted">
                  Примерный размер: {fmtBytes(sizeEstimate)} · свободно {fmtBytes(free)}
                </p>

                <button className="primary" onClick={startDownload}>Скачать</button>
                <button className="ghost" onClick={() => setDialog(null)}>Отмена</button>
              </>
            )}
          </div>
        </div>
      )}

      {picker && (
        <FolderPicker
          start={dir}
          onClose={() => setPicker(null)}
          onPick={p => {
            setDir(p)
            Steam.storageInfo({ dir: p }).then(s => setFree(s.free)).catch(() => {})
          }}
        />
      )}

      <div className="tabs">
        <button className={tab === 'library' ? 'on' : ''} onClick={() => setTab('library')}>Библиотека</button>
        <button className={tab === 'downloads' ? 'on' : ''} onClick={() => setTab('downloads')}>Загрузки</button>
        <button className={tab === 'settings' ? 'on' : ''} onClick={() => setTab('settings')}>⚙ Настройки</button>
      </div>
    </div>
  )
}
