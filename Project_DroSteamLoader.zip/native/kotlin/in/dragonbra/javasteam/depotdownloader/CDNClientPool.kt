package `in`.dragonbra.javasteam.depotdownloader

import `in`.dragonbra.javasteam.steam.cdn.Client
import `in`.dragonbra.javasteam.steam.cdn.Server
import `in`.dragonbra.javasteam.util.log.LogManager
import `in`.dragonbra.javasteam.util.log.Logger
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicReference

/**
 * Manages a pool of CDN server connections for efficient content downloading.
 * This class maintains a list of available CDN servers, automatically selects appropriate
 * servers based on load and app compatibility, and handles connection rotation when
 * servers fail or become unavailable.
 *
 * @param steamSession The Steam3 session for server communication
 * @param appId The application ID to download - used to filter compatible CDN servers
 * @param scope The coroutine scope for async operations
 * @param debug If true, enables debug logging
 *
 * @author Oxters
 * @author Lossy
 * @since Nov 7, 2024
 */
class CDNClientPool(
    private val steamSession: Steam3Session,
    private val appId: Int,
    private val scope: CoroutineScope,
    debug: Boolean = false,
) : AutoCloseable {

    companion object {
        /** Сколько сбоев подряд терпим, прежде чем перестать предлагать сервер. */
        private const val FAIL_LIMIT = 5

        /** Сервер, выбранный пользователем в настройках. Пусто — берём ближайший по нагрузке. */
        @JvmStatic
        var preferredHost: String? = null
    }

    private var logger: Logger? = null

    private val servers = AtomicReference<List<Server>>(emptyList())

    private var nextServer: AtomicInteger = AtomicInteger(0)

    private val mutex: Mutex = Mutex()

    /** Серверы, отказавшие по конкретной части игры: номер депота → адреса серверов. */
    private val blacklist =
        java.util.concurrent.ConcurrentHashMap<Int, java.util.concurrent.ConcurrentHashMap.KeySetView<String, Boolean>>()

    /** Сколько раз подряд сервер сбоил по сети. */
    private val failures = java.util.concurrent.ConcurrentHashMap<String, AtomicInteger>()

    var cdnClient: Client? = null
        private set

    var proxyServer: Server? = null
        private set

    init {
        cdnClient = Client(steamSession.steamClient)

        if (debug) {
            logger = LogManager.getLogger(CDNClientPool::class.java)
        }
    }

    override fun close() {
        logger?.debug("Closing...")

        servers.set(emptyList())
        blacklist.clear()
        failures.clear()

        cdnClient = null
        proxyServer = null

        logger = null
    }

    @Throws(Exception::class)
    suspend fun updateServerList(maxNumServers: Int? = null) = mutex.withLock {
        val serversForSteamPipe = steamSession.steamContent!!.getServersForSteamPipe(
            cellId = steamSession.steamClient.cellID ?: 0,
            maxNumServers = maxNumServers,
            parentScope = scope
        ).await()

        proxyServer = serversForSteamPipe.firstOrNull { it.useAsProxy }

        val weightedCdnServers = serversForSteamPipe
            .filter { server ->
                val isEligibleForApp = server.allowedAppIds.isEmpty() || server.allowedAppIds.contains(appId)
                isEligibleForApp && (server.type == "SteamCache" || server.type == "CDN")
            }
            .sortedWith(
                // сначала обычные CDN (они раздают что угодно), потом кэш-серверы;
                // внутри группы — по загруженности
                compareBy<Server> { if (it.allowedAppIds.isEmpty()) 0 else 1 }
                    .thenBy { it.weightedLoad }
            )
            // один и тот же адрес в списке может встречаться несколько раз
            .distinctBy { it.host }
            .let { list ->
                val wanted = preferredHost
                if (wanted.isNullOrBlank()) {
                    list
                } else {
                    // выбранный сервер вперёд, остальные оставляем как запас
                    val picked = list.filter { it.host == wanted }
                    if (picked.isEmpty()) list else picked + list.filter { it.host != wanted }
                }
            }

        // ContentServerPenalty removed for now.

        servers.set(weightedCdnServers)

        nextServer.set(0)

        // servers.joinToString(separator = "\n", prefix = "Servers:\n") { "- $it" }
        logger?.debug("Found ${weightedCdnServers.size} Servers")

        if (weightedCdnServers.isEmpty()) {
            throw Exception("Failed to retrieve any download servers.")
        }
    }

    fun getConnection(): Server = getConnection(0)

    /**
     * Даёт сервер для скачивания. Пропускаются те, что уже отказали по этой части игры
     * (ответ 403 — «не раздаю этот депот») и те, что подряд сбоят по сети.
     */
    fun getConnection(depotId: Int): Server {
        val all = servers.get()

        if (all.isEmpty()) {
            throw IllegalStateException("Нет доступных серверов загрузки")
        }

        val banned = blacklist[depotId]

        val healthy = all.filter { s ->
            banned?.contains(s.host) != true && (failures[s.host]?.get() ?: 0) < FAIL_LIMIT
        }

        // если здоровых не осталось — берём хотя бы не забаненные, иначе вообще любые
        val pool = if (healthy.isNotEmpty()) {
            healthy
        } else {
            val notBanned = all.filter { banned?.contains(it.host) != true }
            if (notBanned.isNotEmpty()) notBanned else all
        }

        // раскидываем куски по всем серверам сразу; соединение к каждому серверу
        // остаётся в пуле, так что повторного рукопожатия почти нет
        val server = pool[Math.floorMod(nextServer.getAndIncrement(), pool.size)]

        logger?.debug("Getting connection $server")

        return server
    }

    /** Есть ли ещё откуда качать. */
    fun hasServers(): Boolean = servers.get().isNotEmpty()

    /** Сервер отказался раздавать эту часть игры — больше его для неё не берём. */
    fun blacklistForDepot(depotId: Int, server: Server?) {
        if (server == null) return

        val set = blacklist.getOrPut(depotId) { java.util.concurrent.ConcurrentHashMap.newKeySet() }
        val servers = servers.get()

        // не даём забанить вообще все серверы — иначе качать будет неоткуда
        if (set.size >= servers.size - 1) return

        if (set.add(server.host)) {
            logger?.debug("Server ${server.host} blacklisted for depot $depotId")
        }
    }

    fun returnConnection(server: Server?) {
        if (server == null) {
            logger?.error("null server returned to cdn pool.")
            return
        }

        // успех — прошлые сбои этого сервера больше не в счёт
        failures[server.host]?.set(0)

        logger?.debug("Returning connection: $server")

        // (SK) nothing to do, maybe remove from ContentServerPenalty?
    }

    fun returnBrokenConnection(server: Server?) {
        if (server == null) {
            logger?.error("null broken server returned to pool")
            return
        }

        logger?.debug("Returning broken connection: $server")

        // считаем сбои: сервер, который сбоит подряд, временно перестаём предлагать
        failures.getOrPut(server.host) { AtomicInteger(0) }.incrementAndGet()
    }
}
