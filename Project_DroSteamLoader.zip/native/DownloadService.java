package leshugan.DSL;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * Держит процесс живым, пока идёт скачивание, и показывает уведомление с прогрессом.
 */
public class DownloadService extends Service {

    private static final String CHANNEL = "dsl_downloads";
    private static final int NOTIF_ID = 4201;

    private PowerManager.WakeLock wakeLock;

    public static final String ACTION_PAUSE = "leshugan.DSL.PAUSE";
    public static final String ACTION_CANCEL = "leshugan.DSL.CANCEL";
    public static final String ACTION_RESUME = "leshugan.DSL.RESUME";
    public static final String ACTION_CLOSE = "leshugan.DSL.CLOSE";

    private static volatile int currentAppId;
    private static volatile String currentTitle = "DroSteamLoader";
    private static volatile String currentText = "";
    private static volatile int currentPercent;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel(this);
        startInForeground(build(this, "DroSteamLoader", 0, "waiting"));
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dsl:download");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(6L * 60L * 60L * 1000L); // не даём телефону усыпить закачку
            }
        } catch (Throwable ignored) {
        }

    }

    @Override
    public void onDestroy() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Throwable ignored) {
        }
        wakeLock = null;
        super.onDestroy();
    }

    /** На Android 10+ службе нужно явно сказать её тип, иначе система её прибивает. */
    private void startInForeground(Notification n) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Throwable t) {
            try {
                startForeground(NOTIF_ID, n);
            } catch (Throwable ignored) {
            }
        }
    }

    /**
     * Пользователь убрал приложение из недавних — скачивание продолжаем.
     * Служба остаётся в переднем плане, поэтому система процесс не выгружает.
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        try {
            startInForeground(build(this, currentTitle, currentPercent, "running"));
        } catch (Throwable ignored) {
        }
        // намеренно не вызываем super и не останавливаемся
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && "detach".equals(intent.getAction())) {
            // уходим с переднего плана, но уведомление оставляем на экране
            try {
                if (Build.VERSION.SDK_INT >= 24) {
                    stopForeground(Service.STOP_FOREGROUND_DETACH);
                } else {
                    stopForeground(false);
                }
            } catch (Throwable ignored) {
            }
            stopSelf();
            return START_NOT_STICKY;
        }
        startInForeground(build(this, currentTitle, currentPercent, currentPercent > 0 ? "running" : "waiting"));
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static void start(Context ctx) {
        Intent i = new Intent(ctx, DownloadService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(i);
        } else {
            ctx.startService(i);
        }
    }

    public static void stop(Context ctx) {
        ctx.stopService(new Intent(ctx, DownloadService.class));
    }

    /** Совсем убрать уведомление (кнопки «Закрыть» и «Отмена»). */
    public static void dismiss(Context ctx) {
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.cancel(NOTIF_ID);
        } catch (Throwable ignored) {
        }
        stop(ctx);
    }

    /**
     * Пауза: служба больше не нужна, но уведомление должно остаться —
     * отцепляем его от службы, иначе система уберёт его вместе с ней.
     */
    public static void detachAndKeep(Context ctx, String title, int percent) {
        currentTitle = title;
        currentPercent = percent;
        try {
            NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null) nm.notify(NOTIF_ID, build(ctx, title, percent, "paused"));
        } catch (Throwable ignored) {
        }
        Intent i = new Intent(ctx, DownloadService.class).setAction("detach");
        try {
            ctx.startService(i);
        } catch (Throwable ignored) {
        }
    }

    public static void update(Context ctx, String title, int percent, String kind) {
        update(ctx, title, percent, kind, 0, "");
    }

    public static void update(Context ctx, String title, int percent, String kind, int appId, String details) {
        currentAppId = appId;
        currentTitle = title;
        currentPercent = percent;
        currentText = details == null ? "" : details;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.notify(NOTIF_ID, build(ctx, title, percent, kind));
    }

    /** Намерение для кнопки уведомления: явное, с номером игры внутри. */
    private static Intent actionIntent(Context ctx, String action) {
        Intent i = new Intent(ctx, NotifActions.class);
        i.setAction(action);
        i.putExtra("appId", currentAppId);
        return i;
    }

    private static void createChannel(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Загрузки", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
    }

    private static Notification build(Context ctx, String title, int percent, String kind) {
        createChannel(ctx);

        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        open.putExtra("openTab", "downloads");
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open, flags);

        String text;
        boolean done = false;
        if ("completed".equals(kind)) {
            text = "Готово";
            done = true;
        } else if ("failed".equals(kind)) {
            text = "Ошибка";
            done = true;
        } else if ("cancelled".equals(kind)) {
            text = "Отменено";
            done = true;
        } else if ("paused".equals(kind)) {
            text = "На паузе · " + percent + "%";
        } else {
            text = percent + "%" + (currentText.isEmpty() ? "" : " · " + currentText);
        }

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            b = new Notification.Builder(ctx, CHANNEL);
        } else {
            b = new Notification.Builder(ctx);
        }
        b.setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(ctx.getApplicationInfo().icon)
                .setOngoing(!done)
                .setOnlyAlertOnce(true)
                .setContentIntent(pi);
        boolean paused = "paused".equals(kind);
        if (!done) {
            b.setProgress(100, Math.max(0, Math.min(100, percent)), percent <= 0 && !paused);
            b.setOngoing(!paused); // на паузе уведомление можно смахнуть

            int aFlags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) aFlags |= PendingIntent.FLAG_IMMUTABLE;

            PendingIntent pausePi = PendingIntent.getBroadcast(ctx, 1, actionIntent(ctx, ACTION_PAUSE), aFlags);
            PendingIntent cancelPi = PendingIntent.getBroadcast(ctx, 2, actionIntent(ctx, ACTION_CANCEL), aFlags);
            PendingIntent resumePi = PendingIntent.getBroadcast(ctx, 3, actionIntent(ctx, ACTION_RESUME), aFlags);
            PendingIntent closePi = PendingIntent.getBroadcast(ctx, 4, actionIntent(ctx, ACTION_CLOSE), aFlags);

            // Своя разметка нужна только ради кнопок справа: в обычном уведомлении
            // Android всегда ставит их слева. Если разметки нет — работаем как раньше.
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N
                    && applyRightSideButtons(ctx, b, title, text, percent, paused,
                    pausePi, cancelPi, resumePi, closePi)) {
                return b.build();
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (paused) {
                    b.addAction(new Notification.Action.Builder((android.graphics.drawable.Icon) null, "Закрыть", closePi).build());
                    b.addAction(new Notification.Action.Builder((android.graphics.drawable.Icon) null, "Возобновить", resumePi).build());
                } else {
                    b.addAction(new Notification.Action.Builder((android.graphics.drawable.Icon) null, "Пауза", pausePi).build());
                }
                b.addAction(new Notification.Action.Builder((android.graphics.drawable.Icon) null, "Отмена", cancelPi).build());
            }
        }
        return b.build();
    }

    /**
     * Ставит свою разметку с кнопками справа. Возвращает false, если разметки
     * в сборке нет — тогда вызывающий делает обычное уведомление.
     */
    private static boolean applyRightSideButtons(Context ctx, Notification.Builder b, String title,
                                                 String text, int percent, boolean paused,
                                                 PendingIntent pausePi, PendingIntent cancelPi,
                                                 PendingIntent resumePi, PendingIntent closePi) {
        try {
            String pkg = ctx.getPackageName();
            android.content.res.Resources res = ctx.getResources();

            int small = res.getIdentifier("dsl_notif", "layout", pkg);
            int big = res.getIdentifier("dsl_notif_big", "layout", pkg);
            int idTitle = res.getIdentifier("dsl_title", "id", pkg);
            int idText = res.getIdentifier("dsl_text", "id", pkg);
            int idProgress = res.getIdentifier("dsl_progress", "id", pkg);
            int idPause = res.getIdentifier("dsl_pause", "id", pkg);
            int idCancel = res.getIdentifier("dsl_cancel", "id", pkg);
            int idClose = res.getIdentifier("dsl_close", "id", pkg);

            if (small == 0 || big == 0 || idTitle == 0 || idText == 0
                    || idProgress == 0 || idPause == 0 || idCancel == 0 || idClose == 0) {
                return false;
            }

            int p = Math.max(0, Math.min(100, percent));

            android.widget.RemoteViews vSmall = new android.widget.RemoteViews(pkg, small);
            vSmall.setTextViewText(idTitle, title);
            vSmall.setTextViewText(idText, text);
            vSmall.setProgressBar(idProgress, 100, p, percent <= 0);

            android.widget.RemoteViews vBig = new android.widget.RemoteViews(pkg, big);
            vBig.setTextViewText(idTitle, title);
            vBig.setTextViewText(idText, text);
            vBig.setProgressBar(idProgress, 100, p, percent <= 0);

            // На паузе средняя кнопка становится «Возобновить», слева появляется «Закрыть»
            vBig.setTextViewText(idPause, paused ? "Возобновить" : "Пауза");
            vBig.setOnClickPendingIntent(idPause, paused ? resumePi : pausePi);
            vBig.setViewVisibility(idClose, paused ? android.view.View.VISIBLE : android.view.View.GONE);
            vBig.setOnClickPendingIntent(idClose, closePi);
            vBig.setOnClickPendingIntent(idCancel, cancelPi);

            b.setStyle(new Notification.DecoratedCustomViewStyle());
            b.setCustomContentView(vSmall);
            b.setCustomBigContentView(vBig);
            // системная полоса прогресса рисуется поверх нашей — она тут лишняя
            b.setProgress(0, 0, false);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
