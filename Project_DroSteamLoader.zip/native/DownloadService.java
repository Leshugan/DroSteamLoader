package leshugan.DSL;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/**
 * Держит процесс живым, пока идёт скачивание, и показывает уведомление с прогрессом.
 */
public class DownloadService extends Service {

    private static final String CHANNEL = "dsl_downloads";
    private static final int NOTIF_ID = 4201;

    private PowerManager.WakeLock wakeLock;
    private BroadcastReceiver actions;

    public static final String ACTION_PAUSE = "leshugan.DSL.PAUSE";
    public static final String ACTION_CANCEL = "leshugan.DSL.CANCEL";

    private static volatile int currentAppId;
    private static volatile String currentTitle = "DroSteamLoader";
    private static volatile String currentText = "";
    private static volatile int currentPercent;

    @Override
    public void onCreate() {
        super.onCreate();
        createChannel(this);
        startInForeground(build(this, "DroSteamLoader", 0, "waiting"));
        try {
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "dsl:download");
                wakeLock.setReferenceCounted(false);
                wakeLock.acquire(6L * 60L * 60L * 1000L); // не даём телефону усыпить закачку
            }
        } catch (Throwable ignored) {
        }

        actions = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent == null || intent.getAction() == null) return;
                SteamCore core = SteamCore.get(context);
                if (ACTION_PAUSE.equals(intent.getAction())) core.pauseTask(currentAppId);
                if (ACTION_CANCEL.equals(intent.getAction())) core.removeTask(currentAppId, false);
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(ACTION_PAUSE);
        f.addAction(ACTION_CANCEL);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(actions, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(actions, f);
        }
    }

    @Override
    public void onDestroy() {
        try {
            if (actions != null) unregisterReceiver(actions);
        } catch (Throwable ignored) {
        }
        actions = null;
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Throwable ignored) {
        }
        wakeLock = null;
        super.onDestroy();
    }

    /** На Android 10+ службе нужно явно сказать её тип, иначе система её прибивает. */
    private void startInForeground(Notification n) {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
            } else {
                startForeground(NOTIF_ID, n);
            }
        } catch (Throwable t) {
            try {
                startForeground(NOTIF_ID, n);
            } catch (Throwable ignored) {
            }
        }
    }

    /**
     * Пользователь убрал приложение из недавних — скачивание продолжаем.
     * Служба остаётся в переднем плане, поэтому система процесс не выгружает.
     */
    @Override
    public void onTaskRemoved(Intent rootIntent) {
        try {
            startInForeground(build(this, currentTitle, currentPercent, "running"));
        } catch (Throwable ignored) {
        }
        // намеренно не вызываем super и не останавливаемся
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        startInForeground(build(this, currentTitle, currentPercent, currentPercent > 0 ? "running" : "waiting"));
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    public static void start(Context ctx) {
        Intent i = new Intent(ctx, DownloadService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            ctx.startForegroundService(i);
        } else {
            ctx.startService(i);
        }
    }

    public static void stop(Context ctx) {
        ctx.stopService(new Intent(ctx, DownloadService.class));
    }

    public static void update(Context ctx, String title, int percent, String kind) {
        update(ctx, title, percent, kind, 0, "");
    }

    public static void update(Context ctx, String title, int percent, String kind, int appId, String details) {
        currentAppId = appId;
        currentTitle = title;
        currentPercent = percent;
        currentText = details == null ? "" : details;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        nm.notify(NOTIF_ID, build(ctx, title, percent, kind));
    }

    private static void createChannel(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        NotificationManager nm = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm == null) return;
        NotificationChannel ch = new NotificationChannel(CHANNEL, "Загрузки", NotificationManager.IMPORTANCE_LOW);
        ch.setShowBadge(false);
        nm.createNotificationChannel(ch);
    }

    private static Notification build(Context ctx, String title, int percent, String kind) {
        createChannel(ctx);

        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) flags |= PendingIntent.FLAG_IMMUTABLE;
        PendingIntent pi = PendingIntent.getActivity(ctx, 0, open, flags);

        String text;
        boolean done = false;
        if ("completed".equals(kind)) {
            text = "Готово";
            done = true;
        } else if ("failed".equals(kind)) {
            text = "Ошибка";
            done = true;
        } else if ("cancelled".equals(kind) || "paused".equals(kind)) {
            text = "cancelled".equals(kind) ? "Отменено" : "На паузе";
            done = true;
        } else {
            text = percent + "%" + (currentText.isEmpty() ? "" : " · " + currentText);
        }

        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            b = new Notification.Builder(ctx, CHANNEL);
        } else {
            b = new Notification.Builder(ctx);
        }
        b.setContentTitle(title)
                .setContentText(text)
                .setSmallIcon(ctx.getApplicationInfo().icon)
                .setOngoing(!done)
                .setOnlyAlertOnce(true)
                .setContentIntent(pi);
        if (!done) {
            b.setProgress(100, Math.max(0, Math.min(100, percent)), percent <= 0);

            int aFlags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) aFlags |= PendingIntent.FLAG_IMMUTABLE;

            Intent pause = new Intent(ACTION_PAUSE).setPackage(ctx.getPackageName());
            Intent cancel = new Intent(ACTION_CANCEL).setPackage(ctx.getPackageName());
            PendingIntent pausePi = PendingIntent.getBroadcast(ctx, 1, pause, aFlags);
            PendingIntent cancelPi = PendingIntent.getBroadcast(ctx, 2, cancel, aFlags);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                b.addAction(new Notification.Action.Builder((android.graphics.drawable.Icon) null, "Пауза", pausePi).build());
                b.addAction(new Notification.Action.Builder((android.graphics.drawable.Icon) null, "Отмена", cancelPi).build());
            }
        }
        return b.build();
    }
}
