package `in`.dragonbra.javasteam.depotdownloader

import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okio.FileSystem
import okio.Path

/**
 * Помнит, какие файлы уже полностью скачаны для каждой части игры (депота).
 *
 * Нужно, чтобы при продолжении прерванной загрузки не перечитывать и не пересчитывать
 * заново все уже готовые файлы игры — на больших играх это гигабайты и очень долгий старт.
 * Ключ файла — его имя вместе с хешем из манифеста, поэтому запись не подойдёт к другой
 * версии игры, а на диске проверяется ещё и наличие файла нужного размера.
 *
 * Сохраняется пачками (раз в несколько готовых файлов) и при остановке загрузчика, чтобы
 * не переписывать файл прогресса на каждый мелкий файл.
 */
@Serializable
data class DepotProgressStore(
    val completed: MutableMap<Int, MutableSet<String>> = mutableMapOf(),
    /**
     * Недокачанные файлы: какие куски уже записаны на диск.
     * Ключ — часть игры, имя файла и его хеш; значение — смещения записанных кусков.
     * Благодаря этому продолжение не перечитывает файл с диска, а сразу знает,
     * чего не хватает — так же ведёт себя Steam на компьютере.
     */
    val partial: MutableMap<String, MutableSet<Long>> = mutableMapOf(),
    /** true — прошлый раз загрузчик закрылся штатно; false — приложение убили или оно вылетело. */
    var cleanExit: Boolean = false,
) {
    companion object {
        private var instance: DepotProgressStore? = null

        private var filePath: Path? = null

        private val json = Json { ignoreUnknownKeys = true }

        private val lock = Any()

        private var dirtySinceSave = 0

        private const val SAVE_EVERY = 25

        private var lastSave = 0L

        /** Был ли прошлый выход аварийным — чтобы сказать об этом пользователю. */
        var lastRunWasDirty: Boolean = false
            private set

        fun loadFromFile(path: Path) {
            synchronized(lock) {
                val loaded = try {
                    if (FileSystem.SYSTEM.exists(path)) {
                        FileSystem.SYSTEM.read(path) {
                            json.decodeFromString<DepotProgressStore>(readUtf8())
                        }
                    } else {
                        DepotProgressStore()
                    }
                } catch (e: Exception) {
                    DepotProgressStore()
                }

                // Если в прошлый раз приложение вылетело, списку «уже готово» верить нельзя:
                // файл мог остаться недописанным. Забываем его и честно сверяем файлы.
                lastRunWasDirty = (loaded.completed.isNotEmpty() || loaded.partial.isNotEmpty()) &&
                    !loaded.cleanExit
                if (lastRunWasDirty) {
                    loaded.completed.clear()
                    loaded.partial.clear()
                }

                loaded.cleanExit = false
                instance = loaded
                filePath = path
                dirtySinceSave = 0

                // сразу помечаем сеанс как незавершённый
                saveLocked()
            }
        }

        private fun key(fileName: String, fileHashHex: String): String = "$fileName\u0000$fileHashHex"

        private fun partKey(depotId: Int, fileName: String, fileHashHex: String): String =
            "$depotId|$fileName\u0000$fileHashHex"

        fun isDone(depotId: Int, fileName: String, fileHashHex: String): Boolean = synchronized(lock) {
            instance?.completed?.get(depotId)?.contains(key(fileName, fileHashHex)) == true
        }

        fun markDone(depotId: Int, fileName: String, fileHashHex: String) {
            synchronized(lock) {
                val inst = instance ?: return
                // файл готов целиком — покусочная запись больше не нужна
                inst.partial.remove(partKey(depotId, fileName, fileHashHex))
                val set = inst.completed.getOrPut(depotId) { mutableSetOf() }
                if (set.add(key(fileName, fileHashHex))) {
                    dirtySinceSave++
                    if (dirtySinceSave >= SAVE_EVERY) {
                        saveLocked()
                    }
                }
            }
        }

        /** Кусок файла записан на диск — запоминаем, чтобы не качать его снова. */
        fun markChunk(depotId: Int, fileName: String, fileHashHex: String, offset: Long) {
            synchronized(lock) {
                val inst = instance ?: return
                val set = inst.partial.getOrPut(partKey(depotId, fileName, fileHashHex)) { mutableSetOf() }
                if (set.add(offset)) {
                    dirtySinceSave++
                    val now = System.currentTimeMillis()
                    // записей много, поэтому сохраняем не чаще раза в 10 секунд
                    if (dirtySinceSave >= 200 || now - lastSave > 10000L) {
                        saveLocked()
                    }
                }
            }
        }

        /** Какие куски этого файла уже лежат на диске (null — сведений нет). */
        fun chunksDone(depotId: Int, fileName: String, fileHashHex: String): Set<Long>? =
            synchronized(lock) {
                val inst = instance ?: return null
                val set = inst.partial[partKey(depotId, fileName, fileHashHex)] ?: return null
                if (set.isEmpty()) null else HashSet(set)
            }

        /** Часть игры скачана целиком — её список готовых файлов больше не нужен. */
        fun clearDepot(depotId: Int) {
            synchronized(lock) {
                val inst = instance ?: return
                val removed = inst.completed.remove(depotId) != null
                val prefix = "$depotId|"
                val hadParts = inst.partial.keys.removeAll { it.startsWith(prefix) }
                if (removed || hadParts) {
                    saveLocked()
                }
            }
        }

        /** Полная проверка: забываем всё, что считали готовым, и проверяем заново. */
        fun forgetAll() {
            synchronized(lock) {
                val inst = instance ?: return
                inst.completed.clear()
                inst.partial.clear()
                saveLocked()
            }
        }

        fun flush() {
            synchronized(lock) {
                instance?.cleanExit = true
                saveLocked()
            }
        }

        private fun saveLocked() {
            val inst = instance ?: return
            val path = filePath ?: return
            try {
                path.parent?.let { FileSystem.SYSTEM.createDirectories(it) }
                FileSystem.SYSTEM.write(path) {
                    writeUtf8(json.encodeToString(inst))
                }
                dirtySinceSave = 0
                lastSave = System.currentTimeMillis()
            } catch (e: Exception) {
                // прогресс не критичен — не роняем загрузку из-за сбоя записи
            }
        }
    }
}
