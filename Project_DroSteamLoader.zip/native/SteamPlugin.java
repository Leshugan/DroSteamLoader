package leshugan.DSL;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.Settings;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;

@CapacitorPlugin(name = "Steam")
public class SteamPlugin extends Plugin {

    private SteamCore core;

    @Override
    public void load() {
        core = SteamCore.get(getContext());
        core.setEmitter((event, data) -> {
            try {
                notifyListeners(event, JSObject.fromJSONObject(data == null ? new JSONObject() : data));
            } catch (Exception ignored) {
            }
        });
    }

    // region доступ к памяти

    @PluginMethod
    public void hasStorageAccess(PluginCall call) {
        JSObject r = new JSObject();
        boolean ok;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            ok = Environment.isExternalStorageManager();
        } else {
            ok = true;
        }
        r.put("granted", ok);
        call.resolve(r);
    }

    @PluginMethod
    public void requestStorageAccess(PluginCall call) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
            try {
                Intent i = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION);
                i.setData(Uri.parse("package:" + getContext().getPackageName()));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            } catch (Throwable t) {
                Intent i = new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getContext().startActivity(i);
            }
        }
        call.resolve();
    }

    @PluginMethod
    public void storageInfo(PluginCall call) {
        String dir = call.getString("dir", DslPaths.defaultRoot());
        JSObject r = new JSObject();
        r.put("dir", dir);
        r.put("free", DslPaths.freeSpace(dir));
        call.resolve(r);
    }

    @PluginMethod
    public void listFolders(PluginCall call) {
        String path = call.getString("path", "/storage/emulated/0");
        JSONArray arr = new JSONArray();
        File f = new File(path);
        File[] kids = f.listFiles();
        if (kids != null) {
            for (File k : kids) {
                if (!k.isDirectory() || k.isHidden()) continue;
                JSONObject o = new JSONObject();
                try {
                    o.put("name", k.getName());
                    o.put("path", k.getAbsolutePath());
                } catch (Exception ignored) {
                    continue;
                }
                arr.put(o);
            }
        }
        JSObject r = new JSObject();
        r.put("path", f.getAbsolutePath());
        r.put("parent", f.getParent() == null ? "" : f.getParent());
        r.put("items", arr);
        call.resolve(r);
    }

    // endregion

    // region вход

    @PluginMethod
    public void status(PluginCall call) {
        JSObject r = new JSObject();
        r.put("state", core.getState());
        r.put("account", core.getAccountName());
        r.put("savedAccount", core.savedAccount());
        r.put("hasSaved", core.hasSavedSession());
        r.put("downloading", core.isDownloading());
        call.resolve(r);
    }

    @PluginMethod
    public void login(PluginCall call) {
        String user = call.getString("username", "");
        String pass = call.getString("password", "");
        if (user.isEmpty() || pass.isEmpty()) {
            call.reject("Нужны логин и пароль");
            return;
        }
        core.loginWithPassword(user, pass);
        call.resolve();
    }

    @PluginMethod
    public void loginSaved(PluginCall call) {
        if (!core.hasSavedSession()) {
            call.reject("Сохранённого входа нет");
            return;
        }
        core.loginWithSavedToken();
        call.resolve();
    }

    @PluginMethod
    public void loginQr(PluginCall call) {
        core.loginWithQr();
        call.resolve();
    }

    @PluginMethod
    public void submitGuard(PluginCall call) {
        core.submitGuardCode(call.getString("code", ""));
        call.resolve();
    }

    @PluginMethod
    public void logout(PluginCall call) {
        core.logout();
        DownloadService.stop(getContext());
        call.resolve();
    }

    // endregion

    // region данные

    @PluginMethod
    public void library(final PluginCall call) {
        final boolean onlyGames = call.getBoolean("onlyGames", true);
        new Thread(() -> {
            try {
                JSONArray arr = core.library(onlyGames);
                JSObject r = new JSObject();
                r.put("apps", arr);
                call.resolve(r);
            } catch (Throwable t) {
                call.reject(String.valueOf(t.getMessage()));
            }
        }, "dsl-library").start();
    }

    @PluginMethod
    public void cachedLibrary(PluginCall call) {
        JSObject r = new JSObject();
        r.put("apps", core.cachedLibrary());
        r.put("installed", core.installed());
        call.resolve(r);
    }

    @PluginMethod
    public void checkUpdates(final PluginCall call) {
        new Thread(() -> {
            try {
                JSObject r = new JSObject();
                r.put("updates", core.checkUpdates());
                call.resolve(r);
            } catch (Throwable t) {
                call.reject(String.valueOf(t.getMessage()));
            }
        }, "dsl-updates").start();
    }

    @PluginMethod
    public void appInfo(final PluginCall call) {
        final int appId = call.getInt("appId", 0);
        if (appId <= 0) {
            call.reject("Не указан appId");
            return;
        }
        new Thread(() -> {
            try {
                JSONObject o = core.appInfo(appId);
                call.resolve(JSObject.fromJSONObject(o));
            } catch (Throwable t) {
                call.reject(String.valueOf(t.getMessage()));
            }
        }, "dsl-appinfo").start();
    }

    // endregion

    // region скачивание

    @PluginMethod
    public void startDownload(PluginCall call) {
        try {
            JSONObject p = new JSONObject(call.getData().toString());
            DownloadService.start(getContext());
            core.startDownload(p);
            call.resolve();
        } catch (Throwable t) {
            DownloadService.stop(getContext());
            call.reject(String.valueOf(t.getMessage()));
        }
    }

    @PluginMethod
    public void cancelDownload(PluginCall call) {
        core.cancelDownload();
        DownloadService.stop(getContext());
        call.resolve();
    }

    @PluginMethod
    public void cover(final PluginCall call) {
        final int appId = call.getInt("appId", 0);
        if (appId <= 0) {
            call.reject("Не указан appId");
            return;
        }
        CoverCache.get(getContext(), appId, (path, missing) -> {
            JSObject r = new JSObject();
            r.put("appId", appId);
            r.put("missing", missing);
            r.put("path", path == null ? "" : path);
            call.resolve(r);
        });
    }

    @PluginMethod
    public void servers(final PluginCall call) {
        new Thread(() -> {
            try {
                JSObject r = new JSObject();
                r.put("servers", core.servers());
                r.put("current", core.currentServer());
                call.resolve(r);
            } catch (Throwable t) {
                call.reject(String.valueOf(t.getMessage()));
            }
        }, "dsl-servers").start();
    }

    @PluginMethod
    public void setServer(PluginCall call) {
        core.setServer(call.getString("host", ""));
        call.resolve();
    }

    @PluginMethod
    public void saveLog(PluginCall call) {
        String text = call.getString("text", "");
        try {
            java.io.File dir = new java.io.File(DslPaths.defaultRoot());
            //noinspection ResultOfMethodCallIgnored
            dir.mkdirs();
            String stamp = new java.text.SimpleDateFormat("yyyy-MM-dd_HH-mm", java.util.Locale.US)
                    .format(new java.util.Date());
            java.io.File f = new java.io.File(dir, "DroSteamLoader_" + stamp + ".log");
            java.io.FileOutputStream out = new java.io.FileOutputStream(f);
            try {
                out.write(text.getBytes("UTF-8"));
            } finally {
                out.close();
            }
            JSObject r = new JSObject();
            r.put("path", f.getAbsolutePath());
            call.resolve(r);
        } catch (Throwable t) {
            call.reject(String.valueOf(t.getMessage()));
        }
    }

    @PluginMethod
    public void tasks(PluginCall call) {
        JSObject r = new JSObject();
        r.put("tasks", core.tasksJson());
        call.resolve(r);
    }

    @PluginMethod
    public void pauseTask(PluginCall call) {
        core.pauseTask(call.getInt("appId", 0));
        call.resolve();
    }

    @PluginMethod
    public void resumeTask(PluginCall call) {
        core.resumeTask(call.getInt("appId", 0));
        call.resolve();
    }

    @PluginMethod
    public void removeTask(PluginCall call) {
        core.removeTask(call.getInt("appId", 0), Boolean.TRUE.equals(call.getBoolean("withFiles", false)));
        call.resolve();
    }

    /** Тап по уведомлению просил открыть вкладку — отдаём её один раз. */
    @PluginMethod
    public void takePendingTab(PluginCall call) {
        JSObject r = new JSObject();
        r.put("tab", SteamCore.pendingTab == null ? "" : SteamCore.pendingTab);
        SteamCore.pendingTab = null;
        call.resolve(r);
    }

    @PluginMethod
    public void setSpeedUnit(PluginCall call) {
        core.setSpeedUnit(call.getString("unit", "bits"));
        call.resolve();
    }

    @PluginMethod
    public void verifyTask(PluginCall call) {
        core.verifyTask(call.getInt("appId", 0));
        call.resolve();
    }

    @PluginMethod
    public void setBackground(PluginCall call) {
        core.setBackground(Boolean.TRUE.equals(call.getBoolean("background", false)));
        call.resolve();
    }

    @PluginMethod
    public void downloadFinished(PluginCall call) {
        DownloadService.stop(getContext());
        call.resolve();
    }

    /** Путь к полному журналу на диске + его размер. */
    @PluginMethod
    public void getLogFile(PluginCall call) {
        java.io.File f = SteamCore.logFile(getContext());
        JSObject r = new JSObject();
        r.put("path", f.getAbsolutePath());
        r.put("exists", f.exists());
        r.put("size", f.exists() ? f.length() : 0L);
        call.resolve(r);
    }

    /** Отдать полный журнал через «Поделиться». */
    @PluginMethod
    public void shareLogFile(PluginCall call) {
        try {
            java.io.File f = SteamCore.logFile(getContext());
            if (!f.exists()) {
                call.reject("Отчётов о вылете нет — приложение не падало");
                return;
            }
            android.net.Uri uri = androidx.core.content.FileProvider.getUriForFile(
                    getContext(), getContext().getPackageName() + ".fileprovider", f);
            android.content.Intent i = new android.content.Intent(android.content.Intent.ACTION_SEND);
            i.setType("text/plain");
            i.putExtra(android.content.Intent.EXTRA_STREAM, uri);
            i.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION);
            android.content.Intent chooser = android.content.Intent.createChooser(i, "Журнал DroSteamLoader");
            chooser.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
            getContext().startActivity(chooser);
            call.resolve();
        } catch (Throwable t) {
            call.reject(String.valueOf(t.getMessage()));
        }
    }

    // endregion
}
