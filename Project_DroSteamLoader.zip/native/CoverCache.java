package leshugan.DSL;

import android.content.Context;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Обложки игр: скачиваем один раз и держим на телефоне,
 * чтобы при каждом запуске они появлялись мгновенно.
 */
public class CoverCache {

    private static final String BASE = "https://shared.cloudflare.steamstatic.com/store_item_assets/steam/apps/";
    private static final String[] NAMES = {"library_600x900.jpg", "header.jpg"};

    private static ExecutorService pool;

    public interface Result {
        void done(String path, boolean missing);
    }

    private static synchronized ExecutorService pool() {
        if (pool == null) pool = Executors.newFixedThreadPool(4);
        return pool;
    }

    private static File dir(Context ctx) {
        File d = new File(ctx.getFilesDir(), "covers");
        if (!d.exists()) //noinspection ResultOfMethodCallIgnored
            d.mkdirs();
        return d;
    }

    private static File file(Context ctx, int appId) {
        return new File(dir(ctx), appId + ".jpg");
    }

    private static File missMark(Context ctx, int appId) {
        return new File(dir(ctx), appId + ".none");
    }

    /** Отдаёт путь к обложке; если её ещё нет — качает в фоне. */
    public static void get(final Context ctx, final int appId, final Result cb) {
        File f = file(ctx, appId);
        if (f.exists() && f.length() > 0) {
            cb.done(f.getAbsolutePath(), false);
            return;
        }
        if (missMark(ctx, appId).exists()) {
            cb.done(null, true);
            return;
        }
        pool().execute(() -> {
            for (String name : NAMES) {
                if (download(BASE + appId + "/" + name, file(ctx, appId))) {
                    cb.done(file(ctx, appId).getAbsolutePath(), false);
                    return;
                }
            }
            try {
                //noinspection ResultOfMethodCallIgnored
                missMark(ctx, appId).createNewFile();
            } catch (Throwable ignored) {
            }
            cb.done(null, true);
        });
    }

    private static boolean download(String url, File to) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL(url).openConnection();
            c.setConnectTimeout(10000);
            c.setReadTimeout(20000);
            c.setInstanceFollowRedirects(true);
            if (c.getResponseCode() != 200) return false;
            InputStream in = c.getInputStream();
            File tmp = new File(to.getAbsolutePath() + ".part");
            FileOutputStream out = new FileOutputStream(tmp);
            try {
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            } finally {
                out.close();
                in.close();
            }
            if (tmp.length() < 512) {
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
                return false;
            }
            //noinspection ResultOfMethodCallIgnored
            tmp.renameTo(to);
            return true;
        } catch (Throwable t) {
            return false;
        } finally {
            if (c != null) c.disconnect();
        }
    }
}
