package leshugan.DSL;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        registerPlugin(SteamPlugin.class);
        super.onCreate(savedInstanceState);
        SteamCore.installCrashLogger(getApplicationContext());
        askNotificationPermission();
        rememberTab(getIntent());
    }

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        rememberTab(intent);
    }

    /** Тап по уведомлению должен открывать вкладку «Загрузки». */
    private void rememberTab(android.content.Intent intent) {
        try {
            if (intent == null) return;
            String tab = intent.getStringExtra("openTab");
            if (tab != null && !tab.isEmpty()) SteamCore.pendingTab = tab;
        } catch (Throwable ignored) {
        }
    }

    /** Без этого разрешения на Android 13+ уведомление о загрузке просто не показывается. */
    private void askNotificationPermission() {
        try {
            if (android.os.Build.VERSION.SDK_INT < 33) return;
            if (checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                    == android.content.pm.PackageManager.PERMISSION_GRANTED) return;
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 9911);
        } catch (Throwable ignored) {
        }
    }
}
